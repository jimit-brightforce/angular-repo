# BMC-Web
Health care web based application

#System setup
```
1) Install nodejs
2) Install angular cli using `npm install -g @angular/cli`
```

## Quick Start with setup

```bash
clone repo
cd <dir>
npm install
ng s
```

`npm start` should open a browser window to <http://localhost:4200>

By default angular runs on port 4200. To change this port you can run:

```bash
# This starts the development server on port 4205,
# but you can use any port you'd like
export PORT=4205 && npm start
```

### Generate build

- npm run build:qa: Inside repo bind path to your respective server/host `<dir_to_repo>dist/smarthealthcare/browser`
- npm run build:stage
- npm run build:qa
 

### Branch rules
- task: feat/<name>
- bug: fix/<ticket/short_name>

### Commit Rules

- run `npm run lint`
- run `ng build --configuration production` && `npm run build:qa` or `npm run build:prod`
- If you worked on major changes based on number of files, run `npm run prettier-format`
- Commit message should be like `<fix/feat>: <jira ticket> - <message>`

### npm start

If you receive memory issues adjust
`max_old_space_size` in the `ng` command of the `package.json`:

```json
"ng": "cross-env NODE_OPTIONS=--max_old_space_size=2048 ./node_modules/.bin/ng",
```

You can adjust 2048 to any number you need.

For more information about why you may need `--max_old_space_size`
see [this article](https://medium.com/@ashleydavis75/node-js-memory-limitations-30d3fe2664c0).

Keep in mind that this project only uses node to build the angular application.
There is no production dependency on node.
