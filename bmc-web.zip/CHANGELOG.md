# Changelog

# 17.0.0
**Implemented New Features and Enhancements:**
- Upgrade to PrimeNG 17
- Upgrade to Angular 17

## 16.0.0
**Migration Guide**
- Upgrade to PrimeNG 16
- Upgrade to Angular 16
- Update theme files

## 15.0.0
**Migration Guide**
- Upgrade to PrimeNG 15
- Upgrade to Angular 15
  
**Implemented New Features and Enhancements:**
- Update to PrimeNG 15
- Update to Angular 15

## 14.0.5

- Router updates

## 14.0.4

- Updated UI kit demos
- Updated PrimeNG
- Enabled lint

## 14.0.2

- Updated to PrimeNG 14.0.2.

## 14.0.0

- Folder structure updated.
- Replace app.config.service by layout.service.
- Updated to PrimeNG 14.
- Updated to Angular 14.
- Strict mode support added.
- Documentation updated.
- Added max-width in large screens for landing.