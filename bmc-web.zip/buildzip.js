const { zip } = require('zip-a-folder');
const moment = require('moment');

class TestBuild {
  static async main() {
    try {
      console.log(moment().format('DDMMYYYYHH'));
      await zip(
        './dist/smarthealthcare/browser/',
        './dist/smarthealthcare/DEV_' + moment().format('DDMMYYYY-HHmm') + '.zip'
      );
      console.log('dev done');
      await zip(
        './dist/smarthealthcare/qa/', 
        './dist/smarthealthcare/QA_' + moment().format('DDMMYYYY-HHmm') + '.zip'
      );
      console.log('qa done');
    } catch (error) {
      console.log(error);
    }
  }
}

TestBuild.main();
