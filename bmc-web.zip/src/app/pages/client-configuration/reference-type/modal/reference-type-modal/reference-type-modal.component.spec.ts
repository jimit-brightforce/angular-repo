import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferenceTypeModalComponent } from './reference-type-modal.component';

describe('ReferenceTypeModalComponent', () => {
  let component: ReferenceTypeModalComponent;
  let fixture: ComponentFixture<ReferenceTypeModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReferenceTypeModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ReferenceTypeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
