import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { ReferenceTypeService } from '../../service/reference-type.service';
import { ReferenceTypeData } from '../../interface/reference-type.interface';

@Component({
  selector: 'app-reference-type-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    CheckboxModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule,
  ],
  templateUrl: './reference-type-modal.component.html',
  styleUrl: './reference-type-modal.component.scss',
  providers : [ReferenceTypeService]
})
export class ReferenceTypeModalComponent extends DestroyBehavior{

  private _referenceTypeService = inject(ReferenceTypeService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);
  referenceTypeForm = this._referenceTypeService.getReferenceTypeForm();
  referenceTypeModalData: ReferenceTypeData = this._dialogService.getInstance(this._dynamicDialogRef)
    .data;
    referenceTypeModalType: number;

  constructor() {
    super();
    if (this.referenceTypeModalData) {
      this.patchValueIntoReferenceTypeForm();
    }
  }

  patchValueIntoReferenceTypeForm() {
    this.referenceTypeForm.patchValue({
      ...this.referenceTypeModalData,
    });
  }

  submitReferenceTypeForm() {
    this._utilService.markFormGroupDirty(this.referenceTypeForm);
    if (this.referenceTypeForm.valid) {
      const data = {
        id : this.referenceTypeModalData?.id,
        referenceType : this.referenceTypeForm.value.referenceType,
        referenceTable : this.referenceTypeForm.value.referenceTable,
        active : this.referenceTypeForm.value.active,

      };

      this.isLoading.set(true);
      this._referenceTypeService
        .addUpdateReferenceType(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.referenceTypeModalType,
            data: res.responseObject,
          });
        });
    }
  }
}
