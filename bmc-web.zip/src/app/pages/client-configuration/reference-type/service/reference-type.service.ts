import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';


@Injectable()
export class ReferenceTypeService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getReferenceType(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/reference-type/page`,
      payload
    );
  }

  addUpdateReferenceType(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<any>>(
        `/v1/${API_FOLDER.masters}/reference-type`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/reference-type`,
      payload
    );
  }

  deleteReferenceType(id: number) {
    return this._apiService.delete<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/reference-type/${id}`
    );
  }

  getReferenceTypeForm() {
    return this._fb.group({
        referenceType: ['', Validators.required],
        referenceTable: ['', Validators.required],
        active: [true],
    });
  }
}
