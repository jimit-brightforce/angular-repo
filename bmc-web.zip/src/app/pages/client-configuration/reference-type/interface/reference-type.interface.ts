
export interface ReferenceTypeData {
    id ?: number;
    referenceType : string;
    referenceTable : string;
    active : boolean;
}