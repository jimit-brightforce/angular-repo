import { Component, ViewChild, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { DeleteMessagePrefix, ToastService } from '@services';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { AppDialogService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { ReferenceTypeModalComponent } from './modal/reference-type-modal/reference-type-modal.component';
import { ReferenceTypeService } from './service/reference-type.service';
import { ReferenceTypeData } from './interface/reference-type.interface';

@Component({
  selector: 'app-reference-type',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './reference-type.component.html',
  styleUrl: './reference-type.component.scss',
  providers : [ReferenceTypeService]
})
export class ReferenceTypeComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _referenceTypeService = inject(ReferenceTypeService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);
  referenceTypeBody: FilterEvent;

  referenceTypeTableData = signal<ReferenceTypeData[]>([]);

  referenceTypeForm = this._referenceTypeService.getReferenceTypeForm();
  referenceTypeModalData: ReferenceTypeData;
  referenceTypeModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'referenceType', header: 'Reference Type', sortable: true, selected: true },
      { field: 'referenceTable', header: 'Reference Table', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['referenceType'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.referenceTypeBody = event;

    this._referenceTypeService
      .getReferenceType(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.referenceTypeTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteReferenceType(row) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Reference Type?', () => {
      this._referenceTypeService.deleteReferenceType(row.id).subscribe({
        next: res => {
          this.filterEvent(this.referenceTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  addEditReferenceTypeModal(data?: ReferenceTypeData) {
    const addEditReferenceTypeModalRef = this._dialogService.open(ReferenceTypeModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Reference Type',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    addEditReferenceTypeModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.referenceTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }
}
