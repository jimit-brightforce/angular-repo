import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { AppDropdownComponent } from '@components';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { CastService } from '../../service/cast.service';
import { CastData } from '../../interface/cast.interface';

@Component({
  selector: 'app-cast-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    DropdownModule,
    ButtonModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './cast-modal.component.html',
  styleUrl: './cast-modal.component.scss',
  providers : [CastService]
})
export class CastModalComponent extends DestroyBehavior{

  private _castService = inject(CastService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  religion !: ''

  castForm = this._castService.getCastForm();
  castModalData: CastData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  castModalType: number;

  constructor() {
    super();
    if (this.castModalData) {
      this.patchValueIntocastForm();
    }
  }

  patchValueIntocastForm() {
    this.castForm.patchValue({
      ...this.castModalData
    });
  }

  religionOptions = [
    { id : 'Hindu', label : 'Hindu'}
  ]

  submitCastForm() {
    this._utilService.markFormGroupDirty(this.castForm);
    if (this.castForm.valid) {
      const data = {
        id : this.castModalData?.id,
        castName : this.castForm.value.castName,
        religion : this.castForm.value.religion,
      };

      this.isLoading.set(true);
      this._castService
        .addUpdateCast(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
