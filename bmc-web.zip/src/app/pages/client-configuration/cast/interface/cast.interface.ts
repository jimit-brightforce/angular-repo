
export interface CastData {
    id ?: number;
    castName : string;
    religion : string;
}