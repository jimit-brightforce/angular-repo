
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { CastData } from '../interface/cast.interface';

@Injectable()
export class CastService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getCast(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CastData>>(
      `/v1/${API_FOLDER.masters}/cast/page`,
      payload
    );
  }


  addUpdateCast(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<CastData>>(
        `/v1/${API_FOLDER.masters}/cast`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<CastData>>(
      `/v1/${API_FOLDER.masters}/cast`,
      payload
    );
  }

  deleteCast(id: number) {
    return this._apiService.delete<ListApiResponse<CastData>>(
      `/v1/${API_FOLDER.masters}/cast/${id}`
    );
  }

  getCastForm() {
    return this._fb.group({
        castName: ['', [Validators.required]],
        religion: ['', [Validators.required]],
    });
  }
}
