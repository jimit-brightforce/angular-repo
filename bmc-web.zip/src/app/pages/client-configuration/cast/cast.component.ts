import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CastService } from './service/cast.service';
import { CastModalComponent } from './modal/cast-modal/cast-modal.component';
import { CastData } from './interface/cast.interface';

@Component({
  selector: 'app-cast',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './cast.component.html',
  styleUrl: './cast.component.scss',
  providers : [CastService]
})
export class CastComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _castService = inject(CastService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  castTypeBody: FilterEvent;
  castTableData = signal<CastData[]>([]);

  castForm = this._castService.getCastForm();
  castModalData: CastData;
  castModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'castName', header: 'Cast Name', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['cast'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.castTypeBody = event;

    this._castService
      .getCast(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.castTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditCastModal( data?: CastData) {
    const modalRef = this._dialogService.open(CastModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Cast',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.castTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteCast(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Cast?', () => {
      this._castService.deleteCast(row.id).subscribe({
        next: res => {
          this.filterEvent(this.castTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
