import { Component, ViewChild, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { DeleteMessagePrefix, ToastService } from '@services';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { AppDialogService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { MaritalStatusService } from './service/marital-status.service';
import { MaritalStatusData } from './interface/marital-status.interface';
import { MaritalStatusModalComponent } from './modal/marital-status-modal/marital-status-modal.component';

@Component({
  selector: 'app-marital-status',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './marital-status.component.html',
  styleUrl: './marital-status.component.scss',
  providers: [MaritalStatusService]
})
export class MaritalStatusComponent extends DestroyBehavior {

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _maritalStatusService = inject(MaritalStatusService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);

  maritalStatusBody: FilterEvent;
  maritalStatusTableData = signal<MaritalStatusData[]>([]);

  maritalStatusForm = this._maritalStatusService.getMaritalStatusForm();
  maritalStatusModalData: MaritalStatusData;
  maritalStatusModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'maritalStatus', header: 'Marital Status', sortable: true, selected: true },
      { field: 'maritalStatusCode', header: 'Marital Status Code', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['maritalStatus'],
  };

  filterEvent(event: FilterEvent) {
    console.log(event);

    this.config.loading = true;
    this.maritalStatusBody = event;

    this._maritalStatusService
      .getMaritalStatus(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.maritalStatusTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteMaritalStatus(row) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Marital Status?', () => {
      this._maritalStatusService.deleteMaritalStatus(row.id).subscribe({
        next: res => {
          this.filterEvent(this.maritalStatusBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  addEditMaritalStatusModal(data?: MaritalStatusData) {
    const addEditmaritalStatusModalRef = this._dialogService.open(MaritalStatusModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Marital Status',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    addEditmaritalStatusModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.maritalStatusBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }
}
