
export interface MaritalStatusData {
    id ?: number;
    martialStatus : string;
    martialStatusCode : string;
    isActive : boolean;
    primaryDisplay : boolean;
}