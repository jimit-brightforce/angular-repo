import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MaritalStatusModalComponent } from './marital-status-modal.component';

describe('MaritalStatusModalComponent', () => {
  let component: MaritalStatusModalComponent;
  let fixture: ComponentFixture<MaritalStatusModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MaritalStatusModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MaritalStatusModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
