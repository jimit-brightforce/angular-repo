import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { MaritalStatusService } from '../../service/marital-status.service';
import { MaritalStatusData } from '../../interface/marital-status.interface';

@Component({
  selector: 'app-marital-status-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    CheckboxModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule,
  ],
  templateUrl: './marital-status-modal.component.html',
  styleUrl: './marital-status-modal.component.scss',
  providers : [MaritalStatusService]
})
export class MaritalStatusModalComponent extends DestroyBehavior{

  private _maritalStatusService = inject(MaritalStatusService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);
  maritalStatusForm = this._maritalStatusService.getMaritalStatusForm();
  maritalStatusModalData: MaritalStatusData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  maritalStatusModalType: number;

  constructor() {
    super();
    if (this.maritalStatusModalData) {
      this.patchValueIntoMaritalStatusForm();
    }
  }

  patchValueIntoMaritalStatusForm() {
    this.maritalStatusForm.patchValue({
      ...this.maritalStatusModalData,
    });
  }

  submitMaritalStatusForm() {
    this._utilService.markFormGroupDirty(this.maritalStatusForm);
    if (this.maritalStatusForm.valid) {
      const data = {
        id : this.maritalStatusModalData?.id,
        maritalStatus : this.maritalStatusForm.value.maritalStatus,
        maritalStatusCode : this.maritalStatusForm.value.maritalStatusCode,
        isActive : this.maritalStatusForm.value.isActive,

      };

      this.isLoading.set(true);
      this._maritalStatusService
        .addUpdateMaritalStatus(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.maritalStatusModalType,
            data: res.responseObject,
          });
        });
    }
  }
}
