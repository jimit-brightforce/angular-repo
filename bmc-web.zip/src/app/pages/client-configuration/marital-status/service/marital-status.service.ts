import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { MaritalStatusData } from '../interface/marital-status.interface';


@Injectable()
export class MaritalStatusService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getMaritalStatus(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<MaritalStatusData>>(
      `/v1/${API_FOLDER.masters}/marital-status/page`,
      payload
    );
  }


  addUpdateMaritalStatus(payload: MaritalStatusData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<MaritalStatusData>>(
        `/v1/${API_FOLDER.masters}/marital-status`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<MaritalStatusData>>(
      `/v1/${API_FOLDER.masters}/marital-status`,
      payload
    );
  }

  deleteMaritalStatus(id: number) {
    return this._apiService.delete<ListApiResponse<MaritalStatusData>>(
      `/v1/${API_FOLDER.masters}/marital-status/${id}`
    );
  }

  getMaritalStatusForm() {
    return this._fb.group({
        maritalStatus: ['', Validators.required],
        maritalStatusCode: ['', Validators.required],
        isActive: [true],
    });
  }
}
