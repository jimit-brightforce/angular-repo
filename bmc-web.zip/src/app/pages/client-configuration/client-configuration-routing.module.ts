import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'reference-type',
        loadComponent: () =>
          import('./reference-type/reference-type.component').then(m => m.ReferenceTypeComponent),
      },
      {
        path: 'gender',
        loadComponent: () => import('./gender/gender.component').then(m => m.GenderComponent),
      },
      {
        path: 'citizen-title',
        loadComponent: () =>
          import('./citizen-title/citizen-title.component').then(m => m.CitizenTitleComponent),
      },
      {
        path: 'marital-status',
        loadComponent: () =>
          import('./marital-status/marital-status.component').then(m => m.MaritalStatusComponent),
      },
      {
        path: 'blood-group',
        loadComponent: () =>
          import('./blood-group/blood-group.component').then(m => m.BloodGroupComponent),
      },
      {
        path: 'color',
        loadComponent: () => import('./color/color.component').then(m => m.ColorComponent),
      },
      {
        path: 'religion',
        loadComponent: () => import('./religion/religion.component').then(m => m.ReligionComponent),
      },
      {
        path: 'care-provider-type',
        loadComponent: () =>
          import('./care-provider-type/care-provider-type.component').then(
            m => m.CareProviderTypeComponent
          ),
      },
      {
        path: 'cast',
        loadComponent: () => import('./cast/cast.component').then(m => m.CastComponent),
      },
      {
        path: 'grade',
        loadComponent: () => import('./grade/grade.component').then(m => m.GradeComponent),
      },
      {
        path: 'care-professional-category',
        loadComponent: () =>
          import('./care-professional-category/care-professional-category.component').then(
            m => m.CareProfessionalCategoryComponent
          ),
      },
      {
        path: 'ethnicity',
        loadComponent: () =>
          import('./ethnicity/ethnicity.component').then(m => m.EthnicityComponent),
      },
      {
        path: 'national-identity',
        loadComponent: () =>
          import('./national-identity/national-identity.component').then(
            m => m.NationalIdentityComponent
          ),
      },
      {
        path: 'relation-manager',
        loadComponent: () =>
          import('./relation-manager/relation-manager.component').then(
            m => m.RelationManagerComponent
          ),
      },
      {
        path: 'age-group',
        loadComponent: () =>
          import('./age-group/age-group.component').then(m => m.AgeGroupComponent),
      },
      {
        path: 'invoice-config',
        loadComponent: () =>
          import('./invoice-config/invoice-config.component').then(m => m.InvoiceConfigComponent),
      },
      {
        path: 'care-professional-group',
        loadComponent: () =>
          import('./care-professional-group/care-professional-group.component').then(
            m => m.CareProfessionalGroupComponent
          ),
      },
    ]),
  ],
  exports: [RouterModule],
})
export class ClientConfigurationRoutingModule {}
