import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { BloodGroupService } from './service/blood-group.service';
import { BloodGroupData } from './interface/blood-group.interface';
import { BloodGroupModalComponent } from './modal/blood-group-modal/blood-group-modal.component';

@Component({
  selector: 'app-blood-group',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule,
  ],
  templateUrl: './blood-group.component.html',
  styleUrl: './blood-group.component.scss',
  providers : [BloodGroupService]
})
export class BloodGroupComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _bloodGroupService = inject(BloodGroupService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  bloodGroupTypeBody: FilterEvent;

  bloodGroupTableData = signal<BloodGroupData[]>([]);

  bloodGroupForm = this._bloodGroupService.getBloodGroupForm();
  bloodGroupModalData: BloodGroupData;
  bloodGroupModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'bloodGroup', header: 'Blood Group', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['bloodGroup'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.bloodGroupTypeBody = event;

    this._bloodGroupService
      .getBloodGroup(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.bloodGroupTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditBloodGroupModal( data?: BloodGroupData) {
    const modalRef = this._dialogService.open(BloodGroupModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Blood Group',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {

        if (result.id) {
          this.filterEvent(this.bloodGroupTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteBloodGroup(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.bloodGroup}</b>`, () => {
      this._bloodGroupService.deleteBloodGroup(row.id).subscribe({
        next: res => {
          this.filterEvent(this.bloodGroupTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
