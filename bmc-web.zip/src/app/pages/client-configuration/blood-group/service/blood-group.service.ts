
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { BloodGroupData } from '../interface/blood-group.interface';

@Injectable()
export class BloodGroupService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getBloodGroup(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<BloodGroupData>>(
      `/v1/${API_FOLDER.masters}/blood-group/page`,
      payload
    );
  }

  addUpdateBloodGroup(payload: BloodGroupData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<BloodGroupData>>(
        `/v1/${API_FOLDER.masters}/blood-group`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<BloodGroupData>>(
      `/v1/${API_FOLDER.masters}/blood-group`,
      payload
    );
  }

  deleteBloodGroup(id: number) {
    return this._apiService.delete<ListApiResponse<BloodGroupData>>(
      `/v1/${API_FOLDER.masters}/blood-group/${id}`
    );
  }

  getBloodGroupForm() {
    return this._fb.group({
        bloodGroup: ['', [Validators.required]],
    });
  }
}
