
export interface BloodGroupData{
    id ?: number;
    bloodGroup : string,
}