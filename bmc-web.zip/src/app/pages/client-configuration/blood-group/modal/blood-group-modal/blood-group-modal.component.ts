import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { BloodGroupService } from '../../service/blood-group.service';
import { BloodGroupData } from '../../interface/blood-group.interface';

@Component({
  selector: 'app-blood-group-modal',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './blood-group-modal.component.html',
  styleUrl: './blood-group-modal.component.scss',
  providers : [BloodGroupService]
})
export class BloodGroupModalComponent extends DestroyBehavior{

  private _bloodGroupService = inject(BloodGroupService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  bloodGroupForm = this._bloodGroupService.getBloodGroupForm();
  bloodGroupModalData: BloodGroupData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  bloodGroupModalType: number;

  constructor() {
    super();
    if (this.bloodGroupModalData) {
      this.patchValueIntoBloodGroupForm();
    }
  }

  patchValueIntoBloodGroupForm() {
    this.bloodGroupForm.patchValue({
      ...this.bloodGroupModalData
    });
  }

  submitBloodGroupForm() {
    this._utilService.markFormGroupDirty(this.bloodGroupForm);
    if (this.bloodGroupForm.valid) {
      const data = {
        id : this.bloodGroupModalData?.id,
        bloodGroup : this.bloodGroupForm.value.bloodGroup,
      };

      this.isLoading.set(true);
      this._bloodGroupService
        .addUpdateBloodGroup(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
