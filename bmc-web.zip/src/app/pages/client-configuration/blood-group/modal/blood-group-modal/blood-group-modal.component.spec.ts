import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BloodGroupModalComponent } from './blood-group-modal.component';

describe('BloodGroupModalComponent', () => {
  let component: BloodGroupModalComponent;
  let fixture: ComponentFixture<BloodGroupModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BloodGroupModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BloodGroupModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
