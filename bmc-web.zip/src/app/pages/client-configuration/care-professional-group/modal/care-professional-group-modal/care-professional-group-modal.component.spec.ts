import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CareProfessionalGroupModalComponent } from './care-professional-group-modal.component';

describe('CareProfessionalGroupModalComponent', () => {
  let component: CareProfessionalGroupModalComponent;
  let fixture: ComponentFixture<CareProfessionalGroupModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CareProfessionalGroupModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CareProfessionalGroupModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
