/* eslint-disable no-cond-assign */
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, inject, signal } from '@angular/core';
import {
  AppDropdownComponent,
  FilterEvent,
  TableColumnDirective,
  TableComponent,
} from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { PickListModule } from 'primeng/picklist';
import { ButtonModule } from 'primeng/button';
import { FilterPipe } from 'src/app/shared/pipe/filter.pipe';
import { PanelModule } from 'primeng/panel';
import { CheckboxModule } from 'primeng/checkbox';

import {
  SpecialityTypeData,
  CareProfessionalNameData,
  CareprofessionalSpecialtyGroupData,
  CareProfessionalGroupData,
} from '../../interface/care-professional-group.interface';
import { DestroyBehavior } from '@strategies';
import { finalize, map, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import { ToastService, UtilService } from '@services';
import { FloatLabelModule } from 'primeng/floatlabel';

import { CareProfessionalGroupService } from '../../services/care-professional-group.service';

@Component({
  selector: 'app-care-professional-group-modal',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AppDropdownComponent,
    PickListModule,
    InputTextModule,
    ButtonModule,
    FilterPipe,
    PanelModule,
    CheckboxModule,
    FloatLabelModule,
    TableComponent,
    TableColumnDirective,
  ],
  providers: [CareProfessionalGroupService],
  templateUrl: './care-professional-group-modal.component.html',
  styleUrl: './care-professional-group-modal.component.scss',
})
export class CareProfessionalGroupModalComponent extends DestroyBehavior {
  private _careProfessionalGroupService = inject(CareProfessionalGroupService);
  private _dialogService = inject(DialogService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _toast = inject(ToastService);
  private _utilService = inject(UtilService);

  careProfessionalByspecialityTypeDropdownOptions = signal<CareProfessionalNameData[]>([]);
  careProfessionalByspecialityTypeDropdownOptionsV2 = signal<CareProfessionalNameData[]>([]);

  specialityTypeDropdownOptions = signal<SpecialityTypeData[]>([]);

  careProfessionalGroupDataData: CareProfessionalGroupData;

  careProfessionalSpecialtyGroupDropdownOptions = signal<CareprofessionalSpecialtyGroupData[]>([]);

  careProfessionalGroupForm = this._careProfessionalGroupService.getCareProfessionalGroupForm();
  selectedCareProfessionals: CareProfessionalNameData[] = [];

  selectedCarePorffessionalList: any[] = [];
  carePorffessionalList: any[] = [];
  mergedArray: any[] = [];
  // subItemselectedCarePorffessionalList: any[] = [];
  isLoading = signal<boolean>(false);
  selectedId: number;
  searchString: string = '';
  careProfessionalGroupData: CareProfessionalGroupData;
  CareProfessionalGroupModalData: number;
  selectAll: boolean = false;
  selectAllSelected: boolean = false;
  mode: 'add' | 'edit' = 'add'; // default mode is 'add'

  constructor() {
    super();
    this.careProfessionalGroupData = this._dialogService.getInstance(this._dynamicDialogRef).data;

    if (this.careProfessionalGroupData) {
      this.mode = 'edit';
      this.getCareprofessionalSpecialtyGroupList();
      this.getspecialityTypeList();
      this.getCareProfessionalByspecialityTypeListV2();
      this.patchValueIntoServiceForm();
    } else {
      this.getCareprofessionalSpecialtyGroupList();
      this.getspecialityTypeList();
    }
  }

  getCareProfessionalByspecialityTypeList(CareProfessionalGroupData) {
    this._careProfessionalGroupService
      .getCareProfessionalByspecialityTypeList(CareProfessionalGroupData.specialityTypeId)
      .pipe(
        map(res => {
          // Concatenate firstName, middleName, and familyName for each item in responseObject
          res.responseObject.forEach(item => {
            item.fullName = `${item.title}${item.firstName} ${item.middleName ? item.middleName + ' ' : ''}${item.familyName}`;
          });
          return this.careProfessionalByspecialityTypeDropdownOptions.set(res.responseObject);
        })
      )
      .subscribe();
  }

  getCareProfessionalByspecialityTypeListV2(searchKey = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'id',
        order: 'asc',
      },
    };

    this._careProfessionalGroupService
      .getCareProfessionalByspecialityTypeListV2(param)
      .pipe(takeUntil(this.notifier))
      .subscribe(res => {
        this.carePorffessionalList = res.responseObject;

        // Modify carePorffessionalList to include fullName
        this.carePorffessionalList.forEach(item => {
          item.fullName = `${item.title}${item.firstName} ${item.middleName ? item.middleName + ' ' : ''}${item.familyName}`;
        });

        this.carePorffessionalList = this.carePorffessionalList.filter(
          item2 =>
            !this.selectedCarePorffessionalList.some(item1 => item1.careProfessionalIDP === item2.careProfessionalIDP)
        );
      });
  }

  getspecialityTypeList(searchKey = '') {
    const param: FilterEvent = {
      page: 0,
      size: 250,
      searchKey: searchKey ?? null,
      sort: {
        column: 'specialityType',
        order: 'asc',
      },
    };
    this._careProfessionalGroupService
      .getspecialityTypeList(param)
      .pipe(map(res => this.specialityTypeDropdownOptions.set(res.responseObject)))
      .subscribe();
  }

  getCareprofessionalSpecialtyGroupList(searchKey = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'id',
        order: 'asc',
      },
    };
    this._careProfessionalGroupService
      .getCareprofessionalSpecialtyGroupList(param)
      .pipe(map(res => this.careProfessionalSpecialtyGroupDropdownOptions.set(res.responseObject)))
      .subscribe();
  }

  onUserNameChange(eve) {
    this.selectedId = eve;

    if (this.selectedId > 0 && this.selectedId != null) {
      this._careProfessionalGroupService
        .getCareProfessionalByspecialityTypeList(eve)
        .pipe(takeUntil(this.notifier))
        .subscribe(res => {
          this.carePorffessionalList = res.responseObject;
          this.carePorffessionalList.forEach(item => {
            item.fullName = `${item.title}${item.firstName} ${item.middleName ? item.middleName + ' ' : ''}${item.familyName}`;
          });
          // Filter out items from carePorffessionalList that are not present in selectedCarePorffessionalList
          this.carePorffessionalList = this.carePorffessionalList.filter(
            item2 =>
              !this.selectedCarePorffessionalList.some(item1 => item1.careProfessionalIDP === item2.careProfessionalIDP)
          );
        });
    } else {
      this.removeAllSelected();
      this.carePorffessionalList = [];
    }
  }

  getFormVal(formControlName: string) {
    return this.careProfessionalGroupForm.value[formControlName];
  }

  onServiceChange(value) {
    value.selected = !value.selected;
  }
  selectedList(list) {
    const selectedIndex = this.selectedCareProfessionals.findIndex(i => i === list);

    if (selectedIndex !== -1) {
      this.selectedCareProfessionals.splice(selectedIndex, 1);
      const listIndex = this.selectedCarePorffessionalList.findIndex(
        i => i.careProfessionalIDP === list.careProfessionalIDP
      );
      if (listIndex !== -1) {
        this.selectedCarePorffessionalList.splice(listIndex, 1);
      }
    } else {
      this.selectedCareProfessionals.push(list);

      const listIndex = this.selectedCarePorffessionalList.findIndex(
        i => i.careProfessionalIDP === list.careProfessionalIDP
      );
      if (listIndex === -1) {
        console.log(this.selectedCarePorffessionalList);
        list.fullName = `${list.title} ${list.firstName} ${list.middleName ? list.middleName + ' ' : ''}${list.familyName}`;

        this.selectedCarePorffessionalList.filter(obj => obj.selected);
        this.carePorffessionalList.filter(obj => obj.selected);
      }
    }
  }
  getCareprofessionalSpecialtyGroupListForPrimaryDoctor() {
    if (this.mode == 'add') {
      const modifiedArray = this.carePorffessionalList.filter(obj => obj.selected);

      return modifiedArray;
    } else {
      const selectedCarePorffessionalList = this.selectedCarePorffessionalList.filter(obj => obj.selected);
      const carePorffessionalList = this.carePorffessionalList.filter(obj => obj.selected);
      const mergedArray = [...selectedCarePorffessionalList, ...carePorffessionalList];

      return mergedArray;
    }
  }
  submitCareProfessionalGroupForm() {
    // Filter and map selected objects from selectedCarePorffessionalList
    const selectedFromListArray = this.selectedCarePorffessionalList
      .filter(service => service.selected)
      .map(obj => ({ careProfessionalId: obj.careProfessionalIDP.toString() }));

    // Filter and map selected objects from carePorffessionalList
    const selectedFromListArray2 = this.carePorffessionalList
      .filter(service => service.selected)
      .map(obj => ({ careProfessionalId: obj.careProfessionalIDP.toString() }));

    // Combine the results from both arrays
    const selectedService = [...selectedFromListArray, ...selectedFromListArray2];
    this._utilService.markFormGroupDirty(this.careProfessionalGroupForm);

    this._utilService.markFormGroupDirty(this.careProfessionalGroupForm);
    if (this.careProfessionalGroupForm.valid) {
      const formVal = this.careProfessionalGroupForm.getRawValue();

      const data = {
        id: formVal.id,
        groupName: formVal.groupName,
        primaryDoctorId: formVal.primaryDoctorId,
        careProfessionalSpecialtyGroupId: formVal.careProfessionalSpecialtyGroupId,
        careProfessionalGroupDetail: selectedService,
      };
      this.isLoading.set(true);
      this._careProfessionalGroupService
        .addUpdateCareProfessionalGroup(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(res.responseObject);
        });
    }
  }

  resetSelection() {
    this.selectedCarePorffessionalList = this.selectedCarePorffessionalList.map(item => {
      item.selected = false;
      return item;
    });
  }

  toggleAllCheckboxes() {
    // Filter the carePorffessionalList based on the searchString value
    const filteredList = this.carePorffessionalList.filter(item =>
      item.firstName.toLowerCase().includes(this.getFormVal('searchString').toLowerCase())
    );

    if (this.selectAll) {
      // Select all filtered items
      filteredList.forEach(list => {
        list.selected = true;
        this.addToSelectedLists(list);
      });
    } else {
      // Deselect all filtered items
      filteredList.forEach(list => {
        list.selected = false;
        this.removeFromSelectedLists(list);
      });
    }
  }

  addToSelectedLists(list) {
    const selectedIndex = this.selectedCareProfessionals.findIndex(i => i === list);

    if (selectedIndex === -1) {
      this.selectedCareProfessionals.push(list);
    }
    const listIndex = this.selectedCarePorffessionalList.findIndex(
      i => i.careProfessionalIDP === list.careProfessionalIDP
    );
    if (listIndex === -1) {
      list.fullName = `${list.title}${list.firstName} ${list.middleName ? list.middleName + ' ' : ''}${list.familyName}`;

      this.selectedCarePorffessionalList.push(list);
    }
  }

  removeFromSelectedLists(list) {
    const selectedIndex = this.selectedCareProfessionals.findIndex(i => i === list);

    if (selectedIndex !== -1) {
      this.selectedCareProfessionals.splice(selectedIndex, 1);
    }

    const listIndex = this.selectedCarePorffessionalList.findIndex(
      i => i.careProfessionalIDP === list.careProfessionalIDP
    );
    if (listIndex !== -1) {
      this.selectedCarePorffessionalList.splice(listIndex, 1);
    }
  }

  checkSelectAll() {
    this.selectAll = this.selectedCarePorffessionalList.every(list => list.selected);
  }

  removeAllSelected() {
    if (this.selectAllSelected) {
      this.selectedCarePorffessionalList = [];
      this.carePorffessionalList.forEach(list => {
        list.selected = false;
        this.addToSelectedLists(list);
      });
    }
  }

  patchValueIntoServiceForm() {
    if (!this.careProfessionalGroupData) return;

    this.careProfessionalGroupForm.patchValue({
      id: this.careProfessionalGroupData.id,
      groupName: this.careProfessionalGroupData.groupName,
      primaryDoctorId: this.careProfessionalGroupData.primaryDoctorId,
      primaryDoctor: this.careProfessionalGroupData.primaryDoctor,
      careProfessionalSpecialtyGroupId:
        this.careProfessionalGroupData.careProfessionalSpecialtyGroupId,
      careProfessionalSpecialtyGroup: this.careProfessionalGroupData.careProfessionalSpecialtyGroup,
    });
    // Initialize selectedCarePorffessionalList with selected care professionals
    this.selectedCarePorffessionalList =
      this.careProfessionalGroupData.careProfessionalGroupDetail?.map(detail => ({
        careProfessionalIDP: detail.careProfessionalId,
        fullName: detail.careProfessional,
        selected: true,
      })) ?? [];
  }

  resetform() {
    this.careProfessionalGroupForm.reset();
  }
}
