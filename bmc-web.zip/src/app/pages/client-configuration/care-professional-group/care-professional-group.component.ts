import { Component, ViewChild, inject, signal } from '@angular/core';
import {
  FilterEvent,
  TableColumnDirective,
  TableComponent,
  TableConfig,
  TableExpandableRowDirective,
} from '@components';
import { AppDialogService, DeleteMessagePrefix, ToastService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService } from 'primeng/dynamicdialog';
import { ButtonModule } from 'primeng/button';
import { TagModule } from 'primeng/tag';
import { CareProfessionalGroupData } from './interface/care-professional-group.interface';
import { CareProfessionalGroupModalComponent } from './modal/care-professional-group-modal/care-professional-group-modal.component';
import { finalize, takeUntil } from 'rxjs';
import { CareProfessionalGroupService } from './services/care-professional-group.service';
import { OverlayPanelModule } from 'primeng/overlaypanel';

@Component({
  selector: 'app-care-professional-group',
  standalone: true,
  imports: [
    TableComponent,
    ButtonModule,
    TagModule,
    TableColumnDirective,
    OverlayPanelModule,
    TableExpandableRowDirective,
  ],
  providers: [DialogService, CareProfessionalGroupService],
  templateUrl: './care-professional-group.component.html',
  styleUrl: './care-professional-group.component.scss',
})
export class CareProfessionalGroupComponent extends DestroyBehavior {
  @ViewChild(TableComponent) _table: TableComponent;

  private _careProfessionalGroupService = inject(CareProfessionalGroupService);
  private _appDialog = inject(AppDialogService);
  private _dialogService = inject(DialogService);
  private _toast = inject(ToastService);
  careProfessionalGroupBody: FilterEvent;
  careProfessionalGroupData = signal<CareProfessionalGroupData[]>([]);

  config: TableConfig = {
    columns: [
      { field: 'groupName', header: 'Group Name', sortable: true, selected: true },
      {
        field: 'primaryDoctor',
        header: 'Primary Doctor',
        selected: true,
        sortable: true,
      },
    ],
    lazy: true,
    loading: true,
    expandable: true,
    dataKey: 'id',
    globalFilterFields: ['primaryDoctor'],
  };
  subTableConfig: TableConfig = {
    columns: [
      { field: 'careProfessional', header: 'Care Professional', sortable: true, selected: true },
    ],
    lazy: false,
    dataKey: 'id',
    searchBar: false,
    paginator: false,
    showIndex: false,
  };

  // Map the display field to the desired sorting field
  sortFieldMap: { [key: string]: string } = {
    'groupName': 'groupName',
    'primaryDoctor': 'careProfessional.citizen.firstName',
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.careProfessionalGroupBody = event;

    if (event.sort) {
      event.sort.column = this.sortFieldMap[event?.sort?.column] || 'id';
      event.sort.order = this.sortFieldMap[event?.sort?.order] || 'desc';
    }

    this._careProfessionalGroupService
      .getCareProfessionalGroupList(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.careProfessionalGroupData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addUpdateCareProfessionalGroupModal(data?: CareProfessionalGroupData) {
    const addUpdateModalRef = this._dialogService.open(CareProfessionalGroupModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Care Professional Group',
      width: '70%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { Overlay: true },
      focusOnShow: true,
    });
    addUpdateModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.careProfessionalGroupBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteCareProfessionalGroup(row: CareProfessionalGroupData) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.groupName}</b>` + '?', () => {
      this._careProfessionalGroupService.deleteCareProfessionalGroupList(row.id).subscribe({
        next: res => {
          this.filterEvent(this.careProfessionalGroupBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  rowToggleEvent(row) {
    if (row.expanded || row.subTableData) {
      return;
    }
    row.subTableData = row.careProfessionalGroupDetail;
  }
}
