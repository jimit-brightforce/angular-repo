import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CareProfessionalGroupComponent } from './care-professional-group.component';

describe('CareProfessionalGroupComponent', () => {
  let component: CareProfessionalGroupComponent;
  let fixture: ComponentFixture<CareProfessionalGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CareProfessionalGroupComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CareProfessionalGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
