export interface CareProfessionalGroupData {
  id: number;
  groupName: string;
  primaryDoctorId: number;
  primaryDoctor: string;
  careProfessionalSpecialtyGroupId: number;
  careProfessionalSpecialtyGroup: string;
  careProfessionalGroupDetail: CareProfessionalGroupDetail[];
}

export interface CareProfessionalGroupDetail {
  id: number;
  careProfessionalId: number;
  careProfessional: string;
}

export interface SpecialityTypeData {
  id: number;
  specialityType: string;
}

export interface CareprofessionalSpecialtyGroupData {
  id: number;
  careprofessionalSpecialtyGroup: string;
}

export interface CareProfessionalNameData {
  primaryDoctorId: number;
  firstName: string;
  middleName: string;
  familyName: string;
  fullName: string;
  title: string;
}
