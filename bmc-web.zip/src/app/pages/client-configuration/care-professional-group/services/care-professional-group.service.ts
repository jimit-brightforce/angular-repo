import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import {
  CareProfessionalGroupData,
  CareProfessionalNameData,
  CareprofessionalSpecialtyGroupData,
  SpecialityTypeData,
} from '../interface/care-professional-group.interface';
import { API_FOLDER } from '@consts';
import { FilterEvent } from '@components';

@Injectable()
export class CareProfessionalGroupService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getCareProfessionalGroupForm() {
    return this._fb.group({
      id: [null],
      groupName: ['', [Validators.required, Validators.maxLength(150)]],
      primaryDoctorId: [null as number, Validators.required],
      primaryDoctor: [''],
      careProfessionalSpecialtyGroup: [''],
      searchString: [''],
      specialityTypeId: [null],
      specialityType: [''],
      careProfessionalSpecialtyGroupId: [null as number, Validators.required],
    });
  }

  getCareProfessionalGroupDetailsForm() {
    return this._fb.group({
      id: ['', [Validators.required]],
      careProfessionalId: ['', [Validators.required]],
      careProfessional: ['', [Validators.required]],
      searchString: [''],
    });
  }

  getCareProfessionalGroupList(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CareProfessionalGroupData>>(
      `/v1/${API_FOLDER.masters}/care-professional-group/page`,
      payload
    );
  }

  addUpdateCareProfessionalGroup(payload: CareProfessionalGroupData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<CareProfessionalGroupData>>(
        `/v1/${API_FOLDER.masters}/care-professional-group`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<CareProfessionalGroupData>>(
      `/v1/${API_FOLDER.masters}/care-professional-group`,
      payload
    );
  }

  deleteCareProfessionalGroupList(id: number) {
    return this._apiService.delete<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/care-professional-group/${id}`
    );
  }

  getCareProfessionalByspecialityTypeListV2(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CareProfessionalNameData>>(
      `/v1/${API_FOLDER.masters}/care-professional/speciality-type`,
      payload
    );
  }

  getCareProfessionalByspecialityTypeList(id) {
    const payload = {
      'page': 0,
      'size': 50,
      'searchKey': '',
      'sort': {
        'column': 'id',
        'order': 'asc',
      },
    };
    return this._apiService.post<ListApiResponse<CareProfessionalNameData>>(
      `/v1/${API_FOLDER.masters}/care-professional/speciality-type?specialityTypeId=${id}`,
      payload
    );
  }

  getspecialityTypeList(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<SpecialityTypeData>>(
      `/v1/${API_FOLDER.masters}/speciality-type/page`,
      payload
    );
  }

  getCareprofessionalSpecialtyGroupList(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CareprofessionalSpecialtyGroupData>>(
      `/v1/${API_FOLDER.hrDepartment}/care-professional-speciality-group/page`,
      payload
    );
  }

  addDatatoTABLE(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CareProfessionalGroupData>>(
      `/v1/${API_FOLDER.masters}/care-professional-group/page`,
      payload
    );
  }
}
