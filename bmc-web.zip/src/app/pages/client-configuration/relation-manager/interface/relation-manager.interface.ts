
export interface RelationManagerData {
    id: number
    relationManagerName: string;
    relationManagerCode: string;
    relationManagerType: string;
    relationManagerTypeLabel ?: string;
    dateOfJoining: string ;
    cityId: number;
    isActive: boolean;
}
