import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RelationManagerModalComponent } from './relation-manager-modal.component';

describe('RelationManagerModalComponent', () => {
  let component: RelationManagerModalComponent;
  let fixture: ComponentFixture<RelationManagerModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RelationManagerModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RelationManagerModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
