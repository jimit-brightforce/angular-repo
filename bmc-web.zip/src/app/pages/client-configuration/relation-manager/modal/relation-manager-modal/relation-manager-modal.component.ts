import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { RelationManagerService } from '../../service/relation-manager.service';
import { RelationManagerData } from '../../interface/relation-manager.interface';
import { CalendarModule } from 'primeng/calendar';
import { CityData } from 'src/app/pages/demographics-info/city/interface/city.interface';
import { RelationManagerType } from '@consts';
import * as moment from 'moment';

@Component({
  selector: 'app-relation-manager-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    CheckboxModule,
    CalendarModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule,
  ],
  templateUrl: './relation-manager-modal.component.html',
  styleUrl: './relation-manager-modal.component.scss',
  providers : [RelationManagerService]
})
export class RelationManagerModalComponent extends DestroyBehavior{

  private _relationManagerService = inject(RelationManagerService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);
  protected readonly RelationManagerType = RelationManagerType;

  isLoading = signal<boolean>(false);
  relationManagerForm = this._relationManagerService.getRelationManagerForm();
  relationManagerModalData: RelationManagerData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  cityModalData: CityData;
  relationManagerModalType: number;
  cityDropdownOptions = signal<CityData[]>([])

  constructor() {
    super();
    if (this.relationManagerModalData) {
      this.patchValueIntoRelationManagerForm();
    }
  }

  patchValueIntoRelationManagerForm() {
    console.log(this.relationManagerModalData);

    this.relationManagerForm.patchValue({
      ...this.relationManagerModalData,
      dateOfJoining : moment(this.relationManagerModalData.dateOfJoining, "DD-MM-YYYY").toDate() as unknown as string,
    });
  }

  getCityTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'id',
        order: 'asc',
      },
    };
    this._relationManagerService.getMetaForCity(param).subscribe({
      next: res => {
        this.cityDropdownOptions.set(res.responseObject);
      },
    });
  }

  submitRelationManagerForm() {
    this._utilService.markFormGroupDirty(this.relationManagerForm);
    if (this.relationManagerForm.valid) {
      const data = {
        id : this.relationManagerModalData?.id,
        relationManagerName : this.relationManagerForm.value.relationManagerName,
        relationManagerCode : this.relationManagerForm.value.relationManagerCode,
        relationManagerType : this.relationManagerForm.value.relationManagerType,
        dateOfJoining :  moment(this.relationManagerForm.value.dateOfJoining).format('DD-MM-YYYY'),
        cityId : this.relationManagerForm.value.cityId,
        isActive : this.relationManagerForm.value.isActive,
      };

      this.isLoading.set(true);
      this._relationManagerService
        .addUpdateRelationManager(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.relationManagerModalType,
            data: res.responseObject,
          });
        });
    }
  }
}
