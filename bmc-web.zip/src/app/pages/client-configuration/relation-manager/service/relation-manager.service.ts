import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { RelationManagerData } from '../interface/relation-manager.interface';
import { CityData } from 'src/app/pages/demographics-info/city/interface/city.interface';

@Injectable()
export class RelationManagerService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getRelationManager(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<RelationManagerData>>(
      `/v1/${API_FOLDER.masters}/relation-manager/page`,
      payload
    );
  }

  getMetaForCity(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CityData>>(
      `/v1/${API_FOLDER.masters}/city/page`,
      payload
    );
  }

  addUpdateRelationManager(payload: RelationManagerData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<RelationManagerData>>(
        `/v1/${API_FOLDER.masters}/relation-manager`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<RelationManagerData>>(
      `/v1/${API_FOLDER.masters}/relation-manager`,
      payload
    );
  }

  deleteRelationManager(id: number) {
    return this._apiService.delete<ListApiResponse<RelationManagerData>>(
      `/v1/${API_FOLDER.masters}/relation-manager/${id}`
    );
  }

  getRelationManagerForm() {
    return this._fb.group({
        relationManagerName: ['', Validators.required],
        relationManagerCode: ['', Validators.required],
        relationManagerType: ['', Validators.required],
        dateOfJoining: ['', Validators.required],
        cityId: [0, Validators.required],
        isActive: [true],
    });
  }

  RelationManagerType : any[] = [
    { id: 1, label: 'Salary' },
    { id: 2, label: 'Contact' },
    { id: 3, label: 'Dealer' },
];
}
