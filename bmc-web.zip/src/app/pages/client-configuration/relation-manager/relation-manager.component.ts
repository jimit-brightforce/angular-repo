import { Component, ViewChild, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { DeleteMessagePrefix, ToastService } from '@services';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { AppDialogService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { RelationManagerService } from './service/relation-manager.service';
import { RelationManagerData } from './interface/relation-manager.interface';
import { RelationManagerModalComponent } from './modal/relation-manager-modal/relation-manager-modal.component';
import { RelationManagerType } from '@consts';
@Component({
  selector: 'app-relation-manager',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './relation-manager.component.html',
  styleUrl: './relation-manager.component.scss',
  providers : [RelationManagerService]
})
export class RelationManagerComponent extends DestroyBehavior{

    protected RelationManagerType = RelationManagerType;

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _relationManagerService = inject(RelationManagerService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);
  relationManagerBody: FilterEvent;

  relationManagerTableData = signal<RelationManagerData[]>([]);

  relationManagerForm = this._relationManagerService.getRelationManagerForm();
  relationManagerModalData: RelationManagerData;
  relationManagerModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'relationManagerName', header: 'Relation Manager Name', sortable: true, selected: true },
      { field: 'relationManagerCode', header: 'Relation Manager Code', sortable: true, selected: true },
      { field: 'relationManagerTypeLabel', header: 'Relation Manager Type', sortable: true, selected: true },
      { field: 'dateOfJoining', header: 'Date Of Joining', sortable: true, selected: true },
      { field: 'cityName', header: 'City', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['relationManagerName'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.relationManagerBody = event;

    this._relationManagerService
      .getRelationManager(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.relationManagerTableData.set(res.responseObject);
        res.responseObject.forEach(item => {
            const salaryType = this.RelationManagerType.find(x => x.id === +item.relationManagerType);
            item.relationManagerTypeLabel = salaryType ? salaryType.label: '';
        });
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteRelationManager(row) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Relation Manager?', () => {
      this._relationManagerService.deleteRelationManager(row.id).subscribe({
        next: res => {
          this.filterEvent(this.relationManagerBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  addEditRelationManagerModal(data?: RelationManagerData) {
    const addEditrelationManagerModalRef = this._dialogService.open(RelationManagerModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Relation Manager',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    addEditrelationManagerModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.relationManagerBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }
}
