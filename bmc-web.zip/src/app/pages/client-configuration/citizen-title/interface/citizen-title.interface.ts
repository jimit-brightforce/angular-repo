
export interface CitizenTitleData {
    id ?: number;
    citizenTitle : string;
    active : boolean;
}