
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { CitizenTitleData } from '../interface/citizen-title.interface';


@Injectable()
export class CitizenTitleService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getCitizenTitle(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CitizenTitleData>>(
      `/v1/${API_FOLDER.masters}/citizen-title/page`,
      payload
    );
  }


  addUpdateCitizenTitle(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<CitizenTitleData>>(
        `/v1/${API_FOLDER.masters}/citizen-title`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<CitizenTitleData>>(
      `/v1/${API_FOLDER.masters}/citizen-title`,
      payload
    );
  }

  deleteCitizenTitle(id: number) {
    return this._apiService.delete<ListApiResponse<CitizenTitleData>>(
      `/v1/${API_FOLDER.masters}/citizen-title/${id}`
    );
  }

  getCitizenTitleForm() {
    return this._fb.group({
        citizenTitle: ['', [Validators.required]],
        active: [true, [Validators.required]],
    });
  }
}
