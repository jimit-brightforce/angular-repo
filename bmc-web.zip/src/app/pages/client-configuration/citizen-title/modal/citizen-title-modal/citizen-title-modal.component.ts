import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { PanelModule } from 'primeng/panel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { CitizenTitleData } from '../../interface/citizen-title.interface';
import { CitizenTitleService } from '../../service/citizen-title.service';


@Component({
  selector: 'app-citizen-title-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    CheckboxModule,
    ButtonModule,
    DialogModule,
    PanelModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './citizen-title-modal.component.html',
  styleUrl: './citizen-title-modal.component.scss',
  providers : [CitizenTitleService]
})
export class CitizenTitleModalComponent extends DestroyBehavior{

  private _citizenTitleService = inject(CitizenTitleService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  citizenTitleForm = this._citizenTitleService.getCitizenTitleForm();
  citizenTitleModalData: CitizenTitleData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  citizenTitleModalType: number;

  constructor() {
    super();
    if (this.citizenTitleModalData) {
      this.patchValueIntoCitizenTitleForm();
    }
  }

  patchValueIntoCitizenTitleForm() {
    this.citizenTitleForm.patchValue({
      ...this.citizenTitleModalData
    });
  }

  submitCitizenTitleForm() {
    this._utilService.markFormGroupDirty(this.citizenTitleForm);
    if (this.citizenTitleForm.valid) {
      const data = {
        id : this.citizenTitleModalData?.id,
        citizenTitle : this.citizenTitleForm.value.citizenTitle,
        active : this.citizenTitleForm.value.active,
      };

      this.isLoading.set(true);
      this._citizenTitleService
        .addUpdateCitizenTitle(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
