import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CitizenTitleModalComponent } from './citizen-title-modal.component';

describe('CitizenTitleModalComponent', () => {
  let component: CitizenTitleModalComponent;
  let fixture: ComponentFixture<CitizenTitleModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CitizenTitleModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CitizenTitleModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
