import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CitizenTitleService } from './service/citizen-title.service';
import { CitizenTitleData } from './interface/citizen-title.interface';
import { CitizenTitleModalComponent } from './modal/citizen-title-modal/citizen-title-modal.component';

@Component({
  selector: 'app-citizen-title',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './citizen-title.component.html',
  styleUrl: './citizen-title.component.scss',
  providers : [CitizenTitleService]
})
export class CitizenTitleComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _citizenTitleService = inject(CitizenTitleService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  citizenTitleTypeBody: FilterEvent;
  citizenTitleTableData = signal<CitizenTitleData[]>([]);

  citizenTitleForm = this._citizenTitleService.getCitizenTitleForm();
  citizenTitleModalData: CitizenTitleData;
  citizenTitleModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'citizenTitle', header: 'Citizen Title', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['citizenTitle'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.citizenTitleTypeBody = event;

    this._citizenTitleService
      .getCitizenTitle(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.citizenTitleTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditCitizenTitleModal( data?: CitizenTitleData) {
    const modalRef = this._dialogService.open(CitizenTitleModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Citizen Title',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.citizenTitleTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteCitizenTitle(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Speciality Type?', () => {
      this._citizenTitleService.deleteCitizenTitle(row.id).subscribe({
        next: res => {
          this.filterEvent(this.citizenTitleTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
