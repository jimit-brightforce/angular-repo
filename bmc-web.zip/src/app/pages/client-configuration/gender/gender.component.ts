import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { GenderData } from './interface/gender.interface';
import { GenderService } from './service/gender.service';
import { GenderModalComponent } from './modal/gender-modal/gender-modal.component';

@Component({
  selector: 'app-gender',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './gender.component.html',
  styleUrl: './gender.component.scss',
  providers : [GenderService]
})
export class GenderComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _genderService = inject(GenderService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  genderTypeBody: FilterEvent;

  genderTableData = signal<GenderData[]>([]);

  genderForm = this._genderService.getGenderForm();
  genderModalData: GenderData;
  genderModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'gender', header: 'Gender', sortable: true, selected: true },
      { field: 'genderCode', header: 'Gender Code', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['gender'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.genderTypeBody = event;

    this._genderService
      .getGender(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.genderTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditGenderModal( data?: GenderData) {
    const modalRef = this._dialogService.open(GenderModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Gender',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {

        if (result.id) {
          this.filterEvent(this.genderTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteGender(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Gender?', () => {
      this._genderService.deleteGender(row.id).subscribe({
        next: res => {
          this.filterEvent(this.genderTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
