
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { GenderData } from '../interface/gender.interface';

@Injectable()
export class GenderService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getGender(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<GenderData>>(
      `/v1/${API_FOLDER.masters}/gender/page`,
      payload
    );
  }


  addUpdateGender(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<GenderData>>(
        `/v1/${API_FOLDER.masters}/gender`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<GenderData>>(
      `/v1/${API_FOLDER.masters}/gender`,
      payload
    );
  }

  deleteGender(id: number) {
    return this._apiService.delete<ListApiResponse<GenderData>>(
      `/v1/${API_FOLDER.masters}/gender/${id}`
    );
  }

  getGenderForm() {
    return this._fb.group({
        gender: ['', [Validators.required]],
        genderCode: ['', [Validators.required]],
    });
  }
}
