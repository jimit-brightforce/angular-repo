
export interface GenderData {
    id ?: number;
    gender : string;
    genderCode : string;
}