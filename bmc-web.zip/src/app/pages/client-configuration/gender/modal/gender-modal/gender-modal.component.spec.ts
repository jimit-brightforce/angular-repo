import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenderModalComponent } from './gender-modal.component';

describe('GenderModalComponent', () => {
  let component: GenderModalComponent;
  let fixture: ComponentFixture<GenderModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GenderModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GenderModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
