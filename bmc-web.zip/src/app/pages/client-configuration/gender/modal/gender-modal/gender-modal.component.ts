import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { AppDropdownComponent } from '@components';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { GenderService } from '../../service/gender.service';
import { GenderData } from '../../interface/gender.interface';

@Component({
  selector: 'app-gender-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './gender-modal.component.html',
  styleUrl: './gender-modal.component.scss',
  providers : [GenderService]
})
export class GenderModalComponent extends DestroyBehavior{

  private _genderService = inject(GenderService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  genderDropdown: GenderData[] = [];

  isLoading = signal<boolean>(false);

  genderForm = this._genderService.getGenderForm();
  genderModalData: GenderData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  genderModalType: number;

  constructor() {
    super();
    if (this.genderModalData) {
      this.patchValueIntoGenderForm();
    }
  }

  patchValueIntoGenderForm() {
    this.genderForm.patchValue({
      ...this.genderModalData
    });
  }

  submitGenderForm() {
    this._utilService.markFormGroupDirty(this.genderForm);
    if (this.genderForm.valid) {
      const data = {
        id : this.genderModalData?.id,
        gender : this.genderForm.value.gender,
        genderCode : this.genderForm.value.genderCode,
      };

      this.isLoading.set(true);
      this._genderService
        .addUpdateGender(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
