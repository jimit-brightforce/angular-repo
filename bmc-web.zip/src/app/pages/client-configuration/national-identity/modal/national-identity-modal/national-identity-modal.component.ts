import { Component, OnInit, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { NationalIdentityService } from '../../service/national-identity.service';
import { NationalIdentityData } from '../../interface/national-identity.interface';

@Component({
  selector: 'app-national-identity-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    CheckboxModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule,
  ],
  templateUrl: './national-identity-modal.component.html',
  styleUrl: './national-identity-modal.component.scss',
  providers : [NationalIdentityService]
})
export class NationalIdentityModalComponent extends DestroyBehavior implements OnInit{

  private _nationaIdentityService = inject(NationalIdentityService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  nationalIdentityDropdown = signal<NationalIdentityData[]>([]);

  isLoading = signal<boolean>(false);
  nationalIdentityForm = this._nationaIdentityService.getNationalIdentityForm();
  nationalIdentityModalData: NationalIdentityData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  nationalIdentityModalType: number;

  constructor() {
    super();
    if (this.nationalIdentityModalData) {
      this.patchValueIntonationalIdentityForm();
    }
  }

  patchValueIntonationalIdentityForm() {
    this.nationalIdentityForm.patchValue({
      ...this.nationalIdentityModalData,
    });
  }

  ngOnInit(): void {
    this.getNationalIdentityTableData();
  }

  getNationalIdentityTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 15,
      searchKey: searchKey ?? null,
    };
    this._nationaIdentityService.getMetaforNationalIdentityDropDown(param).subscribe({
      next: res => {
        this.nationalIdentityDropdown.set(res.responseObject);
      },
    });
  }

  submitNationalIdentityForm() {
    this._utilService.markFormGroupDirty(this.nationalIdentityForm);
    if (this.nationalIdentityForm.valid) {
      const data = {
        id : this.nationalIdentityModalData?.id,
        countryId : this.nationalIdentityForm.value.countryId,
        identityName : this.nationalIdentityForm.value.identityName,
        isPrimery : this.nationalIdentityForm.value.isPrimery,

      };

      this.isLoading.set(true);
      this._nationaIdentityService
        .addUpdateNationalIdentity(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.nationalIdentityModalType,
            data: res.responseObject,
          });
        });
    }
  }
}
