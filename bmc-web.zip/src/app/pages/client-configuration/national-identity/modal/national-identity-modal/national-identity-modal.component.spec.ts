import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NationalIdentityModalComponent } from './national-identity-modal.component';

describe('NationalIdentityModalComponent', () => {
  let component: NationalIdentityModalComponent;
  let fixture: ComponentFixture<NationalIdentityModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NationalIdentityModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NationalIdentityModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
