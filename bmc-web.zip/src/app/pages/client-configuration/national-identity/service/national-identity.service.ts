import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { NationalIdentityData } from '../interface/national-identity.interface';


@Injectable()
export class NationalIdentityService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getNationalIdentity(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<NationalIdentityData>>(
      `/v1/${API_FOLDER.masters}/national-identity/page`,
      payload
    );
  }

  getMetaforNationalIdentityDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<NationalIdentityData>>(
      `/v1/${API_FOLDER.masters}/national-identity/page`,
      payload
    );
  }

  addUpdateNationalIdentity(payload: NationalIdentityData) {
    if (payload.id) {
      return this._apiService.post<ListApiResponse<NationalIdentityData>>(
        `/v1/${API_FOLDER.masters}/national-identity`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<NationalIdentityData>>(
      `/v1/${API_FOLDER.masters}/national-identity`,
      payload
    );
  }

  deleteNationalIdentity(id: number) {
    return this._apiService.delete<ListApiResponse<NationalIdentityData>>(
      `/v1/${API_FOLDER.masters}/national-identity/${id}`
    );
  }

  getNationalIdentityForm() {
    return this._fb.group({
      countryId: [0, Validators.required],
        identityName: ['', Validators.required],
        isPrimery: [true],
    });
  }
}
