
export interface NationalIdentityData {
    id?: number
    countryId: number
    countryName: string
    identityName: string
    isPrimery: boolean

}