import { Component, ViewChild, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { DeleteMessagePrefix, ToastService } from '@services';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { AppDialogService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { NationalIdentityService } from './service/national-identity.service';
import { NationalIdentityModalComponent } from './modal/national-identity-modal/national-identity-modal.component';
import { NationalIdentityData } from './interface/national-identity.interface';

@Component({
  selector: 'app-national-identity',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './national-identity.component.html',
  styleUrl: './national-identity.component.scss',
  providers : [NationalIdentityService]
})
export class NationalIdentityComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _nationalIdentityService = inject(NationalIdentityService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);
  nationalIdentityBody: FilterEvent;

  nationalIdentityTableData = signal<NationalIdentityData[]>([]);

  nationalIdentityForm = this._nationalIdentityService.getNationalIdentityForm();
  nationalIdentityModalData: NationalIdentityData;
  nationalIdentityModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'identityName', header: 'Identity Name', sortable: true, selected: true },
      { field: 'countryName', header: 'Country', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['nationalIdentity'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.nationalIdentityBody = event;

    this._nationalIdentityService
      .getNationalIdentity(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.nationalIdentityTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteNationalIdentity(row) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'National Identity?', () => {
      this._nationalIdentityService.deleteNationalIdentity(row.id).subscribe({
        next: res => {
          this.filterEvent(this.nationalIdentityBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  addEditNationalIdentityModal(data?: NationalIdentityData) {
    const addEditnationalIdentityModalRef = this._dialogService.open(NationalIdentityModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' National Identity',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },

    });

    addEditnationalIdentityModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.nationalIdentityBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }
}
