export interface AgeGroupData {
    id: number
    ageGroupName: string;
    ageStartRange: number;
    ageEndRange: number;
    isSystem: boolean;
    isActive: boolean;
    careProviderId?: any;
    careProviderName?: any;
}