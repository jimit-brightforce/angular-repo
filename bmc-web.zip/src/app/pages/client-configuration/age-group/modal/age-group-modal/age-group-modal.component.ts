import { Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { AgeGroupService } from '../../service/age-group.service';
import { AgeGroupData } from '../../interface/age-group.interface';

@Component({
    selector: 'app-age-group-modal',
    standalone: true,
    imports: [
        InputTextModule,
        ReactiveFormsModule,
        CheckboxModule,
        DropdownModule,
        ButtonModule,
        DialogModule,
        AppDropdownComponent,
        FloatLabelModule,
        NgxTrimDirectiveModule,
    ],
    templateUrl: './age-group-modal.component.html',
    styleUrl: './age-group-modal.component.scss',
    providers: [AgeGroupService]
})
export class AgeGroupModalComponent extends DestroyBehavior {

    private _ageGroupService = inject(AgeGroupService);
    private _dynamicDialogRef = inject(DynamicDialogRef);
    private _dialogService = inject(DialogService);
    private _utilService = inject(UtilService);
    private _toast = inject(ToastService);

    careProviderDropdownOptions = signal<any[]>([]);
    showCareProvider : boolean = false;

    isLoading = signal<boolean>(false);
    ageGroupForm: FormGroup = this._ageGroupService.getAgeGroupForm();
    ageGroupModalData: AgeGroupData = this._dialogService.getInstance(this._dynamicDialogRef).data;
    ageGroupModalType: number;

    constructor() {
        super();
        if (this.ageGroupModalData) {
            this.patchValueIntoAgeGroupForm();
        }
    }

    patchValueIntoAgeGroupForm() {
        this.ageGroupForm.patchValue({
            // ...this.ageGroupModalData,
        });
    }

    submitAgeGroupForm() {
        this._utilService.markFormGroupDirty(this.ageGroupForm);
        if (this.ageGroupForm.valid) {
            const data = {
                id: this.ageGroupModalData?.id,
                ageGroupName: this.ageGroupForm.value.ageGroupName,
                ageStartRange: this.ageGroupForm.value.ageStartRange,
                ageEndRange: this.ageGroupForm.value.ageEndRange,
                isSystem: this.ageGroupForm.value.isSystem,
                isActive: this.ageGroupForm.value.isActive,

            };

            this.isLoading.set(true);
            this._ageGroupService
                .addUpdateAgeGroup(data as any)
                .pipe(
                    takeUntil(this.notifier),
                    finalize(() => this.isLoading.set(false))
                )
                .subscribe(res => {
                    this._toast.success(res.responseMessage);
                    this._dynamicDialogRef.close({
                        closeModalType: this.ageGroupModalType,
                        data: res.responseObject,
                    });
                });
        }
    }

    getAgeGroupTableData(searchKey: string = '') {
        const param: FilterEvent = {
          page: 0,
          size: 10,
          searchKey: searchKey ?? null,
          sort: {
            column: 'id',
            order: 'asc',
          },
        };
        this._ageGroupService.getMetaforCareProvider(param).subscribe({
          next: res => {
            this.careProviderDropdownOptions.set(res.responseObject);
          },
        });
      }

    showSystemDropDown(eve) {
        console.log(eve.checked);

        if (eve.checked) {
            this.ageGroupForm.removeControl('careProviderId');
        } else {
            this.ageGroupForm.addControl('careProviderId', new FormControl('', Validators.required));
        }
    }

}
