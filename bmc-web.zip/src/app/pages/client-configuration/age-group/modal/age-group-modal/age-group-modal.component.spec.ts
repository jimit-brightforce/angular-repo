import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgeGroupModalComponent } from './age-group-modal.component';

describe('AgeGroupModalComponent', () => {
  let component: AgeGroupModalComponent;
  let fixture: ComponentFixture<AgeGroupModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AgeGroupModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AgeGroupModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
