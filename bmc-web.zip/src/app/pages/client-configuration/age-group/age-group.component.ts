import { Component, ViewChild, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { DeleteMessagePrefix, ToastService } from '@services';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { AppDialogService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { AgeGroupService } from './service/age-group.service';
import { AgeGroupData } from './interface/age-group.interface';
import { AgeGroupModalComponent } from './modal/age-group-modal/age-group-modal.component';

@Component({
  selector: 'app-age-group',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule,
  ],
  templateUrl: './age-group.component.html',
  styleUrl: './age-group.component.scss',
  providers : [AgeGroupService]
})
export class AgeGroupComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _ageGroupService = inject(AgeGroupService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);
  ageGroupBody: FilterEvent;

  ageGroupTableData = signal<AgeGroupData[]>([]);

  ageGroupForm = this._ageGroupService.getAgeGroupForm();
  ageGroupModalData: AgeGroupData;
  ageGroupModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'ageGroupName', header: 'Age Group Name', sortable: true, selected: true },
      { field: 'ageStartRange', header: 'Age Start Range', sortable: true, selected: true },
      { field: 'ageEndRange', header: 'Age End Range', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['ageGroupName'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.ageGroupBody = event;

    this._ageGroupService
      .getAgeGroup(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.ageGroupTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteAgeGroup(row) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.ageGroupName}</b>`, () => {
      this._ageGroupService.deleteAgeGroup(row.id).subscribe({
        next: res => {
          this.filterEvent(this.ageGroupBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  addEditAgeGroupModal(data?: AgeGroupData) {
    const addEditageGroupModalRef = this._dialogService.open(AgeGroupModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Age Group',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    addEditageGroupModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.ageGroupBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }
}
