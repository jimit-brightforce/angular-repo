import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { AgeGroupData } from '../interface/age-group.interface';

@Injectable()
export class AgeGroupService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getAgeGroup(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<AgeGroupData>>(
      `/v1/${API_FOLDER.masters}/ageGroup/page`,
      payload
    );
  }

  getMetaforCareProvider(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/careProvider/page`,
      payload
    );
  }

  addUpdateAgeGroup(payload: AgeGroupData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<AgeGroupData>>(
        `/v1/${API_FOLDER.masters}/ageGroup`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<AgeGroupData>>(
      `/v1/${API_FOLDER.masters}/ageGroup`,
      payload
    );
  }

  deleteAgeGroup(id: number) {
    return this._apiService.delete<ListApiResponse<AgeGroupData>>(
      `/v1/${API_FOLDER.masters}/ageGroup/${id}`
    );
  }

  getAgeGroupForm() {
    return this._fb.group({
        ageGroupName: ['', Validators.required],
        ageStartRange: ['', Validators.required],
        ageEndRange: ['', Validators.required],
        isActive: [true],
        isSystem: [true,],
        careProviderId : [null as number],

    });
  }
}
