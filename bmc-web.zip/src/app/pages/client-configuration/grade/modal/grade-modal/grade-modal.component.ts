import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { GradeService } from '../../service/grade.service';
import { GradeData } from '../../interface/grade.interface';
@Component({
  selector: 'app-grade-modal',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './grade-modal.component.html',
  styleUrl: './grade-modal.component.scss',
  providers : [GradeService]
})
export class GradeModalComponent extends DestroyBehavior{

  private _gradeService = inject(GradeService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  gradeForm = this._gradeService.getGradeForm();
  gradeModalData: GradeData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  gradeModalType: number;

  constructor() {
    super();
    if (this.gradeModalData) {
      this.patchValueIntogradeForm();
    }
  }

  patchValueIntogradeForm() {
    this.gradeForm.patchValue({
      ...this.gradeModalData
    });
  }

  submitGradeForm() {
    this._utilService.markFormGroupDirty(this.gradeForm);
    if (this.gradeForm.valid) {
      const data = {
        id : this.gradeModalData?.id,
        gradeName : this.gradeForm.value.gradeName,
      };

      this.isLoading.set(true);
      this._gradeService
        .addUpdateGrade(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
