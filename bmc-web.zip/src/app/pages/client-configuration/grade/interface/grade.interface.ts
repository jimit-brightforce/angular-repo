
export interface GradeData{
    id ?: number;
    gradeName : string,
}