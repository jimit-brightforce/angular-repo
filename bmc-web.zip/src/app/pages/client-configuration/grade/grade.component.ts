import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { GradeService } from './service/grade.service';
import { GradeData } from './interface/grade.interface';
import { GradeModalComponent } from './modal/grade-modal/grade-modal.component';
@Component({
  selector: 'app-grade',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './grade.component.html',
  styleUrl: './grade.component.scss',
  providers : [GradeService]
})
export class GradeComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _gradeService = inject(GradeService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  gradeTypeBody: FilterEvent;

  gradeTableData = signal<GradeData[]>([]);

  gradeForm = this._gradeService.getGradeForm();
  gradeModalData: GradeData;
  gradeModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'gradeName', header: 'Grade', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['grade'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.gradeTypeBody = event;

    this._gradeService
      .getGrade(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.gradeTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditGradeModal( data?: GradeData) {
    const modalRef = this._dialogService.open(GradeModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Grade',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {

        if (result.id) {
          this.filterEvent(this.gradeTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteGrade(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Grade?', () => {
      this._gradeService.deleteGrade(row.id).subscribe({
        next: res => {
          this.filterEvent(this.gradeTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
