
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { GradeData } from '../interface/grade.interface';

@Injectable()
export class GradeService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getGrade(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<GradeData>>(
      `/v1/${API_FOLDER.masters}/grade/page`,
      payload
    );
  }


  addUpdateGrade(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<GradeData>>(
        `/v1/${API_FOLDER.masters}/grade`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<GradeData>>(
      `/v1/${API_FOLDER.masters}/grade`,
      payload
    );
  }

  deleteGrade(id: number) {
    return this._apiService.delete<ListApiResponse<GradeData>>(
      `/v1/${API_FOLDER.masters}/grade/${id}`
    );
  }

  getGradeForm() {
    return this._fb.group({
        gradeName: ['', [Validators.required]],
    });
  }
}
