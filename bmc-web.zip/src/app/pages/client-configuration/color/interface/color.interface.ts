export interface ColorData {
    id?: number
    colourName: string
    isActive: boolean
    primaryDisplay: boolean
}
