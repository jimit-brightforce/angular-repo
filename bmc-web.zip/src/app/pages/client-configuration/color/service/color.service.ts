
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { ColorData } from '../interface/color.interface';

@Injectable()
export class ColorService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getColor(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<ColorData>>(
      `/v1/${API_FOLDER.masters}/colour/page`,
      payload
    );
  }


  addUpdateColor(payload: any) {
    if (payload.id) {
      return this._apiService.post<ListApiResponse<ColorData>>(
        `/v1/${API_FOLDER.masters}/colour`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<ColorData>>(
      `/v1/${API_FOLDER.masters}/colour`,
      payload
    );
  }

  deleteColor(id: number) {
    return this._apiService.delete<ListApiResponse<ColorData>>(
      `/v1/${API_FOLDER.masters}/colour/${id}`
    );
  }

  getColorForm() {
    return this._fb.group({
      colourName: ['', [Validators.required]],
    });
  }
}
