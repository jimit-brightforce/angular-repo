import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { ColorService } from '../../service/color.service';
import { ColorData } from '../../interface/color.interface';

@Component({
  selector: 'app-color-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './color-modal.component.html',
  styleUrl: './color-modal.component.scss',
  providers : [ColorService]
})
export class ColorModalComponent extends DestroyBehavior{

  private _colorService = inject(ColorService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  colorForm = this._colorService.getColorForm();
  colorModalData: ColorData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  colorModalType: number;

  constructor() {
    super();
    if (this.colorModalData) {
      this.patchValueIntoColorForm();
    }
  }

  patchValueIntoColorForm() {
    this.colorForm.patchValue({
      ...this.colorModalData
    });
  }

  submitColorForm() {
    this._utilService.markFormGroupDirty(this.colorForm);
    if (this.colorForm.valid) {
      const data = {
        id : this.colorModalData?.id,
        colourName : this.colorForm.value.colourName,
      };

      this.isLoading.set(true);
      this._colorService
        .addUpdateColor(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
