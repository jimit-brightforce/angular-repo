import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientConfigurationRoutingModule } from './client-configuration-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ClientConfigurationRoutingModule
  ]
})
export class ClientConfigurationModule { }
