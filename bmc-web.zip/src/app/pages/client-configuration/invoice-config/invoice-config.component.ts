import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';

@Component({
  selector: 'app-invoice-config',
  standalone: true,
  imports: [
    TableModule,
    ButtonModule,
    CheckboxModule,
    CommonModule,
    InputTextModule
    ],
  templateUrl: './invoice-config.component.html',
  styleUrl: './invoice-config.component.scss'
})
export class InvoiceConfigComponent {
 tabledata=[
    {
        plant:'Basic',
        partygst:'YES',
        voucher:'Yes',
        title:'Delivery Challan Cum Tax Invoice'
    },
    {
        plant:'Basic',
        partygst:'YES',
        voucher:'No',
        title:'Delivery Challan Cum '
    },
    {
        plant:'Basic',
        partygst:'NO',
        voucher:'Yes',
        title:'Delivery Tax Invoice'
    },
    {
        plant:'Basic',
        partygst:'NO',
        voucher:'No',
        title:'Delivery  Cum Tax Invoice'
    },
    {
        plant:'Mrp',
        partygst:'NA',
        voucher:'Yes',
        title:'Retail Invoice'
    },
    {
        plant:'Mrp',
        partygst:'NA',
        voucher:'No',
        title:'Retail '
    },
 ]
}
