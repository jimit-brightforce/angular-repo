import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceConfigComponent } from './invoice-config.component';

describe('InvoiceConfigComponent', () => {
  let component: InvoiceConfigComponent;
  let fixture: ComponentFixture<InvoiceConfigComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InvoiceConfigComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InvoiceConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
