import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { EthnicityService } from './service/ethnicity.service';
import { EthnicityData } from './interface/ethnicity.interface';
import { EthnicityModalComponent } from './modal/ethnicity-modal/ethnicity-modal.component';

@Component({
  selector: 'app-ethnicity',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './ethnicity.component.html',
  styleUrl: './ethnicity.component.scss',
  providers : [EthnicityService]
})
export class EthnicityComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;
  private _dialogService = inject(DialogService);
  private _ethnicityService = inject(EthnicityService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  ethnicityBody: FilterEvent;

  visible: boolean = false;
  isShowAddForm: boolean = false;

  ethnicityTableData = signal<EthnicityData[]>([]);

  ethnicityForm = this._ethnicityService.getEthnicityForm();
  ethnicityModalData: EthnicityData;
  ethnicityModalType: number;


  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'ethnicityType', header: 'Ethnicity Type', sortable: true, selected: true },
      { field: 'ethnicityGroupCode', header: 'Ethnicity Group Code', sortable: true, selected: true },

    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['priceListName'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.ethnicityBody = event;

    this._ethnicityService
      .getEthnicity(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.ethnicityTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditEthnicityModal(type: number, data?: EthnicityData) {
    const modalRef = this._dialogService.open(EthnicityModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Ethnicity',
      width: '35%',
      data: { type, data },
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      console.log('Modal closed with result:', result);
      if (result) {
        if (result.id) {
          this.filterEvent(this.ethnicityBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deletEthnicity(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Ethnicity ?', () => {
      this._ethnicityService.deleteEthnicity(row.ethnicityIDP).subscribe({
        next: res => {
          this.filterEvent(this.ethnicityBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
