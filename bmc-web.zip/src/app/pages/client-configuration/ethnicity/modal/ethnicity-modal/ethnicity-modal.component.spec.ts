import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EthnicityModalComponent } from './ethnicity-modal.component';

describe('EthnicityModalComponent', () => {
  let component: EthnicityModalComponent;
  let fixture: ComponentFixture<EthnicityModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EthnicityModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EthnicityModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
