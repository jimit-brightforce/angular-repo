import { Component, OnInit, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule } from 'primeng/dropdown';
import { DividerModule } from 'primeng/divider';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { EthnicityService } from '../../service/ethnicity.service';
import { EthnicityData } from '../../interface/ethnicity.interface';

@Component({
  selector: 'app-ethnicity-modal',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    DropdownModule,
    DividerModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
  ],
  templateUrl: './ethnicity-modal.component.html',
  styleUrl: './ethnicity-modal.component.scss',
  providers : [EthnicityService]
})
export class EthnicityModalComponent extends DestroyBehavior implements OnInit{

  private _ethnicityService = inject(EthnicityService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  ethnicityDropdown = signal<EthnicityData[]>([])

  isLoading = signal<boolean>(false);

  ethnicityForm = this._ethnicityService.getEthnicityForm();
  ethnicityModalData: EthnicityData;
  ethnicityModalType: number;

  constructor() {
    super();
    const modalRef = this._dialogService.getInstance(this._dynamicDialogRef);
    this.ethnicityModalData = modalRef.data.data;
    this.ethnicityModalType = modalRef.data.type;

    if (this.ethnicityModalData) {
      this.patchValueIntoEthnicityForm();
    }
  }

  ngOnInit(): void {
    this.getEthnicityTableData();
  }

  getEthnicityTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 15,
      searchKey: searchKey ?? null,
    };
    this._ethnicityService.getMetaforEthnicityDropDown(param).subscribe({
      next: res => {
        this.ethnicityDropdown.set(res.responseObject);
      },
    });
  }

  patchValueIntoEthnicityForm() {
    this.ethnicityForm.patchValue({
      ethnicityType: this.ethnicityModalData.ethnicityType,
      ethnicityGroupIdf: this.ethnicityModalData.ethnicityGroupIdf,
    });
  }

  submitEthnicityForm() {
    this._utilService.markFormGroupDirty(this.ethnicityForm);
    if (this.ethnicityForm.valid) {
      const data = this.ethnicityForm.value;
      console.log(data);

      this.isLoading.set(true);
      this._ethnicityService
        .addUpdateEthnicity(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.ethnicityModalType,
            data: res.responseObject,
          });
        });
    }
  }
}
