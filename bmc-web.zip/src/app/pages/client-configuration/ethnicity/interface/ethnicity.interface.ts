
export interface EthnicityData {
    id ?: number;
    ethnicityType : string;
    ethnicityGroup : string;
    ethnicityGroupIdf : string;
    isActive : boolean;
    primaryDisplay : boolean;
}
