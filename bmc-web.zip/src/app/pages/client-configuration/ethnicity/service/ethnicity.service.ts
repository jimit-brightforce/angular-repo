import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { EthnicityData } from '../interface/ethnicity.interface';


@Injectable()
export class EthnicityService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getEthnicity(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<EthnicityData>>(
      `/v1/${API_FOLDER.masters}/ethnicity/page`,
      payload
    );
  }

  getMetaforEthnicityDropDown(payload: FilterEvent) {
    return this._apiService.get<ListApiResponse<EthnicityData>>(
      `/v1/${API_FOLDER.masters}/ethnicityGroup`,
      payload
    );
  }

  addUpdateEthnicity(payload: EthnicityData) {
    if (payload.id) {
      return this._apiService.post<ListApiResponse<EthnicityData>>(
        `/v1/${API_FOLDER.masters}/ethnicity`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<EthnicityData>>(
      `/v1/${API_FOLDER.masters}/ethnicity`,
      payload
    );
  }

  deleteEthnicity(id: number) {
    return this._apiService.delete<ListApiResponse<EthnicityData>>(
      `/v1/${API_FOLDER.masters}/ethnicity/${id}`
    );
  }

  getEthnicityForm() {
    return this._fb.group({
        ethnicityType: ['', Validators.required],
        ethnicityGroupIdf: ['', Validators.required],

    });
  }
}
