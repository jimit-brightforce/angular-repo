
export interface CareProviderTypeData{
    id ?: number;
    careProviderType : string,
}