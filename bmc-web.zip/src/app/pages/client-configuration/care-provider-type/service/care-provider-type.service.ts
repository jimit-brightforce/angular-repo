
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { CareProviderTypeData } from '../interface/care-provider-type.interface';

@Injectable()
export class CareProviderTypeService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getCareProviderType(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CareProviderTypeData>>(
      `/v1/${API_FOLDER.masters}/careProviderType/page`,
      payload
    );
  }

  addUpdateCareProviderType(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<CareProviderTypeData>>(
        `/v1/${API_FOLDER.masters}/careProviderType`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<CareProviderTypeData>>(
      `/v1/${API_FOLDER.masters}/careProviderType`,
      payload
    );
  }

  deleteCareProviderType(id: number) {
    return this._apiService.delete<ListApiResponse<CareProviderTypeData>>(
      `/v1/${API_FOLDER.masters}/careProviderType/${id}`
    );
  }

  getCareProviderTypeForm() {
    return this._fb.group({
        careProviderType: ['', [Validators.required]],
    });
  }
}
