import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CareProviderTypeService } from './service/care-provider-type.service';
import { CareProviderTypeData } from './interface/care-provider-type.interface';
import { CareProviderTypeModalComponent } from './modal/care-provider-type-modal/care-provider-type-modal.component';

@Component({
  selector: 'app-care-provider-type',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './care-provider-type.component.html',
  styleUrl: './care-provider-type.component.scss',
  providers : [CareProviderTypeService]
})
export class CareProviderTypeComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _careProviderTypeService = inject(CareProviderTypeService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  careProviderTypeBody: FilterEvent;

  careProviderTypeTableData = signal<CareProviderTypeData[]>([]);

  careProviderTypeForm = this._careProviderTypeService.getCareProviderTypeForm();
  careProviderTypeModalData: CareProviderTypeData;
  careProviderTypeModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'careProviderType', header: 'Care Provider Type ', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['careProviderType'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.careProviderTypeBody = event;

    this._careProviderTypeService
      .getCareProviderType(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.careProviderTypeTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditCareProviderTypeModal( data?: CareProviderTypeData) {
    const modalRef = this._dialogService.open(CareProviderTypeModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Appointment Mode',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {

        if (result.id) {
          this.filterEvent(this.careProviderTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteCareProviderType(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Speciality Type?', () => {
      this._careProviderTypeService.deleteCareProviderType(row.id).subscribe({
        next: res => {
          this.filterEvent(this.careProviderTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
