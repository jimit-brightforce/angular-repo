import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { CareProviderTypeService } from '../../service/care-provider-type.service';
import { CareProviderTypeData } from '../../interface/care-provider-type.interface';

@Component({
  selector: 'app-care-provider-type-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './care-provider-type-modal.component.html',
  styleUrl: './care-provider-type-modal.component.scss',
  providers : [CareProviderTypeService]
})
export class CareProviderTypeModalComponent extends DestroyBehavior{

  private _careProviderTypeService = inject(CareProviderTypeService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  careProviderTypeForm = this._careProviderTypeService.getCareProviderTypeForm();
  careProviderTypeModalData: CareProviderTypeData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  careProviderTypeModalType: number;

  constructor() {
    super();
    if (this.careProviderTypeModalData) {
      this.patchValueIntoCareProviderTypeForm();
    }
  }

  patchValueIntoCareProviderTypeForm() {
    this.careProviderTypeForm.patchValue({
      ...this.careProviderTypeModalData
    });
  }

  submitCareProviderTypeForm() {
    this._utilService.markFormGroupDirty(this.careProviderTypeForm);
    if (this.careProviderTypeForm.valid) {
      const data = {
        id : this.careProviderTypeModalData?.id,
        careProviderType : this.careProviderTypeForm.value.careProviderType,
      };

      this.isLoading.set(true);
      this._careProviderTypeService
        .addUpdateCareProviderType(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
