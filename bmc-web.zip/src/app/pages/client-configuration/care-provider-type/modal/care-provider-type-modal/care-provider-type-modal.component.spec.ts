import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CareProviderTypeModalComponent } from './care-provider-type-modal.component';

describe('CareProviderTypeModalComponent', () => {
  let component: CareProviderTypeModalComponent;
  let fixture: ComponentFixture<CareProviderTypeModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CareProviderTypeModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CareProviderTypeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
