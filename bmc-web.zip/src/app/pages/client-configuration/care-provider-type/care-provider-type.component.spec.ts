import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CareProviderTypeComponent } from './care-provider-type.component';

describe('CareProviderTypeComponent', () => {
  let component: CareProviderTypeComponent;
  let fixture: ComponentFixture<CareProviderTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CareProviderTypeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CareProviderTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
