import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { CareProfessionalCategoryService } from '../../service/care-professional-category.service';
import { CareProfessionalCategoryData } from '../../interface/care-professional-category.interface';

@Component({
  selector: 'app-care-professional-category-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    CheckboxModule,
    DropdownModule,
    ButtonModule,
    DialogModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './care-professional-category-modal.component.html',
  styleUrl: './care-professional-category-modal.component.scss',
  providers : [CareProfessionalCategoryService]
})
export class CareProfessionalCategoryModalComponent extends DestroyBehavior{

  private _careProfessionalCategoryService = inject(CareProfessionalCategoryService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  careProfessionalCategoryForm = this._careProfessionalCategoryService.getCareProfessionalCategoryForm();
  careProfessionalCategoryModalData: CareProfessionalCategoryData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  careProfessionalCategoryModalType: number;

  constructor() {
    super();
    if (this.careProfessionalCategoryModalData) {
      this.patchValueIntoCareProfessionalCategoryForm();
    }
  }

  patchValueIntoCareProfessionalCategoryForm() {
    this.careProfessionalCategoryForm.patchValue({
      ...this.careProfessionalCategoryModalData
    });
  }

  submitCareProfessionalCategoryForm() {
    this._utilService.markFormGroupDirty(this.careProfessionalCategoryForm);
    if (this.careProfessionalCategoryForm.valid) {
      const data = {
        id : this.careProfessionalCategoryModalData?.id,
        careProfCategory : this.careProfessionalCategoryForm.value.careProfCategory,
        medicalPractitioner : this.careProfessionalCategoryForm.value.medicalPractitioner,
      };

      this.isLoading.set(true);
      this._careProfessionalCategoryService
        .addUpdateCareProfessionalCategory(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
