import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CareProfessionalCategoryModalComponent } from './care-professional-category-modal.component';

describe('CareProfessionalCategoryModalComponent', () => {
  let component: CareProfessionalCategoryModalComponent;
  let fixture: ComponentFixture<CareProfessionalCategoryModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CareProfessionalCategoryModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CareProfessionalCategoryModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
