
export interface CareProfessionalCategoryData {
    id ?: number;
    careProfCategory : string;
    medicalPractitioner : boolean;
}