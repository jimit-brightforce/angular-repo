
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { CareProfessionalCategoryData } from '../interface/care-professional-category.interface';

@Injectable()
export class CareProfessionalCategoryService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getCareProfessionalCategory(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CareProfessionalCategoryData>>(
      `/v1/${API_FOLDER.masters}/care-professional-category/page`,
      payload
    );
  }


  addUpdateCareProfessionalCategory(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<CareProfessionalCategoryData>>(
        `/v1/${API_FOLDER.masters}/care-professional-category`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<CareProfessionalCategoryData>>(
      `/v1/${API_FOLDER.masters}/care-professional-category`,
      payload
    );
  }

  deleteCareProfessionalCategory(id: number) {
    return this._apiService.delete<ListApiResponse<CareProfessionalCategoryData>>(
      `/v1/${API_FOLDER.masters}/care-professional-category/${id}`
    );
  }

  getCareProfessionalCategoryForm() {
    return this._fb.group({
        careProfCategory: ['', [Validators.required]],
        medicalPractitioner: [true, [Validators.required]],
    });
  }
}
