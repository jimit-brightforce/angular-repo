import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CareProfessionalCategoryComponent } from './care-professional-category.component';

describe('CareProfessionalCategoryComponent', () => {
  let component: CareProfessionalCategoryComponent;
  let fixture: ComponentFixture<CareProfessionalCategoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CareProfessionalCategoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CareProfessionalCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
