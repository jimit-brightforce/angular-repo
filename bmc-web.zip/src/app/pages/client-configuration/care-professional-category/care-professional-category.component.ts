import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CareProfessionalCategoryService } from './service/care-professional-category.service';
import { CareProfessionalCategoryData } from './interface/care-professional-category.interface';
import { CareProfessionalCategoryModalComponent } from './modal/care-professional-category-modal/care-professional-category-modal.component';

@Component({
  selector: 'app-care-professional-category',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './care-professional-category.component.html',
  styleUrl: './care-professional-category.component.scss',
  providers : [CareProfessionalCategoryService]
})
export class CareProfessionalCategoryComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _careProfessionalCategoryService = inject(CareProfessionalCategoryService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  careProfessionalCategoryTypeBody: FilterEvent;
  careProfessionalCategoryTableData = signal<CareProfessionalCategoryData[]>([]);

  careProfessionalCategoryForm = this._careProfessionalCategoryService.getCareProfessionalCategoryForm();
  careProfessionalCategoryModalData: CareProfessionalCategoryData;
  careProfessionalCategoryModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'careProfCategory', header: 'Care Professional Category', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['careProfessionalCategory'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.careProfessionalCategoryTypeBody = event;

    this._careProfessionalCategoryService
      .getCareProfessionalCategory(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.careProfessionalCategoryTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditCareProfessionalCategoryModal( data?: CareProfessionalCategoryData) {
    const modalRef = this._dialogService.open(CareProfessionalCategoryModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Care Professional Category',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.careProfessionalCategoryTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteCareProfessionalCategory(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.careProfCategory}</b>`, () => {
      this._careProfessionalCategoryService.deleteCareProfessionalCategory(row.id).subscribe({
        next: res => {
          this.filterEvent(this.careProfessionalCategoryTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
