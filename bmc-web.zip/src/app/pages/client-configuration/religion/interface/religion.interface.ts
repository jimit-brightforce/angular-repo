
export interface ReligionData{
    id ?: number;
    religionName : string,
}