import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { AppDropdownComponent } from '@components';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { ReligionService } from '../../service/religion.service';
import { ReligionData } from '../../interface/religion.interface';

@Component({
  selector: 'app-religion-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './religion-modal.component.html',
  styleUrl: './religion-modal.component.scss',
  providers : [ReligionService]
})
export class ReligionModalComponent extends DestroyBehavior{

  private _religionService = inject(ReligionService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  religionForm = this._religionService.getReligionForm();
  religionModalData: ReligionData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  religionModalType: number;

  constructor() {
    super();
    if (this.religionModalData) {
      this.patchValueIntoreligionForm();
    }
  }

  patchValueIntoreligionForm() {
    this.religionForm.patchValue({
      ...this.religionModalData
    });
  }

  submitReligionForm() {
    this._utilService.markFormGroupDirty(this.religionForm);
    if (this.religionForm.valid) {
      const data = {
        id : this.religionModalData?.id,
        religionName : this.religionForm.value.religionName,
      };

      this.isLoading.set(true);
      this._religionService
        .addUpdateReligion(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
