
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { ReligionData } from '../interface/religion.interface';

@Injectable()
export class ReligionService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getReligion(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<ReligionData>>(
      `/v1/${API_FOLDER.masters}/religion/page`,
      payload
    );
  }


  addUpdateReligion(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<ReligionData>>(
        `/v1/${API_FOLDER.masters}/religion`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<ReligionData>>(
      `/v1/${API_FOLDER.masters}/religion`,
      payload
    );
  }

  deleteReligion(id: number) {
    return this._apiService.delete<ListApiResponse<ReligionData>>(
      `/v1/${API_FOLDER.masters}/religion/${id}`
    );
  }

  getReligionForm() {
    return this._fb.group({
        religionName: ['', [Validators.required]],
    });
  }
}
