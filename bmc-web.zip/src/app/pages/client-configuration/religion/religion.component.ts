import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { ReligionService } from './service/religion.service';
import { ReligionData } from './interface/religion.interface';
import { ReligionModalComponent } from './modal/religion-modal/religion-modal.component';

@Component({
  selector: 'app-religion',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './religion.component.html',
  styleUrl: './religion.component.scss',
  providers : [ReligionService]
})
export class ReligionComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _religionService = inject(ReligionService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  religionTypeBody: FilterEvent;

  religionTableData = signal<ReligionData[]>([]);

  religionForm = this._religionService.getReligionForm();
  religionModalData: ReligionData;
  religionModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'religionName', header: 'Religion Name', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['religionName'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.religionTypeBody = event;

    this._religionService
      .getReligion(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.religionTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditReligionModal( data?: ReligionData) {
    const modalRef = this._dialogService.open(ReligionModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Appointment Mode',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {

        if (result.id) {
          this.filterEvent(this.religionTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteReligion(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Religion?', () => {
      this._religionService.deleteReligion(row.id).subscribe({
        next: res => {
          this.filterEvent(this.religionTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
