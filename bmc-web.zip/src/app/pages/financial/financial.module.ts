import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FinancialRoutingModule } from './financial-routing.module';

@NgModule({
  declarations: [],
  imports: [CommonModule, FinancialRoutingModule],
})
export class FinancialModule {}
