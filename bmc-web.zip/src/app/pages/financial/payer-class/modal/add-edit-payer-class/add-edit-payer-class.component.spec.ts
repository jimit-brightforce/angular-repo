import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditPayerClassComponent } from './add-edit-payer-class.component';

describe('AddEditPayerClassComponent', () => {
  let component: AddEditPayerClassComponent;
  let fixture: ComponentFixture<AddEditPayerClassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddEditPayerClassComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditPayerClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
