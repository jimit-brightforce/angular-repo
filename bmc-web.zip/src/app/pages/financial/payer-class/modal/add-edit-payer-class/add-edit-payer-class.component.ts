import { Component, inject, signal } from '@angular/core';
import { PayerClassBodyModel, PayerClassListData } from '../../interface/payer-class.interface';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { DividerModule } from 'primeng/divider';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { PayerClassService } from '../../services/payer-class.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { AuthService, ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { PayerMapData } from '../../../payer-map/interface/payer-map.interface';

@Component({
  selector: 'app-add-edit-payer-class',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    FormsModule,
    CheckboxModule,
    DropdownModule,
    DividerModule,
    ButtonModule,
    TableModule,
    ToastModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule,
  ],
  templateUrl: './add-edit-payer-class.component.html',
  styleUrl: './add-edit-payer-class.component.scss',
})
export class AddEditPayerClassComponent extends DestroyBehavior {
  private _payerClassService = inject(PayerClassService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _authService = inject(AuthService);
  private _toast = inject(ToastService);

  payerMapDropdown = signal<PayerMapData[]>([]);
  isLoading = signal<boolean>(false);
  payerClassForm = this._payerClassService.getPayerClassForm();
  payerClassModalData: PayerClassListData = this._dialogService.getInstance(this._dynamicDialogRef)
    .data;
  payerClassModalType: number;

  constructor() {
    super();
    if (this.payerClassModalData) {
      this.patchValueIntoPayerClassForm();
      this.getPayerClassTableData(this.payerClassModalData.payerMap.payerName);
    }
  }

  getPayerClassTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'id',
        order: 'asc',
      },
      isActive: true
    };
    this._payerClassService.getMetaforDropDown(param).subscribe({
      next: res => {
        this.payerMapDropdown.set(res.responseObject);
      },
    });
  }

  patchValueIntoPayerClassForm() {
    this.payerClassForm.patchValue({
      ...this.payerClassModalData,
      payerName: this.payerClassModalData.payerMap.id as string,
    });
    const activeControl = this.payerClassForm.get('active');
    if (this.payerClassModalData.active) {
      activeControl.disable();
    }
  }

  submitPayerClassForm() {
    this._utilService.markFormGroupDirty(this.payerClassForm);
    if (this.payerClassForm.valid) {
      const formValues = this.payerClassForm.getRawValue();
      const data: PayerClassBodyModel = {
        payerClassIDP: this.payerClassModalData?.payerClassIDP,
        payerClassName: formValues.payerClassName,
        active: formValues.active,
        createdByIDF: this._authService.userInfo().userLoginIDP,
        payerMap: {
          id: formValues.payerName,
        },
      };

      this.isLoading.set(true);
      this._payerClassService
        .addUpdatePayerClass(data as PayerClassBodyModel)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.payerClassModalType,
            data: res.responseObject,
          });
        });
    }
  }

  resetForm() {
    this.payerClassForm.reset({
      active: true
    });
    this.payerClassForm.get('active');
    if (this.payerClassModalData.active) {
      // activeControl.disable();
      //this.payerClassModalData = null;
    }
    this.payerClassModalData = null;
    this.getPayerClassTableData();
  }
}
