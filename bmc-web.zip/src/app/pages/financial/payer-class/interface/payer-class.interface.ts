import { PayerMapData } from '../../payer-map/interface/payer-map.interface';

export interface PayerClassListData {
  payerClassIDP?: number;
  payerClassName: string;
  createdByIDF: number;
  payerMap: PayerMapData;
  active: boolean;
}

export interface PayerModel {
  payerIDP: number;
  payerName: string;
  payerCode: string;
  remarks: string;
}

export interface LedgerMapModel {
  ledgerMapIDP: number;
  ledgerName: string;
  ledgerCode: string;
  careProviderIDF: number;
  description: any;
  active: boolean;
}

export interface PayerClassBodyModel {
  payerClassIDP?: number;
  payerClassName: string;
  active: boolean;
  createdByIDF: number;
  payerMap: {
    id: number | string;
  };
}
