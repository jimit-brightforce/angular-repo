import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { PayerClassBodyModel, PayerClassListData } from '../interface/payer-class.interface';
import { FilterEvent } from '@components';
import { PayerMapData } from '../../payer-map/interface/payer-map.interface';

@Injectable()
export class PayerClassService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getPayerClass(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<PayerClassListData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer-class/page`,
      payload
    );
  }

  getMetaforDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<PayerMapData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer-map/page`,
      payload
    );
  }

  addUpdatePayerClass(payload: PayerClassBodyModel) {
    if (payload.payerClassIDP) {
      return this._apiService.put<ListApiResponse<any>>(
        `/v1/${API_FOLDER.serviceConfiguration}/payer-class`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer-class`,
      payload
    );
  }

  deletePayerClass(payerClassIDP: number) {
    return this._apiService.delete<ListApiResponse<any>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer-class/${payerClassIDP}`
    );
  }

  getPayerClassForm() {
    return this._fb.group({
      payerClassName: ['', Validators.required],
      payerName: ['', Validators.required],
      active: [true],
    });
  }
}
