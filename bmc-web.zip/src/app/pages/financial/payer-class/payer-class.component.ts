import { Component, ViewChild, inject, signal } from '@angular/core';
import { PayerClassService } from './services/payer-class.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { MessageService } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { ToastService } from '@services';
import { AddEditPayerClassComponent } from './modal/add-edit-payer-class/add-edit-payer-class.component';
import { PayerClassListData } from './interface/payer-class.interface';
import { TableModule } from 'primeng/table';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {
  TableColumnDirective,
  TableComponent,
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { AppDialogService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { CommonModule } from '@angular/common';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { ActionPermissionDirective, PermissionMap } from '@directives';
import { SlugMap } from '@enums';

@Component({
  selector: 'app-payer-class',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    FormsModule,
    ButtonModule,
    TableModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule,
    NgxTrimDirectiveModule,
    ActionPermissionDirective
  ],
  templateUrl: './payer-class.component.html',
  styleUrl: './payer-class.component.scss',
  providers: [PayerClassService, MessageService, DialogService],
})
export class PayerClassComponent extends DestroyBehavior {
  @ViewChild(TableComponent) _table: TableComponent;

  protected readonly PermissionMap = PermissionMap;
  protected readonly SlugMap = SlugMap;

  private _dialogService = inject(DialogService);
  private _payerClassService = inject(PayerClassService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);
  payerClassBody: FilterEvent;

  payerClassTableData = signal<PayerClassListData[]>([]);

  payerClassForm = this._payerClassService.getPayerClassForm();
  payerClassModalData: PayerClassListData;
  payerClassModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [{ field: 'payerClassName', header: 'Payer Class', sortable: true, selected: true }],
    lazy: true,
    totalRecords: 0,
    dataKey: 'payerClassIDP',
    globalFilterFields: ['payerClassName'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.payerClassBody = event;

    this._payerClassService
      .getPayerClass(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.payerClassTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deletePayerClass(row: PayerClassListData) {
    this._appDialog.confirmDelete(`Are you sure you want to delete ${row.payerClassName}?`, () => {
      this._payerClassService.deletePayerClass(row.payerClassIDP).subscribe({
        next: res => {
          this.filterEvent(this.payerClassBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  addEditPayerClassModal(data?: PayerClassListData) {
    const addEditPayerClassModalRef = this._dialogService.open(AddEditPayerClassComponent, {
      header: (data ? 'Edit' : 'Add') + ' Payer Class',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    addEditPayerClassModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      console.log(result);
      if (result) {
        if (result.payerClassIDP) {
          this.filterEvent(this.payerClassBody);
          //   const index = findIndex(this.payerClassTableData(), {
          //     payerClassIDP: data.payerClassIDP,
          //   });
          //   this.payerClassTableData.update(data => {
          //     data[index] = result;
          //     return data;
          //   });
        } else {
          this._table.table.reset();
        }
      }
    });
  }
}
