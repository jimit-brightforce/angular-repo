import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayerClassComponent } from './payer-class.component';

describe('PayerClassComponent', () => {
  let component: PayerClassComponent;
  let fixture: ComponentFixture<PayerClassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PayerClassComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(PayerClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
