import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayerTypeComponent } from './payer-type.component';

describe('PayerTypeComponent', () => {
  let component: PayerTypeComponent;
  let fixture: ComponentFixture<PayerTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PayerTypeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PayerTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
