import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { PayerTypeService } from '../../service/payer-type.service';
import { PayerTypeData } from '../../interface/payer-type.interface';
import { CheckboxModule } from 'primeng/checkbox';


@Component({
  selector: 'app-payer-type-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    CheckboxModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './payer-type-modal.component.html',
  styleUrl: './payer-type-modal.component.scss',
  providers : [PayerTypeService]
})
export class PayerTypeModalComponent extends DestroyBehavior{

  private _payerTypeService = inject(PayerTypeService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  payerTypeForm = this._payerTypeService.getPayerTypeForm();
  payerTypeModalData: PayerTypeData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  payerTypeModalType: number;

  constructor() {
    super();
    if (this.payerTypeModalData) {
      this.patchValueIntopayerTypeForm();
    }
  }

  patchValueIntopayerTypeForm() {
    this.payerTypeForm.patchValue({
      ...this.payerTypeModalData
    });
  }

  submitPayerTypeForm() {
    this._utilService.markFormGroupDirty(this.payerTypeForm);
    if (this.payerTypeForm.valid) {
      const data = {
        id : this.payerTypeModalData?.id,
        payerType : this.payerTypeForm.value.payerType,
        isActive : this.payerTypeForm.value.isActive,
      };

      this.isLoading.set(true);
      this._payerTypeService
        .addUpdatePayerType(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
