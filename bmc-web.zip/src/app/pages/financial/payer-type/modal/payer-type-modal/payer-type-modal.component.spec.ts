import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayerTypeModalComponent } from './payer-type-modal.component';

describe('PayerTypeModalComponent', () => {
  let component: PayerTypeModalComponent;
  let fixture: ComponentFixture<PayerTypeModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PayerTypeModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PayerTypeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
