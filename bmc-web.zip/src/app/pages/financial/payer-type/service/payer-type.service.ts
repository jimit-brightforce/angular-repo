
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { PayerTypeData } from '../interface/payer-type.interface';

@Injectable()
export class PayerTypeService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getPayerType(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<PayerTypeData>>(
      `/v1/${API_FOLDER.masters}/payer-type/page`,
      payload
    );
  }

  addUpdatePayerType(payload: any) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<PayerTypeData>>(
        `/v1/${API_FOLDER.masters}/payer-type`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<PayerTypeData>>(
      `/v1/${API_FOLDER.masters}/payer-type`,
      payload
    );
  }

  deletePayerType(id: number) {
    return this._apiService.delete<ListApiResponse<PayerTypeData>>(
      `/v1/${API_FOLDER.masters}/payer-type/${id}`
    );
  }

  getPayerTypeForm() {
    return this._fb.group({
        payerType: ['', [Validators.required]],
        isActive : [true]
    });
  }
}
