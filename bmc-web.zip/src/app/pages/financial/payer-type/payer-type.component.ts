import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { PayerTypeService } from './service/payer-type.service';
import { PayerTypeData } from './interface/payer-type.interface';
import { PayerTypeModalComponent } from './modal/payer-type-modal/payer-type-modal.component';

@Component({
  selector: 'app-payer-type',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './payer-type.component.html',
  styleUrl: './payer-type.component.scss',
  providers : [PayerTypeService]
})
export class PayerTypeComponent extends DestroyBehavior{

    @ViewChild(TableComponent) _table: TableComponent;

    private _dialogService = inject(DialogService);
    private _payerTypeService = inject(PayerTypeService);
    private _toast = inject(ToastService);
    private _appDialog = inject(AppDialogService);

    payerTypeTypeBody: FilterEvent;

    payerTypeTableData = signal<PayerTypeData[]>([]);

    payerTypeForm = this._payerTypeService.getPayerTypeForm();
    payerTypeModalData: PayerTypeData;
    payerTypeModalType: number;

    config: TableConfig = {
      loading: true,
      columns: [
        { field: 'payerType', header: 'Payer Type', sortable: true, selected: true },
      ],
      lazy: true,
      totalRecords: 0,
      globalFilterFields: ['payerType'],
      showIndex: true,
    };

    filterEvent(event: FilterEvent) {
      this.config.loading = true;
      this.payerTypeTypeBody = event;

      this._payerTypeService
        .getPayerType(event)
        .pipe(
          finalize(() => (this.config.loading = false)),
          takeUntil(this.notifier)
        )
        .subscribe(res => {
          this.payerTypeTableData.set(res.responseObject);
          this.config.totalRecords = res.totalRecords;
        });
    }

    addEditPayerTypeModal( data?: PayerTypeData) {
      const modalRef = this._dialogService.open(PayerTypeModalComponent, {
        header: (data ? 'Edit' : 'Add') + ' Payer Type',
        width: '35%',
        data: data,
        breakpoints: { '1199px': '75vw', '575px': '90vw' },
        contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
        focusOnShow: true,
      });

      modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
        if (result) {

          if (result.id) {
            this.filterEvent(this.payerTypeTypeBody);
          } else {
            this._table.table.reset();
          }
        }
      });
    }

    deletePayerType(row): void {
      this._appDialog.confirmDelete(DeleteMessagePrefix + 'Payer Type?', () => {
        this._payerTypeService.deletePayerType(row.id).subscribe({
          next: res => {
            this.filterEvent(this.payerTypeTypeBody);
            this._toast.success(res.responseMessage);
          },
        });
      });
    }
}
