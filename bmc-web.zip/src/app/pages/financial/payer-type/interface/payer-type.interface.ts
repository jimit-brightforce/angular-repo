
export interface PayerTypeData{
    id ?: number;
    payerType : string,
    isActive : boolean;
}
