import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LedgerMapComponent } from './ledger-map-component.component';

describe('LedgerMapComponent', () => {
  let component: LedgerMapComponent;
  let fixture: ComponentFixture<LedgerMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LedgerMapComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(LedgerMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
