export interface LedgerMapData {
  id?: number;
  ledgerName: string;
  ledgerCode: string;
  ledgerMapIsActive: true;
  careProviderId: number;
  description: string;
  ledgerId: number;
  ledger: string;
  ledgerGroupId: number;
  ledgerGroup: string;
}

export interface LedgerData {
  id?: number | string;
  ledgerName: string;
}

export interface LedgerGroupData {
  id?: number | string;
  ledgerGroupName: string;
}
