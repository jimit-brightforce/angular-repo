import { Component, ViewChild, inject, signal } from '@angular/core';
import { TableComponent, TableColumnDirective, TableConfig, FilterEvent } from '@components';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { TagModule } from 'primeng/tag';
import { AddEditLedgerMapComponent } from './modal/add-edit-ledger-modal/add-edit-ledger-modal.component';
import { AppDialogService, ToastService } from '@services';
import { LedgerMapService } from './services/ledger-map.service';
import { finalize, takeUntil } from 'rxjs';
import { LedgerData, LedgerMapData } from './interface/ledger-map.interface';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { TooltipModule } from 'primeng/tooltip';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-ledger-map-component',
  standalone: true,
  imports: [
    ButtonModule,
    InputTextModule,
    ReactiveFormsModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    TooltipModule,
    OverlayPanelModule,
  ],
  templateUrl: './ledger-map-component.component.html',
  styleUrl: './ledger-map-component.component.scss',
  providers: [LedgerMapService, MessageService, DialogService],
})
export class LedgerMapComponent extends DestroyBehavior {
  @ViewChild(TableComponent) _table: TableComponent;
  private _dialogService = inject(DialogService);
  private _appDialog = inject(AppDialogService);
  private _ledgerMapService = inject(LedgerMapService);
  private _toast = inject(ToastService);

  ledgerMapDataData = signal<LedgerMapData[]>([]);
  ledgerListBody: FilterEvent;

  addEditLedgerModal(data?: LedgerData) {
    const modalRef = this._dialogService.open(AddEditLedgerMapComponent, {
      header: (data ? 'Edit' : 'Add') + ' Ledger List',
      width: '55%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
    });
    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.ledgerListBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  config: TableConfig = {
    columns: [
      { field: 'ledgerName', header: 'Ledger Map Name', sortable: true, selected: true },
      { field: 'ledger', header: 'Ledger', sortable: true, selected: true },
      {
        field: 'ledgerGroup',
        header: 'Ledger Group',
        sortable: true,
        selected: true,
      },
      {
        field: 'ledgerCode',
        header: 'Ledger Code',
        sortable: true,
        selected: true,
      },
      {
        field: 'description',
        header: 'Description',
        sortable: true,
        selected: true,
      },
    ],
    // lazy: false,
    globalFilterFields: ['ledgerName', 'ledger', 'ledgerGroup', 'ledgerCode', 'description'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.ledgerListBody = event;

    this._ledgerMapService
      .getLedgerMapList(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.ledgerMapDataData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteLedgerMap(row: LedgerMapData) {
    this._appDialog.confirmDelete(
      `Are you sure you want to delete '<b>${row.ledgerName}</b>'?`,
      () => {
        this._ledgerMapService.deleteLedgerMapList(row.id as number).subscribe({
          next: res => {
            this.filterEvent(this.ledgerListBody);
            this._toast.success(res.responseMessage);
          },
        });
      }
    );
  }
}
