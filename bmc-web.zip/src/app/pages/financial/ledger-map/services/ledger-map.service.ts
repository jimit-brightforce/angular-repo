import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { LedgerData, LedgerGroupData, LedgerMapData } from '../interface/ledger-map.interface';

@Injectable()
export class LedgerMapService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getLedgerMapForm() {
    return this._fb.group({
      ledgerId: [null as Number, Validators.required],
      ledgerGroupId: [null as Number, Validators.required],
      ledgerName: ['', Validators.required],
      ledgerCode: [''],
      description: [''],
      ledgerMapIsActive: [true],
    });
  }

  getLedgerMapList(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<LedgerMapData>>(
      `/v1/${API_FOLDER.masters}/ledger-map/page`,
      payload
    );
  }

  addUpdateLedgerMap(payload) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<any>>(
        `/v1/${API_FOLDER.masters}/ledger-map`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/ledger-map`,
      payload
    );
  }

  deleteLedgerMapList(ledgerMapIDP: number) {
    return this._apiService.delete<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/ledger-map/${ledgerMapIDP}`
    );
  }

  getLedgerData(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<LedgerData>>(
      `/v1/${API_FOLDER.masters}/ledger/page`,
      payload
    );
  }

  getLedgerGroupData(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<LedgerGroupData>>(
      `/v1/${API_FOLDER.masters}/ledger-group/page`,
      payload
    );
  }
}
