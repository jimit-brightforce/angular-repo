import { Component, inject, signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { DividerModule } from 'primeng/divider';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { LedgerMapService } from '../../services/ledger-map.service';
import { LedgerMapData, LedgerData, LedgerGroupData } from '../../interface/ledger-map.interface';
import { AuthService, ToastService, UtilService } from '@services';
import { FloatLabelModule } from 'primeng/floatlabel';
import { finalize, map, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { InputTrimDirective } from '@directives';

@Component({
  selector: 'app-add-edit-payer-map',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    FormsModule,
    CheckboxModule,
    DropdownModule,
    DividerModule,
    ButtonModule,
    TableModule,
    ToastModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    InputTrimDirective,
  ],
  templateUrl: './add-edit-ledger-modal.component.html',
  styleUrl: './add-edit-ledger-modal.component.scss',
})
export class AddEditLedgerMapComponent extends DestroyBehavior {
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _ledgerMapService = inject(LedgerMapService);
  private _utilService = inject(UtilService);
  private _authService = inject(AuthService);
  private _toast = inject(ToastService);

  ledgerMapForm = this._ledgerMapService.getLedgerMapForm();
  ledgerMapModalData: LedgerMapData;
  ledgerMapModalType: number;
  ledgerMapDataDropdownOptions = signal<LedgerData[]>([]);
  ledgerGroupDropdownOptions = signal<LedgerGroupData[]>([]);
  isLoading = signal<boolean>(false);

  constructor() {
    super();
    const modalRef = this._dialogService.getInstance(this._dynamicDialogRef);
    this.ledgerMapModalData = modalRef.data;
    if (this.ledgerMapModalData) {
      this.patchValueIntoLedgerMapForm();
    }
  }

  getLedgerDropdownData(searchKey: string = '') {
    const param: FilterEvent = {
      isActive: true,
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'ledgerName',
        order: 'asc',
      },
    };
    this._ledgerMapService
      .getLedgerData(param)
      .pipe(map(res => this.ledgerMapDataDropdownOptions.set(res.responseObject)))
      .subscribe();
  }

  getLedgerGroupDropdownData(searchKey: string = '') {
    const param: FilterEvent = {
      isActive: true,
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'ledgerGroup',
        order: 'asc',
      },
    };
    this._ledgerMapService
      .getLedgerGroupData(param)
      .pipe(map(res => this.ledgerGroupDropdownOptions.set(res.responseObject)))
      .subscribe();
  }

  patchValueIntoLedgerMapForm() {
    this.getLedgerDropdownData(this.ledgerMapModalData.ledger);
    this.getLedgerGroupDropdownData(this.ledgerMapModalData.ledgerGroup);
    this.ledgerMapForm.patchValue({
      ledgerId: this.ledgerMapModalData.ledgerId,
      ledgerGroupId: this.ledgerMapModalData.ledgerGroupId,
      ledgerName: this.ledgerMapModalData.ledgerName,
      ledgerCode: this.ledgerMapModalData.ledgerCode,
      description: this.ledgerMapModalData.description,
      ledgerMapIsActive: this.ledgerMapModalData.ledgerMapIsActive,
    });
  }

  submitledgerMapForm() {
    this._utilService.markFormGroupDirty(this.ledgerMapForm);
    if (this.ledgerMapForm.valid) {
      const formVal = this.ledgerMapForm.value;
      const data = {
        id: this.ledgerMapModalData?.id,
        ledgerId: formVal.ledgerId,
        ledgerGroupId: formVal.ledgerGroupId,
        ledgerName: formVal.ledgerName,
        description: formVal.description,
        ledgerCode: formVal.ledgerCode,
        ledgerMapIsActive: formVal.ledgerMapIsActive,
      };
      this.isLoading.set(true);
      this._ledgerMapService
        .addUpdateLedgerMap(data)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
