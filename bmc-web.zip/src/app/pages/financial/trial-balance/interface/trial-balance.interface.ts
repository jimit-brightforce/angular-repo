export interface AddFinancialYearFormData {
  financialYear: string;
}

export interface BalanceProcessModalData {
  balanceProcessOption: string;
  financialYear: number;
}

export interface TrialBalanceReportFormData {
  fromDate: string;
  toDate: string;
  isStationary: boolean;
}

export interface LstTrialBlance {
  id: number;
  ledgerName: string;
  ledgerCode: string;
  careProviderIDF: number;
  description: string;
  ledgerGroupId: number;
  ledgerGroupName: string;
  openingBalance: number;
  openingSide: number;
  closingBalance: number;
  closingSide: string;
  active: boolean;
}

export interface drpFinancialYear {
  id: number;
  financialYear: number;
  financialYearName: string;
}
