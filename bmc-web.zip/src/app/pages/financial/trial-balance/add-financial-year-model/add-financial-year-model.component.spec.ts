import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFinancialYearModelComponent } from './add-financial-year-model.component';

describe('AddFinancialYearModelComponent', () => {
  let component: AddFinancialYearModelComponent;
  let fixture: ComponentFixture<AddFinancialYearModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddFinancialYearModelComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AddFinancialYearModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
