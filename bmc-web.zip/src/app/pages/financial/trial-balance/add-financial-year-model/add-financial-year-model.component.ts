import { Component, inject, signal } from '@angular/core';
import { TrialBalanceService } from '../service/trial-balance.service';
import { AddFinancialYearFormData, drpFinancialYear } from '../interface/trial-balance.interface';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppDropdownComponent } from '@components';
import { ToastService, UtilService } from '@services';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-add-financial-year-model',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, ButtonModule, AppDropdownComponent],
  providers: [TrialBalanceService],
  templateUrl: './add-financial-year-model.component.html',
  styleUrl: './add-financial-year-model.component.scss',
})
export class AddFinancialYearModelComponent extends DestroyBehavior {
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _trialBalanceService = inject(TrialBalanceService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);
  fetchFinancialYearOptions = signal<drpFinancialYear[]>([]);

  financialYearOptions = this._trialBalanceService.FetchFinancialYearOptions();

  financialYearForm = this._trialBalanceService.getAddFinancialYearForm();
  financialYearModalData: AddFinancialYearFormData;
  financialYearModalType: number;

  constructor() {
    super();
    this.fetchDrpfinancialYear();
  }

  fetchDrpfinancialYear() {
    this._trialBalanceService
      .FetchFinancialYearOptions()
      .pipe(takeUntil(this.notifier))
      .subscribe(res => {
        this.fetchFinancialYearOptions.set(res.responseObject);
      });
  }

  closeModal(result: boolean) {
    this._dynamicDialogRef.close(result);
  }

  submitFinancialYearForm() {
    this._utilService.markFormGroupDirty(this.financialYearForm);
    if (this.financialYearForm.valid) {
      const closeModalParams = this.financialYearForm.getRawValue();
      const payload = {
        id: closeModalParams.financialYear,
      };
      this._trialBalanceService
        .saveFinancialYear(payload)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(closeModalParams);
        });
    } else {
      this._toast.error('Please select Finanacial Year.');
    }
  }
}
