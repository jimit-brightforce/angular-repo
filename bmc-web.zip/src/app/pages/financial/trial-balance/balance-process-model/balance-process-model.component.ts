import { Component, inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';
import { TrialBalanceService } from '../service/trial-balance.service';
import { BalanceProcessModalData } from '../interface/trial-balance.interface';
import { UtilService } from '@services';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-balance-process-model',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, ButtonModule, RadioButtonModule],
  providers: [TrialBalanceService],
  templateUrl: './balance-process-model.component.html',
  styleUrl: './balance-process-model.component.scss',
})
export class BalanceProcessModelComponent {
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _trialBalanceService = inject(TrialBalanceService);
  private _utilService = inject(UtilService);
  private _dialogService = inject(DialogService);

  balanceProcessForm = this._trialBalanceService.getAddBalanceProcessForm();
  balanceProcessModalData: BalanceProcessModalData;
  balanceProcessModalType: number;

  balanceProcessOptions = this._trialBalanceService.getBalanceProcessOptions();

  constructor() {
    const modalRef = this._dialogService.getInstance(this._dynamicDialogRef);
    this.balanceProcessModalData = modalRef.data.data;
    this.balanceProcessModalType = modalRef.data.type;
  }

  closeModal(result: boolean) {
    this._dynamicDialogRef.close(result);
  }

  submitBalanceProcessForm() {
    this._utilService.markFormGroupDirty(this.balanceProcessForm);
    const event = {
      'financialId': this.balanceProcessModalData.financialYear,
      'radio': this.balanceProcessForm.value.balanceProcessOption,
    };
    console.log(event);

    if (this.balanceProcessForm.valid) {
      this._trialBalanceService.getTrialBalancewithBalnceProcess(event).subscribe(res => {
        this._dynamicDialogRef.close(res.responseObject);
      });
    }
  }
}
