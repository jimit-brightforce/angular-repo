import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BalanceProcessModelComponent } from './balance-process-model.component';

describe('BalanceProcessModelComponent', () => {
  let component: BalanceProcessModelComponent;
  let fixture: ComponentFixture<BalanceProcessModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BalanceProcessModelComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(BalanceProcessModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
