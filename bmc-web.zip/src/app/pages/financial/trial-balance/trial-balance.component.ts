import { Component, inject, signal } from '@angular/core';
import { TrialBalanceService } from './service/trial-balance.service';
import {
  AppDropdownComponent,
  TableColumnDirective,
  TableComponent,
  TableConfig,
} from '@components';
import { TrialBalanceReportModelComponent } from './trial-balance-report-model/trial-balance-report-model.component';
import { cloneDeep } from 'lodash';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DestroyBehavior } from '@strategies';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { InputTextModule } from 'primeng/inputtext';
import { AddFinancialYearModelComponent } from './add-financial-year-model/add-financial-year-model.component';
import { BalanceProcessModelComponent } from './balance-process-model/balance-process-model.component';
import { LstTrialBlance, drpFinancialYear } from './interface/trial-balance.interface';
import { PanelModule } from 'primeng/panel';
import { DropdownModule } from 'primeng/dropdown';
import { ToastService } from '@services';

@Component({
  selector: 'app-trial-balance',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    InputTextModule,
    TableComponent,
    TableColumnDirective,
    ButtonModule,
    AppDropdownComponent,
    PanelModule,
    DropdownModule,
  ],
  providers: [TrialBalanceService],
  templateUrl: './trial-balance.component.html',
  styleUrl: './trial-balance.component.scss',
})
export class TrialBalanceComponent extends DestroyBehavior {
  private _dialogService = inject(DialogService);
  private _trialBalanceService = inject(TrialBalanceService);
  private _toast = inject(ToastService);

  financialYearOptions = signal<drpFinancialYear[]>([]);
  getTralBlanceTblData = signal<LstTrialBlance[]>([]);

  trialbalanceForm: FormGroup;
  OpeningBalanceVlaueArray = [];
  OpeningBalanceOptionsArray = [];
  ClosingBalanceVlaueArray = [];
  ClosingBalanceOptionsArray = [];

  trialBalanceSearchForm = this._trialBalanceService.getTrialBalanceSearchForm();

  constructor() {
    super();
    this.getDrpfinancialYear();
  }

  config: TableConfig = {
    columns: [
      {
        field: 'ledgerMapName',
        header: 'Ledger Name',
        sortable: false,
        selected: true,
      },
    ],
    lazy: false,
    paginator: false,
    searchBar: true,
    hideGlobalFilter: true,
    showIndex: false,
    showColumnFilter: false,
  };

  openingSideOptions = [
    {
      label: 'Dr',
      openingSide: '1',
    },
    {
      label: 'Cr',
      openingSide: '2',
    },
  ];

  closingSideOptions = [
    {
      label: 'Dr',
      closingSide: '1',
    },
    {
      label: 'Cr',
      closingSide: '2',
    },
  ];

  getDrpfinancialYear() {
    this._trialBalanceService
      .getFinancialYearOptions()
      .pipe(takeUntil(this.notifier))
      .subscribe(res => {
        this.financialYearOptions.set(res.responseObject);
      });
  }

  selectedFinancialYearData(event) {
    event.value = event.value ? event.value : 0;
    this.config.loading = true;

    this._trialBalanceService
      .getLagderListbyFinancialyear(event.value)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.getTralBlanceTblData.set(res.responseObject);

        for (const item of res.responseObject) {
          this.OpeningBalanceVlaueArray.push(item.openingBalance ?? 0);
          this.ClosingBalanceVlaueArray.push(item.closingBalance ?? 0);

          this.OpeningBalanceOptionsArray.push(item.openingSide ?? '1');
          this.ClosingBalanceOptionsArray.push(item.closingSide ?? '1');
        }
      });
  }

  setClosingSideValue(value: any, i) {
    this.ClosingBalanceOptionsArray[i] = value;
  }

  setClosingBalanceValue(value: any, i) {
    this.ClosingBalanceVlaueArray[i] = value;
  }

  addUpdateTrialBalanceReportModal(type: number, data?: any) {
    let modalParams;
    if (data) {
      modalParams = cloneDeep(data);
    }
    const modalRef = this._dialogService.open(TrialBalanceReportModelComponent, {
      header: 'Trial Balance Report',
      width: '60%',
      data: { type, data: modalParams },
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '600px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      console.log('Modal closed with result:', result);
    });
  }

  submitTrialBalanceSearchForm() {
    const items = cloneDeep(this.getTralBlanceTblData());
    const payload = [];

    items.forEach((item, i) => {
      payload.push({
        id: this.trialBalanceSearchForm.value.financialYear,
        ledgerMapId: item.ledgerMapId,
        openingSide: this.OpeningBalanceOptionsArray[i],
        closingSide: this.ClosingBalanceOptionsArray[i],
        openingBalance: this.OpeningBalanceVlaueArray[i] ? this.OpeningBalanceVlaueArray[i] : 0,
        closingBalance: this.ClosingBalanceVlaueArray[i] ? this.ClosingBalanceVlaueArray[i] : 0,
      });
    });

    this.config.loading = true;
    this._trialBalanceService
      .updateTrialBalance(payload)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.getTralBlanceTblData.set(res.responseObject);
        this._toast.success(res.responseMessage);
      });
  }

  addFinancialYearModal(data?: any) {
    const modalRef = this._dialogService.open(AddFinancialYearModelComponent, {
      header: (data ? 'Edit' : 'Add') + ' Financial Year',
      width: '35%',
      data: { data: data },
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '600px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });
    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      console.log('Modal closed with result:', result);
      this.getDrpfinancialYear();
    });
  }

  addBalanceProcessModal(data?: any) {
    const modalRef = this._dialogService.open(BalanceProcessModelComponent, {
      header: 'Select Option',
      width: '45%',
      data: { data: data },
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '600px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });
    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      console.log('Modal closed with result:', result);
      this.getTralBlanceTblData.set(result);
    });
  }

  openTrialBalanceReportModel(data?: any) {
    const modalRef = this._dialogService.open(TrialBalanceReportModelComponent, {
      header: 'Trial Balance Report',
      width: '45%',
      data: { data: data },
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '600px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });
    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      console.log('Modal closed with result:', result);
    });
  }

  selectText(event: FocusEvent) {
    const inputElement = event.target as HTMLInputElement;
    inputElement.select();
  }
}
