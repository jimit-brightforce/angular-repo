import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrialBalanceReportModelComponent } from './trial-balance-report-model.component';

describe('TrialBalanceReportModelComponent', () => {
  let component: TrialBalanceReportModelComponent;
  let fixture: ComponentFixture<TrialBalanceReportModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TrialBalanceReportModelComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TrialBalanceReportModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
