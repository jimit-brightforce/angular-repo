import { Component, inject } from '@angular/core';
import { TrialBalanceReportFormData } from '../interface/trial-balance.interface';
import { UtilService } from '@services';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { TrialBalanceService } from '../service/trial-balance.service';
import { CalendarModule } from 'primeng/calendar';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';

@Component({
  selector: 'app-trial-balance-report-model',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, ButtonModule, CalendarModule, CheckboxModule],
  providers: [TrialBalanceService],
  templateUrl: './trial-balance-report-model.component.html',
  styleUrl: './trial-balance-report-model.component.scss',
})
export class TrialBalanceReportModelComponent {
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _trialBalanceService = inject(TrialBalanceService);
  private _utilService = inject(UtilService);
  private _dialogService = inject(DialogService);

  trialBalanceReportForm = this._trialBalanceService.getAddTrialBalanceReportForm();
  trialBalanceReportModalData: TrialBalanceReportFormData;
  trialBalanceReportModalType: number;

  constructor() {
    const modalRef = this._dialogService.getInstance(this._dynamicDialogRef);
    this.trialBalanceReportModalData = modalRef.data.data;
    this.trialBalanceReportModalType = modalRef.data.type;
    if (this.trialBalanceReportModalData) {
      this.patchValueIntoTrialBalanceReportForm();
    }
  }

  patchValueIntoTrialBalanceReportForm() {}

  closeModal(result: boolean) {
    this._dynamicDialogRef.close(result);
  }

  submitTrialBalanceReportForm() {
    this._utilService.markFormGroupDirty(this.trialBalanceReportForm);
    if (this.trialBalanceReportForm.valid) {
      const closeModalParams = this.trialBalanceReportForm.getRawValue();
      this._dynamicDialogRef.close(closeModalParams);
    }
  }
}
