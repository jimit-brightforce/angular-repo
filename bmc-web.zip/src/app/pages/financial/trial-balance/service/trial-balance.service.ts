import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { LstTrialBlance, drpFinancialYear } from '../interface/trial-balance.interface';

@Injectable()
export class TrialBalanceService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getTrialBalanceSearchForm() {
    return this._fb.group({
      financialYear: [''],
      balanceProcessOption: [''],
      id: [],
      ledgerName: [],
      ledgerCode: [],
      careProviderIDF: [],
      description: [],
      ledgerGroupId: [],
      ledgerGroupName: [],
      openingBalance: [],
      openingSide: [],
      closingBalance: [],
      closingSide: [],
      active: [false],
    });
  }

  getAddFinancialYearForm() {
    return this._fb.group({
      financialYear: ['', [Validators.required]],
    });
  }

  getAddBalanceProcessForm() {
    return this._fb.group({
      balanceProcessOption: [''],
    });
  }

  getLagderListbyFinancialyear(id: number) {
    return this._apiService.get<ListApiResponse<LstTrialBlance>>(
      `/v1/${API_FOLDER.financial}/ledger-map-balance/financial-year/${id}`
    );
  }

  getTrialBalancewithBalnceProcess(event) {
    return this._apiService.post<ListApiResponse<LstTrialBlance>>(
      `/v1/${API_FOLDER.financial}/ledger-map-balance/balance-process`,
      event
    );
  }

  getFinancialYearOptions() {
    return this._apiService.get<ListApiResponse<drpFinancialYear>>(
      `/v1/${API_FOLDER.financial}/ledger-map-balance/financial-year`
    );
  }

  FetchFinancialYearOptions() {
    return this._apiService.get<ListApiResponse<drpFinancialYear>>(
      `/v1/${API_FOLDER.financial}/ledger-map-balance/fetch-financial-year`
    );
  }

  updateTrialBalance(event) {
    return this._apiService.post<ListApiResponse<LstTrialBlance>>(
      `/v1/${API_FOLDER.financial}/ledger-map-balance/save-ledger-map-balance`,
      event
    );
  }

  saveFinancialYear(event) {
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.financial}/ledger-map-balance/save-care-financial-year`,
      event
    );
  }

  getBalanceProcessOptions() {
    return [
      {
        label: 'Only Opening Balance',
        value: 'O',
      },
      {
        label: 'Only Closing Balance',
        value: 'C',
      },
      {
        label: 'Both',
        value: 'B',
      },
    ];
  }

  getAddTrialBalanceReportForm() {
    return this._fb.group({
      fromDate: [''],
      toDate: [''],
      isStationary: [''],
    });
  }
}
