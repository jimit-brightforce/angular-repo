import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { PayerService } from './service/payer.service';
import { PayerData } from './interface/payer.interface';
import { PayerModalComponent } from './modal/payer-modal/payer-modal.component';
import { ActionPermissionDirective, PermissionMap } from '@directives';
import { SlugMap } from '@enums';

@Component({
  selector: 'app-payer',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule,
    ActionPermissionDirective
  ],
  templateUrl: './payer.component.html',
  styleUrl: './payer.component.scss',
  providers : [PayerService]
})
export class PayerComponent extends DestroyBehavior{

    @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _payerService = inject(PayerService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  protected readonly PermissionMap = PermissionMap;
  protected readonly SlugMap = SlugMap;

  payerTypeBody: FilterEvent;

  payerTableData = signal<PayerData[]>([]);

  payerForm = this._payerService.getPayerForm();
  payerModalData: PayerData;
  payerModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'payerName', header: 'Payer Name', sortable: true, selected: true },
      { field: 'payerCode', header: 'Payer Code', sortable: true, selected: true },
      { field: 'payerType', header: 'Payer Type', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['payerName'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.payerTypeBody = event;

    this._payerService
      .getPayer(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.payerTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditPayerModal( data?: PayerData) {
    const modalRef = this._dialogService.open(PayerModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' payer',
      width: '50%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {

        if (result.id) {
          this.filterEvent(this.payerTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deletePayer(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.payerName}</b>`, () => {
      this._payerService.deletePayer(row.id).subscribe({
        next: res => {
          this.filterEvent(this.payerTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
