import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators} from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { PayerData } from '../interface/payer.interface';

@Injectable()
export class PayerService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getPayer(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<PayerData>>(
      `/v1/${API_FOLDER.masters}/payer/page`,
      payload
    );
  }

  getMetaforPayerDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<PayerData>>(
      `/v1/${API_FOLDER.masters}/payer-type/page`,
      payload
    );
  }

  addUpdatePayer(payload: PayerData) {
    if (payload.id) {
      return this._apiService.post<ListApiResponse<PayerData>>(
        `/v1/${API_FOLDER.masters}/payer`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<PayerData>>(
      `/v1/${API_FOLDER.masters}/payer`,
      payload
    );
  }

  deletePayer(id: number) {
    return this._apiService.delete<ListApiResponse<PayerData>>(
      `/v1/${API_FOLDER.masters}/payer/${id}`
    );
  }

  getPayerForm() {
    return this._fb.group({
        payerName: ['', Validators.required],
        payerCode: ['', Validators.required],
        payerTypeIDF: [null as number, Validators.required],
        remarks: ['', Validators.required],
    });
  }
}
