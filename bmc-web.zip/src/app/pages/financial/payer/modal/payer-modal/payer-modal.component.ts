import { Component, OnInit, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive'
import { PayerService } from '../../service/payer.service';
import { PayerData } from '../../interface/payer.interface';
import { InputTextareaModule } from 'primeng/inputtextarea';

@Component({
  selector: 'app-payer-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    InputTextareaModule,
    FloatLabelModule,
    NgxTrimDirectiveModule,
  ],
  templateUrl: './payer-modal.component.html',
  styleUrl: './payer-modal.component.scss',
  providers : [PayerService]
})
export class PayerModalComponent extends DestroyBehavior implements OnInit{

    private _payerService = inject(PayerService);
    private _dynamicDialogRef = inject(DynamicDialogRef);
    private _dialogService = inject(DialogService);
    private _utilService = inject(UtilService);
    private _toast = inject(ToastService);

    payerDropdown = signal<PayerData[]>([]);

    isLoading = signal<boolean>(false);
    payerForm = this._payerService.getPayerForm();
    payerModalData: PayerData = this._dialogService.getInstance(this._dynamicDialogRef).data;
    payerModalType: number;

    constructor() {
      super();
      if (this.payerModalData) {
        this.patchValueIntopayerForm();
      }
    }

    patchValueIntopayerForm() {
      this.payerForm.patchValue({
        ...this.payerModalData,
      });
    }

    ngOnInit(): void {
      this.getPayerTableData();
    }

    getPayerTableData(searchKey: string = '') {
      const param: FilterEvent = {
        page: 0,
        size: 15,
        searchKey: searchKey ?? null,
      };
      this._payerService.getMetaforPayerDropDown(param).subscribe({
        next: res => {
          this.payerDropdown.set(res.responseObject);
        },
      });
    }

    submitPayerForm() {
      this._utilService.markFormGroupDirty(this.payerForm);
      if (this.payerForm.valid) {
        const data = {
          id : this.payerModalData?.id,
          payerName : this.payerForm.value.payerName,
          payerCode : this.payerForm.value.payerCode,
          payerTypeIDF : this.payerForm.value.payerTypeIDF,
          remarks : this.payerForm.value.remarks,

        };

        this.isLoading.set(true);
        this._payerService
          .addUpdatePayer(data as any)
          .pipe(
            takeUntil(this.notifier),
            finalize(() => this.isLoading.set(false))
          )
          .subscribe(res => {
            this._toast.success(res.responseMessage);
            this._dynamicDialogRef.close({
              closeModalType: this.payerModalType,
              data: res.responseObject,
            });
          });
      }
    }
}
