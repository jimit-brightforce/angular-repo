
export interface PayerData {
    id?: number;
    payerName: string;
    payerCode: string;
    remarks: string;
    payerTypeIDF: number;
    payerType: string;

}
