/* eslint-disable no-cond-assign */
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, inject, OnInit, signal } from '@angular/core';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { PickListModule } from 'primeng/picklist';
import { ButtonModule } from 'primeng/button';
import { FilterPipe } from 'src/app/shared/pipe/filter.pipe';
import { VoucherUserMapService } from '../../services/voucher-user-map.service';
import { PanelModule } from 'primeng/panel';
import { CheckboxModule } from 'primeng/checkbox';
import { VoucherUserMapData } from '../../interface/voucherUserMap.interface';
import { DestroyBehavior } from '@strategies';
import { finalize, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import { ToastService, UtilService } from '@services';
import { TableModule } from 'primeng/table';

@Component({
  selector: 'app-voucher-user-map-modal',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AppDropdownComponent,
    PickListModule,
    InputTextModule,
    ButtonModule,
    FilterPipe,
    PanelModule,
    CheckboxModule,
    TableModule,

  ],
  providers: [VoucherUserMapService],
  templateUrl: './voucher-user-map-modal.component.html',
  styleUrl: './voucher-user-map-modal.component.scss',
})
export class VoucherUserMapModalComponent extends DestroyBehavior implements OnInit {
  private _voucherUserMapService = inject(VoucherUserMapService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _toast = inject(ToastService);
  private _utilService = inject(UtilService);

  logInDropdownOptions = signal<VoucherUserMapData[]>([]);
  listArray: any[] = [];
  isLoading = signal<boolean>(false);
  selectedUserId: number;
  searchString: string = '';
  voucherUserMapForm = this._voucherUserMapService.getVoucherUserMapForm();
  voucherUserMapModalData: VoucherUserMapData;
  checked:boolean=false;
  selectAll :boolean = false

  getVoucherUserMapDropDown(searchKey = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'userName',
        order: 'asc',
      },
    };
    this._voucherUserMapService.getMetaforLogInDropDown(param).subscribe({
      next: res => {
        this.logInDropdownOptions.set(res.responseObject);
      },
    });
  }

  toggleAllCheckboxes() {
    this.listArray.forEach(list => {
      list.selected = this.selectAll;
    });
  }

  checkSelectAll() {
    this.selectAll = this.listArray.every(list => list.selected);
  }
  ngOnInit(): void {
    this.getVoucherUserMapDropDown();
  }

  onUserNameChange(eve) {
      eve = eve ? eve : 0;
    this.selectedUserId = eve;
    this._voucherUserMapService
      .getOptionsfromLogInDropDown(eve)
      .pipe(takeUntil(this.notifier))
      .subscribe(res => {
        //  this.listArray = res.responseObject.map(obj => ({ ...obj, selected: false }));
        this.listArray = res.responseObject;
      });
  }

  getFormVal(formControlName: string) {
    return this.voucherUserMapForm.value[formControlName];
  }

  onServiceChange(value) {
    value.selected = !value.selected;
  }

  submitVoucherUserMapForm() {
    const selectedService = this.listArray
      .filter(service => service.selected)
      .map(obj => ({ id: obj.id.toString() }));

    this._utilService.markFormGroupDirty(this.voucherUserMapForm);

    if (!selectedService.length) {
      this._toast.error('Select at least one service');
      return;
    }
    if (this.voucherUserMapForm.valid) {
      const data = {
        userLoginIDF: this.selectedUserId,
        voucherTypeDtos: selectedService,
      };
      this.isLoading.set(true);
      this._voucherUserMapService
        .addDatatoTABLE(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(res.responseObject);
        });
    }
  }

  resetSelection() {
    this.listArray = this.listArray.map(item => {
      item.selected = false;
      return item;
    });
  }
}
