import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoucherUserMapModalComponent } from './voucher-user-map-modal.component';

describe('VoucherUserMapModalComponent', () => {
  let component: VoucherUserMapModalComponent;
  let fixture: ComponentFixture<VoucherUserMapModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VoucherUserMapModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(VoucherUserMapModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
