import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { VoucherUserMapData } from '../interface/voucherUserMap.interface';

@Injectable()
export class VoucherUserMapService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getVoucherUserMaplist() {
    return this._apiService.get<ListApiResponse<VoucherUserMapData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/voucher-user-map/userMapList`
    );
  }

  getVoucherUserMaplistContent(id: number) {
    return this._apiService.get<ListApiResponse<VoucherUserMapData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/voucher-user-map/userVoucherTypeList/${id}`
    );
  }

  getMetaforLogInDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<VoucherUserMapData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/user-login/page`,
      payload
    );
  }

  getOptionsfromLogInDropDown(id: number) {
    return this._apiService.get<ListApiResponse<VoucherUserMapData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/voucher-user-map/getVoucherTypeForUserVoucherMap/${id}`
    );
  }

  addDatatoTABLE(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<VoucherUserMapData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/voucher-user-map`,
      payload
    );
  }

  deleteVoucherUserMap(id: number) {
    return this._apiService.delete<ListApiResponse<VoucherUserMapData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/voucher-user-map/${id}`
    );
  }

  getVoucherUserMapForm() {
    return this._fb.group({
      name: ['', [Validators.required]],
      searchString: [],
    });
  }
}
