import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoucherUserMapComponent } from './voucher-user-map.component';

describe('VoucherUserMapComponent', () => {
  let component: VoucherUserMapComponent;
  let fixture: ComponentFixture<VoucherUserMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VoucherUserMapComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(VoucherUserMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
