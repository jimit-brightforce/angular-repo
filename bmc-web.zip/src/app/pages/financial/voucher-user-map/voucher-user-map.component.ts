import { Component, inject, OnInit, signal } from '@angular/core';

import { DialogService } from 'primeng/dynamicdialog';
import { ButtonModule } from 'primeng/button';
import { AppDialogService, DeleteMessagePrefix, ToastService } from '@services';

import { VoucherUserMapModalComponent } from './modal/voucher-user-map-modal/voucher-user-map-modal.component';
import { takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { VoucherUserMapService } from './services/voucher-user-map.service';
import { InputTextModule } from 'primeng/inputtext';
import { AccordionModule } from 'primeng/accordion';
import { ChipModule } from 'primeng/chip';
import { CommonModule } from '@angular/common';
import { VoucherUserMapData } from './interface/voucherUserMap.interface';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from 'src/app/shared/pipe/filter.pipe';
import { ActionPermissionDirective, PermissionMap } from '@directives';
import { SlugMap } from '@enums';

@Component({
  selector: 'app-voucher-user-map',
  standalone: true,
  imports: [
    ButtonModule,
    InputTextModule,
    AccordionModule,
    ChipModule,
    CommonModule,
    FormsModule,
    FilterPipe,
    ActionPermissionDirective
  ],
  providers: [DialogService, VoucherUserMapService],
  templateUrl: './voucher-user-map.component.html',
  styleUrl: './voucher-user-map.component.scss',
})
export class VoucherUserMapComponent extends DestroyBehavior implements OnInit {
  private _dialogService = inject(DialogService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);
  private _voucherUserMapService = inject(VoucherUserMapService);

  protected readonly PermissionMap = PermissionMap;
  protected readonly SlugMap = SlugMap;

  voucherUserMapForm = this._voucherUserMapService.getVoucherUserMapForm();

  voucherUserMapList = signal<VoucherUserMapData[]>([]);
  selectedUser = signal<VoucherUserMapData[]>([]);
  isLoading = signal<boolean>(false);
  searchString: string = '';

  ngOnInit(): void {
    this.getVoucherUser();
  }

  openVoucherUserMapModal(data) {
    const addUpdateModalRef = this._dialogService.open(VoucherUserMapModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Voucher User Map',
      width: '70%',
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '700px', overflow: 'auto', Overlay: true },
    });

    addUpdateModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        this.getVoucherUser();
      }
    });
  }

  getVoucherUser() {
    this._voucherUserMapService
      .getVoucherUserMaplist()
      .pipe(takeUntil(this.notifier))
      .subscribe(res => {
        this.voucherUserMapList.set(res.responseObject);
        if (this.voucherUserMapList().length) {
          this.selectItem(res.responseObject[0]);
        }
      });
  }

  onItemDelete(row) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `${row.voucherTypeName}`, () => {
      this._voucherUserMapService.deleteVoucherUserMap(row.id).subscribe({
        next: res => {
          if (res) {
            if (res.responseObject) {
              this.selectedUser.update(data => {
                return data.filter(r => r.id !== row.id);
              });
            }
          }
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  searchClear() {
    this.searchString = '';
  }

  selectItem(data) {
    this._voucherUserMapService
      .getVoucherUserMaplistContent(data.id)
      .pipe(takeUntil(this.notifier))
      .subscribe(res => {
        this.selectedUser.set(res.responseObject);
      });
  }
}
