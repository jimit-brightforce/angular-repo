export interface VoucherUserMapData {
  id?: number;
  userLoginIDF?: number;
  userName?: string;
  voucherTypeIDF?: number;
  voucherTypeName?: string;
  voucherTypeDtos?: any;
}
