/* eslint-disable @typescript-eslint/no-unused-vars */
import { Component, ViewChild, inject } from '@angular/core';
import { TableColumnDirective, TableComponent, TableConfig, TableExpandableRowDirective } from '@components';
import { ButtonModule } from 'primeng/button';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { AppDialogService, DeleteMessagePrefix, ToastService } from '@services';
import { AddVoucherMapComponent } from './modal/add-voucher-map/add-voucher-map.component';
import { DialogService } from 'primeng/dynamicdialog';
import { TagModule } from 'primeng/tag';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-voucher-map',
  standalone: true,
  imports: [
    TableComponent,
    TableColumnDirective,
    ButtonModule,
    OverlayPanelModule,
    TableExpandableRowDirective,
    TagModule
  ],
  providers:[DialogService],
  templateUrl: './voucher-map.component.html',
  styleUrl: './voucher-map.component.scss'
})
export class VoucherMapComponent extends  DestroyBehavior{
  private _dialogService = inject(DialogService);
  private _appDialog = inject(AppDialogService);

  @ViewChild(TableComponent) _table: TableComponent;

  
  config: TableConfig = {
    columns: [
      { field: 'vouchermap', header: 'Voucher Map', sortable: true, selected: true },
      { field: 'vouchertype', header: 'Voucher Type', sortable: true, selected: true },
      { field: 'voucate', header: 'Voucher Category', sortable: true, selected: true },
      { field: 'defa', header: 'Default Ledger', sortable: true, selected: true },
      { field: 'defrounding', header: 'Default Rounding Ledger', sortable: true, selected: true },
      { field: 'defdiscount', header: 'Default Discount Ledger', sortable: true, selected: true },
      { field: 'description', header: 'Description', sortable: true, selected: true },
    ],
    lazy: true,
    showIndex: true,
    loading: true,
    showColumnFilter:false
  };
  Tabledata=[
    {
      id: 1,
      vouchermap: 'Voucher001',
      vouchertype: 'voucher',
      voucate: 'Supplier A',
      defa: 'Godown 1',
      defrounding:'cash-tag',
      defdiscount:'22122',
      description:'10101',
      isAuto:true,
      toPrint:false
    }
  ]
  addUpdateVoucherMap(data?:any) {
    const addUpdateDetailsModalRef = this._dialogService.open(AddVoucherMapComponent, {
      header: 'Add Voucher Map',
      width: '60%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '600px', overflow: 'auto', Overlay: true },
      // focusOnShow: true,
    });  
  }

  deletePayerInfo(row) {
    this._appDialog.confirmDelete('Are you sure you want to delete Credit Note?', () => {
      this.Tabledata = this.Tabledata.filter(res=>res);
    });
  }
}
