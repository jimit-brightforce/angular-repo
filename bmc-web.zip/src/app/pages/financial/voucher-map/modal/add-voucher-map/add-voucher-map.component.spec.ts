import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddVoucherMapComponent } from './add-voucher-map.component';

describe('AddVoucherMapComponent', () => {
  let component: AddVoucherMapComponent;
  let fixture: ComponentFixture<AddVoucherMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddVoucherMapComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddVoucherMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
