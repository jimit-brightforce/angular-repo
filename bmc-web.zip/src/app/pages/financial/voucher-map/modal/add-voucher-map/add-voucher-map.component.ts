import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppDropdownComponent } from '@components';
import { AutoFocusModule } from 'primeng/autofocus';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';

@Component({
  selector: 'app-add-voucher-map',
  standalone: true,
  imports: [
    ButtonModule,
    CheckboxModule,
    DropdownModule,
    FloatLabelModule,
    MultiSelectModule,
    AppDropdownComponent,
    InputTextModule,
    CommonModule,
    FormsModule,
    AutoFocusModule
  ],
  templateUrl: './add-voucher-map.component.html',
  styleUrl: './add-voucher-map.component.scss'
})
export class AddVoucherMapComponent {
  isradiocheck: boolean = false

  categoryOptions = [
    { id: 1, label: 'Cardiogram' },
    { id: 2, label: 'Option 2' },
    { id: 3, label: 'Option 3' },
    { id: 4, label: 'Option 4' },
    { id: 5, label: 'Option 5' }
  ];
}
