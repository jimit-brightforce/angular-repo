import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoucherMapComponent } from './voucher-map.component';

describe('VoucherMapComponent', () => {
  let component: VoucherMapComponent;
  let fixture: ComponentFixture<VoucherMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VoucherMapComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VoucherMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
