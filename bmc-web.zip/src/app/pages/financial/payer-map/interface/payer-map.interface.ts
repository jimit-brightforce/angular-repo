export interface PayerMapData {
  payerMapIDP: number | string;
  id: number | string;
  payerName: string;
  payerCode: string;
  careProviderIDF: number;
  payerFinanceLink: boolean;
  active: boolean;
  payer: PayerData;
  ledgerMap: LedgerData;
}

export interface LedgerData {
  id: number | string;
  ledgerMapIDP: number | string;
  ledgerName: string;
  ledgerCode: string;
  isActive: boolean;
  careProviderIDF: number;
  description: string;
}

export interface PayerData {
  payerCode: string;
  id: number | string;
  payerIDP: number | string;
  payerName: string;
  remarks: string;
}
