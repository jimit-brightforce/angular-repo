import { Component, ViewChild, inject, signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { MessageService } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { TagModule } from 'primeng/tag';
import { TableModule } from 'primeng/table';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { TooltipModule } from 'primeng/tooltip';

import { finalize, takeUntil } from 'rxjs';

import { AddEditPayerMapComponent } from './modal/add-edit-payer-map/add-edit-payer-map.component';
import { FilterEvent, TableColumnDirective, TableComponent, TableConfig } from '@components';
import { AppDialogService, ToastService } from '@services';
import { DestroyBehavior } from '@strategies';
import { PayerMapData } from './interface/payer-map.interface';
import { PayerMapService } from './services/payer-map.sevice';
import { ActionPermissionDirective, PermissionMap } from '@directives';
import { SlugMap } from '@enums';

@Component({
  selector: 'app-payer-map',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    FormsModule,
    ButtonModule,
    TableModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule,
    TooltipModule,
    ActionPermissionDirective
  ],
  templateUrl: './payer-map.component.html',
  styleUrl: './payer-map.component.scss',
  providers: [PayerMapService, MessageService, DialogService],
})
export class PayerMapComponent extends DestroyBehavior {
  @ViewChild(TableComponent) _table: TableComponent;
  private _dialogService = inject(DialogService);
  private _payerMapService = inject(PayerMapService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);

  protected readonly PermissionMap = PermissionMap;
  protected readonly SlugMap = SlugMap;

  visible: boolean = false;
  isShowAddForm: boolean = false;

  payerMapForm = this._payerMapService.getPayerMapForm();
  payerMapFormModalData: PayerMapData;
  payerMapFormModalType: number;

  payerMapData = signal<PayerMapData[]>([]);
  payerMapBody: FilterEvent;

  addEditPayerMapModal(type: number, data?: PayerMapData) {
    const modalRef = this._dialogService.open(AddEditPayerMapComponent, {
      header: (data ? 'Edit' : 'Add') + ' Payer Map',
      width: '40%',
      data: { type, data },
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result.payerMapIDP) {
        this.filterEvent(this.payerMapBody);
      } else {
        this._table.table.reset();
      }
    });
  }

  config: TableConfig = {
    columns: [{ field: 'payerCode', header: 'Payer Code', sortable: true, selected: true }],
    // lazy: false,
    globalFilterFields: ['payerName', 'payerCode'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.payerMapBody = event;

    this._payerMapService
      .getPayerMapList(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.payerMapData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deletePayerMap(row: PayerMapData) {
    this._appDialog.confirmDelete(`Are you sure you want to delete ${row.payerName}?`, () => {
      this._payerMapService.deletePayerMapList(row.payerMapIDP as number).subscribe({
        next: res => {
          this.filterEvent(this.payerMapBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
