import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditPayerMapComponent } from './add-edit-payer-map.component';

describe('AddEditPayerMapComponent', () => {
  let component: AddEditPayerMapComponent;
  let fixture: ComponentFixture<AddEditPayerMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddEditPayerMapComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditPayerMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
