import { Component, inject, signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { DividerModule } from 'primeng/divider';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { PayerMapService } from '../../services/payer-map.sevice';
import { LedgerData, PayerData, PayerMapData } from '../../interface/payer-map.interface';
import { AuthService, ToastService, UtilService } from '@services';
import { FloatLabelModule } from 'primeng/floatlabel';
import { finalize, map, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { InputTrimDirective } from '@directives';

@Component({
  selector: 'app-add-edit-payer-map',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    FormsModule,
    CheckboxModule,
    DropdownModule,
    DividerModule,
    ButtonModule,
    TableModule,
    ToastModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    InputTrimDirective,
  ],
  templateUrl: './add-edit-payer-map.component.html',
  styleUrl: './add-edit-payer-map.component.scss',
})
export class AddEditPayerMapComponent extends DestroyBehavior {
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _payerMapService = inject(PayerMapService);
  private _utilService = inject(UtilService);
  private _authService = inject(AuthService);
  private _toast = inject(ToastService);

  payerMapForm = this._payerMapService.getPayerMapForm();
  payerMapModalData: PayerMapData;
  payerMapModalType: number;
  payerDropdownOptions = signal<PayerData[]>([]);
  ledgerDropdownOptions = signal<LedgerData[]>([]);
  isLoading = signal<boolean>(false);

  constructor() {
    super();
    const modalRef = this._dialogService.getInstance(this._dynamicDialogRef);
    this.payerMapModalData = modalRef.data.data;
    this.payerMapModalType = modalRef.data.type;
    if (this.payerMapModalData) {
      this.patchValueIntoPlayerMapForm();
      // this.getPayerMapDropdownData(this.payerMapModalData.payer?.payerName);
      this.getLedgerMapDropdownData(this.payerMapModalData.ledgerMap?.ledgerName);
      this.payerDropdownOptions.set([
        {
          payerCode: this.payerMapModalData.payer.payerCode,
          id: this.payerMapModalData.payer.payerIDP,
          payerIDP: this.payerMapModalData.payer.id,
          payerName: this.payerMapModalData.payer.payerName,
          remarks: '',
        },
      ]);
    }
  }

  getPayerMapDropdownData(searchKey: string = '') {
    const param: FilterEvent = {
      isActive: true,
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'payerName',
        order: 'asc',
      },
    };
    this._payerMapService
      .getUnmappedPayerData(param)
      .pipe(map(res => this.payerDropdownOptions.set(res.responseObject)))
      .subscribe();
  }

  getLedgerMapDropdownData(searchKey: string = '') {
    const param: FilterEvent = {
      isActive: true,
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'ledgerName',
        order: 'asc',
      },
    };
    this._payerMapService
      .getLedgerMapData(param)
      .pipe(map(res => this.ledgerDropdownOptions.set(res.responseObject)))
      .subscribe();
  }

  patchValueIntoPlayerMapForm() {
    this.payerMapForm.patchValue({
      payer: this.payerMapModalData.payer?.id as string,
      payerName: this.payerMapModalData.payerName,
      payerCode: this.payerMapModalData.payerCode,
      payerFinanceLink: this.payerMapModalData.payerFinanceLink,
      active: this.payerMapModalData.active,
      ledger: this.payerMapModalData.ledgerMap?.id as string,
    });
  }

  closeModal(result: boolean) {
    this._dynamicDialogRef.close(result);
  }

  submitpayerMapForm() {
    this._utilService.markFormGroupDirty(this.payerMapForm);
    if (this.payerMapForm.valid) {
      const formVal = this.payerMapForm.value;
      const data = {
        payerMapIDP: this.payerMapModalData?.payerMapIDP,
        payerName: formVal.payerName,
        payerCode: formVal.payerCode,
        careProviderIDF: this._authService.userInfo().careProviderIDP,
        payerFinanceLink: formVal.payerFinanceLink,
        active: formVal.active,
        payer: {
          id: formVal.payer,
        },
        ledgerMap: {
          id: formVal.ledger,
        },
      };
      this.isLoading.set(true);
      this._payerMapService
        .addUpdatePayerMap(data)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }

  preFillFields(data) {
    this.payerMapForm.patchValue({
      payerName: data.item.payerName,
      payerCode: data.item.payerCode,
    });
  }
}
