import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { LedgerData, PayerData, PayerMapData } from '../interface/payer-map.interface';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';

@Injectable()
export class PayerMapService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getPayerMapForm() {
    return this._fb.group({
      payer: ['', Validators.required],
      payerName: ['', Validators.required],
      payerCode: [''],
      ledger: ['', Validators.required],
      payerFinanceLink: [true],
      active: [true],
    });
  }

  getPayerMapList(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<PayerMapData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer-map/page`,
      payload
    );
  }

  addUpdatePayerMap(payload) {
    if (payload.payerMapIDP) {
      return this._apiService.put<ListApiResponse<any>>(
        `/v1/${API_FOLDER.serviceConfiguration}/payer-map`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer-map`,
      payload
    );
  }

  deletePayerMapList(payerMapIDP: number) {
    return this._apiService.delete<ListApiResponse<any>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer-map/${payerMapIDP}`
    );
  }

  getPayerData(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<PayerData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer/page`,
      payload
    );
  }

  getUnmappedPayerData(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<PayerData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/payer/unmappedPayer`,
      payload
    );
  }

  getLedgerMapData(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<LedgerData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/ledger-map/page`,
      payload
    );
  }
}
