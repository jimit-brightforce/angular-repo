import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoucherCategoryComponent } from './voucher-category.component';

describe('VoucherCategoryComponent', () => {
  let component: VoucherCategoryComponent;
  let fixture: ComponentFixture<VoucherCategoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VoucherCategoryComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(VoucherCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
