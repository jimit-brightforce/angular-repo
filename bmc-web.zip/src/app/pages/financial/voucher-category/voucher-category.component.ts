import { Component, ViewChild, inject, signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { MessageService } from 'primeng/api';
import { PanelModule } from 'primeng/panel';
import { DialogService } from 'primeng/dynamicdialog';
import { TagModule } from 'primeng/tag';
import { TableModule } from 'primeng/table';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { TooltipModule } from 'primeng/tooltip';

import { finalize, takeUntil } from 'rxjs';

import { AddEditVoucherCategoryComponent } from './modal/voucher-category-modal/voucher-category-modal.component';
import { FilterEvent, TableColumnDirective, TableComponent, TableConfig } from '@components';
import { AppDialogService, DeleteMessagePrefix, ToastService } from '@services';
import { DestroyBehavior } from '@strategies';
import { VoucherCategoryData } from './interface/voucher-category.interface';
import { VoucherCategoryService } from './services/voucher-category.sevice';

@Component({
  selector: 'app-voucher-category',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    FormsModule,
    ButtonModule,
    PanelModule,
    TableModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule,
    TooltipModule,
  ],
  templateUrl: './voucher-category.component.html',
  styleUrl: './voucher-category.component.scss',
  providers: [VoucherCategoryService, MessageService, DialogService],
})
export class VoucherCategoryComponent extends DestroyBehavior {
  @ViewChild(TableComponent) _table: TableComponent;
  private _dialogService = inject(DialogService);
  private _voucherCategoryService = inject(VoucherCategoryService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);

  visible: boolean = false;
  isShowAddForm: boolean = false;

  voucherCategoryForm = this._voucherCategoryService.getVoucherCategoryForm();
  voucherCategoryFormModalData: VoucherCategoryData;
  voucherCategoryFormModalType: number;

  voucherCategoryData = signal<VoucherCategoryData[]>([]);
  voucherCategoryBody: FilterEvent;

  addEditVoucherCategoryModal(type: number, data?: VoucherCategoryData) {
    const modalRef = this._dialogService.open(AddEditVoucherCategoryComponent, {
      header: (data ? 'Edit' : 'Add') + ' Voucher Category',
      width: '40%',
      data: { type, data },
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result.id) {
        this.filterEvent(this.voucherCategoryBody);
      } else {
        this._table.table.reset();
      }
    });
  }

  config: TableConfig = {
    columns: [
      { field: 'voucherCategory', header: 'Voucher Category', sortable: true, selected: true },
      { field: 'description', header: 'Description', sortable: true, selected: true },
    ],
    // lazy: false,
    globalFilterFields: ['voucherCategory'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.voucherCategoryBody = event;

    this._voucherCategoryService
      .getVoucherCategoryList(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.voucherCategoryData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteVoucherCategory(row: VoucherCategoryData) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Voucher Category?', () => {
      this._voucherCategoryService.deleteVoucherCategoryList(row.id as number).subscribe({
        next: res => {
          this.filterEvent(this.voucherCategoryBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
