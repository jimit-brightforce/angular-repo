import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditVoucherCategoryComponent } from './voucher-category-modal.component';

describe('AddEditVoucherCategoryComponent', () => {
  let component: AddEditVoucherCategoryComponent;
  let fixture: ComponentFixture<AddEditVoucherCategoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddEditVoucherCategoryComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AddEditVoucherCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
