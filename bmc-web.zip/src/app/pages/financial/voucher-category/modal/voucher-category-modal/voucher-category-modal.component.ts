import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { AppDropdownComponent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { VoucherCategoryService } from '../../services/voucher-category.sevice';
import { VoucherCategoryData } from '../../interface/voucher-category.interface';
import { ToastService, UtilService } from '@services';
import { FloatLabelModule } from 'primeng/floatlabel';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { InputTrimDirective } from '@directives';

@Component({
  selector: 'app-voucher-category',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    CheckboxModule,
    DropdownModule,
    ButtonModule,
    ToastModule,
    AppDropdownComponent,
    FloatLabelModule,
    InputTrimDirective,
  ],
  templateUrl: './voucher-category-modal.component.html',
  styleUrl: './voucher-category-modal.component.scss',
})
export class AddEditVoucherCategoryComponent extends DestroyBehavior {
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _voucherCategoryService = inject(VoucherCategoryService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  voucherCategoryForm = this._voucherCategoryService.getVoucherCategoryForm();
  voucherCategoryModalData: VoucherCategoryData;
  voucherCategoryModalType: number;
  isLoading = signal<boolean>(false);

  constructor() {
    super();
    const modalRef = this._dialogService.getInstance(this._dynamicDialogRef);
    this.voucherCategoryModalData = modalRef.data.data;
    this.voucherCategoryModalType = modalRef.data.type;
    if (this.voucherCategoryModalData) {
      this.patchValueIntoPlayerMapForm();
    }
  }

  patchValueIntoPlayerMapForm() {
    this.voucherCategoryForm.patchValue({
      voucherCategory: this.voucherCategoryModalData.voucherCategory,
      description: this.voucherCategoryModalData.description,
    });
  }

  closeModal(result: boolean) {
    this._dynamicDialogRef.close(result);
  }

  submitVoucherCategoryForm() {
    this._utilService.markFormGroupDirty(this.voucherCategoryForm);
    if (this.voucherCategoryForm.valid) {
      const formVal = this.voucherCategoryForm.value;
      const data = {
        ...formVal,
        id: this.voucherCategoryModalData?.id,
      };
      this.isLoading.set(true);
      this._voucherCategoryService
        .addUpdateVoucherCategory(data)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
