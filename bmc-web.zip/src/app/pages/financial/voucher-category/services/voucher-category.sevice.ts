import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { VoucherCategoryData } from '../interface/voucher-category.interface';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';

@Injectable()
export class VoucherCategoryService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getVoucherCategoryForm() {
    return this._fb.group({
      voucherCategory: ['', Validators.required],
      description: [''],
    });
  }

  getVoucherCategoryList(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<VoucherCategoryData>>(
      `/v1/${API_FOLDER.masters}/voucher-category/page`,
      payload
    );
  }

  addUpdateVoucherCategory(payload) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<any>>(
        `/v1/${API_FOLDER.masters}/voucher-category`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/voucher-category`,
      payload
    );
  }

  deleteVoucherCategoryList(id: number) {
    return this._apiService.delete<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/voucher-category/${id}`
    );
  }
}
