export interface VoucherCategoryData {
  id: number;
  voucherCategory: string;
  description: string;
}
