import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { DiscountTypeData } from '../interface/discount-type.interface';


@Injectable()
export class DiscountTypeService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getDiscountType(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<DiscountTypeData>>(
      `/v1/${API_FOLDER.masters}/discountType/page`,
      payload
    );
  }

  getMetaforDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<DiscountTypeData>>(
      `/v1/${API_FOLDER.serviceConfiguration}/discountType/page`,
      payload
    );
  }

  addUpdateDiscountType(payload: DiscountTypeData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<DiscountTypeData>>(
        `/v1/${API_FOLDER.masters}/discountType`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<DiscountTypeData>>(
      `/v1/${API_FOLDER.masters}/discountType`,
      payload
    );
  }

  deleteDiscountType(id: number) {
    return this._apiService.delete<ListApiResponse<DiscountTypeData>>(
      `/v1/${API_FOLDER.masters}/discountType/${id}`
    );
  }

  getDiscountTypeForm() {
    return this._fb.group({
        discountType: ['', Validators.required],
        discountLedger: ['', Validators.required],
        rate: ['', Validators.required],
    });
  }
}
