
export interface DiscountTypeData {
    id ?: number;
    discountType : string;
    discountLedger : string;
    rate : string;
}
