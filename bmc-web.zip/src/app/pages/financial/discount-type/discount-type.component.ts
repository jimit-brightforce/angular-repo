import { Component, ViewChild, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { DeleteMessagePrefix, ToastService } from '@services';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { AppDialogService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DiscountTypeService } from './service/discount-type.service';
import { DiscountTypeData } from './interface/discount-type.interface';
import { DiscountTypeModalComponent } from './modal/discount-type-modal/discount-type-modal.component';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-discount-type',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './discount-type.component.html',
  styleUrl: './discount-type.component.scss',
  providers : [DiscountTypeService]
})
export class DiscountTypeComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _discountTypeService = inject(DiscountTypeService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);
  discountTypeBody: FilterEvent;

  discountTypeTableData = signal<DiscountTypeData[]>([]);

  discountTypeForm = this._discountTypeService.getDiscountTypeForm();
  discountTypeModalData: DiscountTypeData;
  discountTypeModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'discountType', header: 'Discount Type', sortable: true, selected: true },
      { field: 'discountTypeCode', header: 'Discount Type Code', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['discountType'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.discountTypeBody = event;

    this._discountTypeService
      .getDiscountType(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.discountTypeTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteDiscountType(row) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + 'Discount Type?', () => {
      this._discountTypeService.deleteDiscountType(row.id).subscribe({
        next: res => {
          this.filterEvent(this.discountTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  addEditDiscountTypeModal(data?: DiscountTypeData) {
    const addEditdiscountTypeModalRef = this._dialogService.open(DiscountTypeModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Discount Type',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    addEditdiscountTypeModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.discountTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }
}
