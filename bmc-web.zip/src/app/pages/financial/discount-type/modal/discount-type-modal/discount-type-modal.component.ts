import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { DiscountTypeService } from '../../service/discount-type.service';
import { DiscountTypeData } from '../../interface/discount-type.interface';
import { AppDropdownComponent, FilterEvent } from '@components';

@Component({
  selector: 'app-discount-type-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    FloatLabelModule,
    AppDropdownComponent,
    NgxTrimDirectiveModule,
    CheckboxModule,
  ],
  templateUrl: './discount-type-modal.component.html',
  styleUrl: './discount-type-modal.component.scss',
  providers : [DiscountTypeService]
})
export class DiscountTypeModalComponent extends DestroyBehavior{

  private _discountTypeService = inject(DiscountTypeService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);
  discountTypeForm = this._discountTypeService.getDiscountTypeForm();
  discountTypeModalData: DiscountTypeData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  discountTypeModalType: number;
  discountTypeDropdown = signal<DiscountTypeData[]>([]);

  constructor() {
    super();
    if (this.discountTypeModalData) {
      this.patchValueIntoDiscountTypeForm();
    }
  }

  patchValueIntoDiscountTypeForm() {
    this.discountTypeForm.patchValue({
      ...this.discountTypeModalData,
    });
  }

  getDiscountTypeTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'id',
        order: 'asc',
      },
    };
    this._discountTypeService.getMetaforDropDown(param).subscribe({
      next: res => {
        this.discountTypeDropdown.set(res.responseObject);
      },
    });
  }

  submitDiscountTypeForm() {
    this._utilService.markFormGroupDirty(this.discountTypeForm);
    if (this.discountTypeForm.valid) {
      const data = {
        id : this.discountTypeModalData?.id,
        discountType : this.discountTypeForm.value.discountType,
        discountLedger : this.discountTypeForm.value.discountLedger,
        rate : this.discountTypeForm.value.rate,

      };

      this.isLoading.set(true);
      this._discountTypeService
        .addUpdateDiscountType(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.discountTypeModalType,
            data: res.responseObject,
          });
        });
    }
  }
}
