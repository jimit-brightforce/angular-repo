import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscountTypeModalComponent } from './discount-type-modal.component';

describe('DiscountTypeModalComponent', () => {
  let component: DiscountTypeModalComponent;
  let fixture: ComponentFixture<DiscountTypeModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DiscountTypeModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DiscountTypeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
