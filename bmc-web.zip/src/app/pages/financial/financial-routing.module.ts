import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'payer-class',
        loadComponent: () =>
          import('./payer-class/payer-class.component').then(m => m.PayerClassComponent),
      },
      {
        path: 'payer-map',
        loadComponent: () =>
          import('./payer-map/payer-map.component').then(m => m.PayerMapComponent),
      },
      {
        path: 'voucher-user-map',
        loadComponent: () =>
          import('./voucher-user-map/voucher-user-map.component').then(
            m => m.VoucherUserMapComponent
          ),
      },
      {
        path: 'trial-balance',
        loadComponent: () =>
          import('./trial-balance/trial-balance.component').then(m => m.TrialBalanceComponent),
      },
      {
        path: 'discount-type',
        loadComponent: () =>
          import('./discount-type/discount-type.component').then(m => m.DiscountTypeComponent),
      },
      {
        path: 'voucher-category',
        loadComponent: () =>
          import('./voucher-category/voucher-category.component').then(
            m => m.VoucherCategoryComponent
          ),
      },
      {
        path: 'discount-type',
        loadComponent: () =>
          import('./discount-type/discount-type.component').then(m => m.DiscountTypeComponent),
      },
      {
        path: 'payer-type',
        loadComponent: () =>
          import('./payer-type/payer-type.component').then(m => m.PayerTypeComponent),
      },
      {
        path: 'payer',
        loadComponent: () => import('./payer/payer.component').then(m => m.PayerComponent),
      },
      {
        path: 'financial-year',
        loadComponent: () =>
          import('./financial-year/financial-year.component').then(m => m.FinancialYearComponent),
      },
      {
        path: 'ledger-map',
        loadComponent: () =>
          import('./ledger-map/ledger-map-component.component').then(m => m.LedgerMapComponent),
      },
      {
        path: 'voucher-map',
        loadComponent: () =>
          import('./voucher-map/voucher-map.component').then(m => m.VoucherMapComponent),
      },
    ]),
  ],
  exports: [RouterModule],
})
export class FinancialRoutingModule {}
