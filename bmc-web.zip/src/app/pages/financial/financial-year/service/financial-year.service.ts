import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators} from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { FinancialYearData } from '../interface/financial-year.interface';

@Injectable()
export class FinancialYearService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getFinancialYear(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<FinancialYearData>>(
      `/v1/${API_FOLDER.masters}/financial-year/page`,
      payload
    );
  }

  getMetaforFinancialYearDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<FinancialYearData>>(
      `/v1/${API_FOLDER.masters}/financial-year/page`,
      payload
    );
  }

  addUpdateFinancialYear(payload: FinancialYearData) {
    if (payload.id) {
      return this._apiService.post<ListApiResponse<FinancialYearData>>(
        `/v1/${API_FOLDER.masters}/financial-year`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<FinancialYearData>>(
      `/v1/${API_FOLDER.masters}/financial-year`,
      payload
    );
  }

  deleteFinancialYear(id: number) {
    return this._apiService.delete<ListApiResponse<FinancialYearData>>(
      `/v1/${API_FOLDER.masters}/financial-year/${id}`
    );
  }

  getFinancialYearForm() {
    return this._fb.group({
        financialYearName: ['', Validators.required],
        startYearDate: ['', Validators.required],
        endYearDate: ['', Validators.required],
        precedingYearIDF: [null as number, Validators.required],
        countryCode: ['', Validators.required],
        isActive : [true]
    });
  }
}
