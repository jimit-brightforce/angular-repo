import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialYearModalComponent } from './financial-year-modal.component';

describe('FinancialYearModalComponent', () => {
  let component: FinancialYearModalComponent;
  let fixture: ComponentFixture<FinancialYearModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FinancialYearModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FinancialYearModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
