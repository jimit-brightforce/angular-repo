import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { CheckboxModule } from 'primeng/checkbox';
import { FinancialYearService } from '../../service/financial-year.service';
import { FinancialYearData } from '../../interface/financial-year.interface';
import { CalendarModule } from 'primeng/calendar';
import { AppDropdownComponent, FilterEvent } from '@components';
import * as moment from 'moment';

@Component({
  selector: 'app-financial-year-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    CheckboxModule,
    CalendarModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './financial-year-modal.component.html',
  styleUrl: './financial-year-modal.component.scss',
  providers : [FinancialYearService]
})
export class FinancialYearModalComponent extends DestroyBehavior{

    private _financialYearService = inject(FinancialYearService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);
  financialYearDropDownOptions = signal<FinancialYearData[]>([])

  financialYearForm = this._financialYearService.getFinancialYearForm();
  financialYearModalData: FinancialYearData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  financialYearModalType: number;

  constructor() {
    super();
    if (this.financialYearModalData) {
      this.patchValueIntofinancialYearForm();
    }
  }

  patchValueIntofinancialYearForm() {
    this.financialYearForm.patchValue({
      ...this.financialYearModalData
    });
  }

  getFinancialYearTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'id',
        order: 'asc',
      },
    };
    this._financialYearService.getMetaforFinancialYearDropDown(param).subscribe({
      next: res => {
        this.financialYearDropDownOptions.set(res.responseObject);
      },
    });
  }

  submitFinancialYearForm() {
    this._utilService.markFormGroupDirty(this.financialYearForm);
    if (this.financialYearForm.valid) {
      const data = {
        id : this.financialYearModalData?.id,
        financialYearName : this.financialYearForm.value.financialYearName,
        startYearDate : moment(this.financialYearForm.value.startYearDate).format("DD-MMM-YYYY"),
        endYearDate : moment(this.financialYearForm.value.endYearDate).format("DD-MMM-YYYY"),
        precedingYearIDF : this.financialYearForm.value.precedingYearIDF,
        countryCode : this.financialYearForm.value.countryCode,
        isActive : this.financialYearForm.value.isActive,
      };

      this.isLoading.set(true);
      this._financialYearService
        .addUpdateFinancialYear(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
