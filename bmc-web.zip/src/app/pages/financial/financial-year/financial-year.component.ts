import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { FinancialYearService } from './service/financial-year.service';
import { FinancialYearData } from './interface/financial-year.interface';
import { FinancialYearModalComponent } from './modal/financial-year-modal/financial-year-modal.component';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-financial-year',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './financial-year.component.html',
  styleUrl: './financial-year.component.scss',
  providers : [FinancialYearService]
})
export class FinancialYearComponent extends DestroyBehavior{

    @ViewChild(TableComponent) _table: TableComponent;

    private _dialogService = inject(DialogService);
    private _financialYearService = inject(FinancialYearService);
    private _toast = inject(ToastService);
    private _appDialog = inject(AppDialogService);

    financialYearTypeBody: FilterEvent;

    financialYearTableData = signal<FinancialYearData[]>([]);

    financialYearForm = this._financialYearService.getFinancialYearForm();
    financialYearModalData: FinancialYearData;
    financialYearModalType: number;

    config: TableConfig = {
      loading: true,
      columns: [
        { field: 'financialYearName', header: 'Financial Year', sortable: true, selected: true },
        { field: 'startYearDate', header: 'Start Year', sortable: true, selected: true },
        { field: 'endYearDate', header: 'End Year', sortable: true, selected: true },
        { field: 'precedingYear', header: 'Preciding Year', sortable: true, selected: true },
        { field: 'countryCode', header: 'Country code', sortable: true, selected: true },
      ],
      lazy: true,
      totalRecords: 0,
      globalFilterFields: ['financialYear'],
      showIndex: true,
    };

    filterEvent(event: FilterEvent) {
      this.config.loading = true;
      this.financialYearTypeBody = event;

      this._financialYearService
        .getFinancialYear(event)
        .pipe(
          finalize(() => (this.config.loading = false)),
          takeUntil(this.notifier)
        )
        .subscribe(res => {
          this.financialYearTableData.set(res.responseObject);
          this.config.totalRecords = res.totalRecords;
        });
    }

    addEditFinancialYearModal( data?: FinancialYearData) {
      const modalRef = this._dialogService.open(FinancialYearModalComponent, {
        header: (data ? 'Edit' : 'Add') + ' Financial Year',
        width: '50%',
        data: data,
        breakpoints: { '1199px': '75vw', '575px': '90vw' },
        contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
        focusOnShow: true,
      });

      modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
        if (result) {

          if (result.id) {
            this.filterEvent(this.financialYearTypeBody);
          } else {
            this._table.table.reset();
          }
        }
      });
    }

    deleteFinancialYear(row): void {
      this._appDialog.confirmDelete(DeleteMessagePrefix + 'Financial Year?', () => {
        this._financialYearService.deleteFinancialYear(row.id).subscribe({
          next: res => {
            this.filterEvent(this.financialYearTypeBody);
            this._toast.success(res.responseMessage);
          },
        });
      });
    }
}
