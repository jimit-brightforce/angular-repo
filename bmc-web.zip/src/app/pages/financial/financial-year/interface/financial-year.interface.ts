
export interface FinancialYearData {
    id?: number;
    financialYearName: string;
    startYearDate: string;
    endYearDate: string;
    countryCode: string;
    isActive: boolean;
    precedingYearIDF: number;
    precedingYear: string;
}
