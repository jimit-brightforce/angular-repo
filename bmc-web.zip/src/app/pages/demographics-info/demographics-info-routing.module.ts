import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes : Routes = [
    {
        path : 'country',
        loadComponent : () => import('./country/country.component').then(m => m.CountryComponent)
    },
    {
        path : 'state',
        loadComponent : () => import('./state/state.component').then(m => m.StateComponent)
    },
    {
        path : 'address-type',
        loadComponent : () => import('./address-type/address-type.component').then(m => m.AddressTypeComponent)
    },
    {
        path : 'city',
        loadComponent : () => import('./city/city.component').then(m => m.CityComponent)
    },
    {
        path : 'area',
        loadComponent : () => import('./area/area.component').then(m => m.AreaComponent)
    },
    {
        path : 'region',
        loadComponent : () => import('./region/region.component').then(m => m.RegionComponent)
    },
    {
        path : 'zone',
        loadComponent : () => import('./zone/zone.component').then(m => m.ZoneComponent)
    },
    {
        path : 'district',
        loadComponent : () => import('./district/district.component').then(m => m.DistrictComponent)
    }
]

@NgModule({
    imports : [RouterModule.forChild(routes)],
    exports : [RouterModule]
})

export class DemographicsInfoRoutingModule{}
