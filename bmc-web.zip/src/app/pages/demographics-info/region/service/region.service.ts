
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { RegionData } from '../interface/region.interface';

@Injectable()
export class RegionService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getRegion(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<RegionData>>(
      `/v1/${API_FOLDER.masters}/region/page`,
      payload
    );
  }

  addUpdateRegion(payload: RegionData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<RegionData>>(
        `/v1/${API_FOLDER.masters}/region`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<RegionData>>(
      `/v1/${API_FOLDER.masters}/region`,
      payload
    );
  }

  deleteRegion(id: number) {
    return this._apiService.delete<ListApiResponse<RegionData>>(
      `/v1/${API_FOLDER.masters}/region/${id}`
    );
  }

  getRegionForm() {
    return this._fb.group({
        regionName: ['', [Validators.required]],
        regionCode: ['', [Validators.required]],
    });
  }
}
