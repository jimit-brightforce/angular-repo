import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CommonModule } from '@angular/common';
import { RegionService } from './service/region.service';
import { RegionData } from './interface/region.interface';
import { RegionModalComponent } from './modal/region-modal/region-modal.component';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-region',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './region.component.html',
  styleUrl: './region.component.scss',
  providers : [RegionService]
})
export class RegionComponent extends DestroyBehavior{

    @ViewChild(TableComponent) _table: TableComponent;

    private _dialogService = inject(DialogService);
    private _regionService = inject(RegionService);
    private _toast = inject(ToastService);
    private _appDialog = inject(AppDialogService);

    regionBody: FilterEvent;

    regionTableData = signal<RegionData[]>([]);

    regionForm = this._regionService.getRegionForm();
    regionModalData: RegionData;
    regionModalType: number;

    config: TableConfig = {
      loading: true,
      columns: [
        { field: 'regionName', header: 'Region Name', sortable: true, selected: true },
        { field: 'regionCode', header: 'Region Code', sortable: true, selected: true },
        { field: 'careProviderName', header: 'Care Provider', sortable: true, selected: true },
      ],
      lazy: true,
      totalRecords: 0,
      globalFilterFields: ['regionName'],
      showIndex: true,
    };

    filterEvent(event: FilterEvent) {
      this.config.loading = true;
      this.regionBody = event;

      this._regionService
        .getRegion(event)
        .pipe(
          finalize(() => (this.config.loading = false)),
          takeUntil(this.notifier)
        )
        .subscribe(res => {
          this.regionTableData.set(res.responseObject);
          this.config.totalRecords = res.totalRecords;
        });
    }

    addEditRegionModal( data?: RegionData) {
      const modalRef = this._dialogService.open(RegionModalComponent, {
        header: (data ? 'Edit' : 'Add') + ' Region',
        width: '35%',
        data: data,
        breakpoints: { '1199px': '75vw', '575px': '90vw' },
        contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
        focusOnShow: true,
      });

      modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
        if (result) {
          console.log(result);

          if (result.id) {
            this.filterEvent(this.regionBody);
          } else {
            this._table.table.reset();
          }
        }
      });
    }

    deleteRegion(row): void {
      this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.regionName}</b>`, () => {
        this._regionService.deleteRegion(row.id).subscribe({
          next: res => {
            this.filterEvent(this.regionBody);
            this._toast.success(res.responseMessage);
          },
        });
      });
    }
}
