
export interface RegionData{
    id ?: number;
    regionName: string;
    regionCode: string;
}
