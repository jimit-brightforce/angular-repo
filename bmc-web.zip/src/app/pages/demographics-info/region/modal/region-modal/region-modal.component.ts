import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { RegionData } from '../../interface/region.interface';
import { RegionService } from '../../service/region.service';

@Component({
  selector: 'app-region-modal',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './region-modal.component.html',
  styleUrl: './region-modal.component.scss',
  providers : [ RegionService]
})
export class RegionModalComponent extends DestroyBehavior{

    private _regionService = inject(RegionService);
    private _dynamicDialogRef = inject(DynamicDialogRef);
    private _dialogService = inject(DialogService);
    private _utilService = inject(UtilService);
    private _toast = inject(ToastService);

    isLoading = signal<boolean>(false);
    regionForm = this._regionService.getRegionForm();
    regionModalData: RegionData = this._dialogService.getInstance(this._dynamicDialogRef).data;
    regionModalType: number;

    constructor() {
      super();
      if (this.regionModalData) {
        this.patchValueIntoRegionForm();
      }
    }

    patchValueIntoRegionForm() {
      this.regionForm.patchValue({
        ...this.regionModalData,
      });
    }

    submitRegionForm() {
      this._utilService.markFormGroupDirty(this.regionForm);
      if (this.regionForm.valid) {
        const data = {
          id: this.regionModalData?.id,
          regionName: this.regionForm.value.regionName,
          regionCode: this.regionForm.value.regionCode,
        };

        this.isLoading.set(true);
        this._regionService
          .addUpdateRegion(data as any)
          .pipe(
            takeUntil(this.notifier),
            finalize(() => this.isLoading.set(false))
          )
          .subscribe(res => {
            this._toast.success(res.responseMessage);
            this._dynamicDialogRef.close({
              closeModalType: this.regionModalType,
              data: res.responseObject,
            });
          });
      }
    }
}
