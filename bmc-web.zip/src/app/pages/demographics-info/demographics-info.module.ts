import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DemographicsInfoRoutingModule } from './demographics-info-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DemographicsInfoRoutingModule
  ]
})
export class DemographicsInfoModule { }
