
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { CountryData } from '../interface/country.interface';

@Injectable()
export class CountryService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getCountry(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CountryData>>(
      `/v1/${API_FOLDER.masters}/country/page`,
      payload
    );
  }

  addUpdateCountry(payload: CountryData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<CountryData>>(
        `/v1/${API_FOLDER.masters}/country`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<CountryData>>(
      `/v1/${API_FOLDER.masters}/country`,
      payload
    );
  }

  deleteCountry(id: number) {
    return this._apiService.delete<ListApiResponse<CountryData>>(
      `/v1/${API_FOLDER.masters}/country/${id}`
    );
  }

  getCountryForm() {
    return this._fb.group({
        countryName: ['', [Validators.required]],
        iana : [''],
        un : [''],
        ioc : [''],
        iso : [''],
        ituCode : [''],
    });
  }
}
