import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CountryService } from './service/country.service';
import { CountryData } from './interface/country.interface';
import { CountryModalComponent } from './modal/country-modal/country-modal.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-country',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './country.component.html',
  styleUrl: './country.component.scss',
  providers : [CountryService]
})
export class CountryComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _countryService = inject(CountryService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  countryTypeBody: FilterEvent;

  countryTableData = signal<CountryData[]>([]);

  countryForm = this._countryService.getCountryForm();
  countryModalData: CountryData;
  countryModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'countryName', header: 'Country Name', sortable: true, selected: true },
      { field: 'iana', header: 'IANA', sortable: true, selected: true },
      { field: 'un', header: 'UN', sortable: true, selected: true },
      { field: 'ioc', header: 'IOC', sortable: true, selected: true },
      { field: 'iso', header: 'ISO', sortable: true, selected: true },
      { field: 'ituCode', header: 'ITU Code', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['countryName'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.countryTypeBody = event;

    this._countryService
      .getCountry(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.countryTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditCountryModal( data?: CountryData) {
    const modalRef = this._dialogService.open(CountryModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Country',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {

        if (result.id) {
          this.filterEvent(this.countryTypeBody)
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteCountry(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.countryName}</b>`, () => {
      this._countryService.deleteCountry(row.id).subscribe({
        next: res => {
          this.filterEvent(this.countryTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
