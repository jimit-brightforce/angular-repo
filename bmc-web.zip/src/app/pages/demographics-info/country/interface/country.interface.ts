export interface CountryData{
    id?: number
    countryName: string
    iana: string
    un: string
    ioc: string
    iso: string
    ituCode: string
    timeZone: any
}