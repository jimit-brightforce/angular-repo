import { Component, inject, signal } from '@angular/core';
import { ToastService, UtilService } from '@services';
import { DestroyBehavior } from '@strategies';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { finalize, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { CountryService } from '../../service/country.service';
import { CountryData } from '../../interface/country.interface';

@Component({
  selector: 'app-country-modal',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './country-modal.component.html',
  styleUrl: './country-modal.component.scss',
  providers: [CountryService]
})
export class CountryModalComponent extends DestroyBehavior {

  private _countryService = inject(CountryService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);

  countryForm = this._countryService.getCountryForm();
  countryModalData: CountryData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  countryModalType: number;

  constructor() {
    super();
    if (this.countryModalData) {
      this.patchValueIntocountryForm();
    }
  }

  patchValueIntocountryForm() {
    this.countryForm.patchValue({
      ...this.countryModalData
    });
  }

  submitCountryForm() {
    this._utilService.markFormGroupDirty(this.countryForm);
    if (this.countryForm.valid) {
      const data = {
        id: this.countryModalData?.id,
        countryName: this.countryForm.value.countryName,
        iana: this.countryForm.value.iana,
        un: this.countryForm.value.un,
        ioc: this.countryForm.value.ioc,
        iso: this.countryForm.value.iso,
        ituCode: this.countryForm.value.ituCode,
      };

      this.isLoading.set(true);
      this._countryService
        .addUpdateCountry(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close(data);
        });
    }
  }
}
