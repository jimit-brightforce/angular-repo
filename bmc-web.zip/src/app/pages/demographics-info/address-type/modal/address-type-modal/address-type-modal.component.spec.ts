import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressTypeModalComponent } from './address-type-modal.component';

describe('AddressTypeModalComponent', () => {
  let component: AddressTypeModalComponent;
  let fixture: ComponentFixture<AddressTypeModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddressTypeModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddressTypeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
