import { Component, ViewChild, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { DeleteMessagePrefix, ToastService } from '@services';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { AppDialogService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { CommonModule } from '@angular/common';
import { AddressTypeService } from './service/address-type.service';
import { AddressTypeData } from './interface/address-type.interface';
import { AddressTypeModalComponent } from './modal/address-type-modal/address-type-modal.component';

@Component({
  selector: 'app-address-type',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './address-type.component.html',
  styleUrl: './address-type.component.scss',
  providers : [ AddressTypeService]
})
export class AddressTypeComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _addressTypeService = inject(AddressTypeService);
  private _appDialog = inject(AppDialogService);
  private _toast = inject(ToastService);
  addressTypeBody: FilterEvent;

  addressTypeTableData = signal<AddressTypeData[]>([]);

  addressTypeForm = this._addressTypeService.getAddressTypeForm();
  addressTypeModalData: AddressTypeData;
  addressTypeModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'addressType', header: 'Address Type', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['addressType'],
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.addressTypeBody = event;

    this._addressTypeService
      .getAddressType(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.addressTypeTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  deleteAddressType(row) {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.addressType}</b>`, () => {
      this._addressTypeService.deleteAddressType(row.id).subscribe({
        next: res => {
          this.filterEvent(this.addressTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }

  addEditAddressTypeModal(data?: AddressTypeData) {
    const addEditaddressTypeModalRef = this._dialogService.open(AddressTypeModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' Address Type',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    addEditaddressTypeModalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.addressTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }
}
