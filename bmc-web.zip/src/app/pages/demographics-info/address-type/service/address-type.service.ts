import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { AddressTypeData } from '../interface/address-type.interface';


@Injectable()
export class AddressTypeService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getAddressType(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<AddressTypeData>>(
      `/v1/${API_FOLDER.masters}/address-type/page`,
      payload
    );
  }

  addUpdateAddressType(payload: AddressTypeData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<AddressTypeData>>(
        `/v1/${API_FOLDER.masters}/address-type`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<AddressTypeData>>(
      `/v1/${API_FOLDER.masters}/address-type`,
      payload
    );
  }

  deleteAddressType(id: number) {
    return this._apiService.delete<ListApiResponse<AddressTypeData>>(
      `/v1/${API_FOLDER.masters}/address-type/${id}`
    );
  }

  getAddressTypeForm() {
    return this._fb.group({
        addressType: ['', Validators.required],
        isActive: [true],
    });
  }
}
