
export interface AddressTypeData {
    id ?: number;
    addressType : string;
    isActive : boolean;
}