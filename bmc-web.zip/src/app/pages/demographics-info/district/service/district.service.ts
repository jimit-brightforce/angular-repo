import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { DistrictData } from '../interface/district.interface';
import { StateData } from '../../state/interface/state.interface';

@Injectable()
export class DistrictService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getDistrict(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<DistrictData>>(
      `/v1/${API_FOLDER.masters}/district/page`,
      payload
    );
  }

  getMetaforStateDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<StateData>>(
      `/v1/${API_FOLDER.masters}/state/page`,
      payload
    );
  }

  addUpdateDistrict(payload: DistrictData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<DistrictData>>(
        `/v1/${API_FOLDER.masters}/district`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<DistrictData>>(
      `/v1/${API_FOLDER.masters}/district`,
      payload
    );
  }

  deleteDistrict(id: number) {
    return this._apiService.delete<ListApiResponse<DistrictData>>(
      `/v1/${API_FOLDER.masters}/district/${id}`
    );
  }

  getDistrictForm() {
    return this._fb.group({
        districtName: ['', Validators.required],
        districtCode: ['', Validators.required],
        stateId: [0, Validators.required],
    });
  }
}
