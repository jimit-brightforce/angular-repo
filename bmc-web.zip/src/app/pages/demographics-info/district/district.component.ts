import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CommonModule } from '@angular/common';
import { DistrictService } from './service/district.service';
import { DistrictData } from './interface/district.interface';
import { DistrictModalComponent } from './modal/district-modal/district-modal.component';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-district',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './district.component.html',
  styleUrl: './district.component.scss',
  providers : [DistrictService]
})
export class DistrictComponent extends DestroyBehavior{

    @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _districtService = inject(DistrictService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  districtTypeBody: FilterEvent;

  districtTableData = signal<DistrictData[]>([]);

  districtForm = this._districtService.getDistrictForm();
  districtModalData: DistrictData;
  districtModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'districtName', header: 'District Name', sortable: true, selected: true },
      { field: 'districtCode', header: 'District Code', sortable: true, selected: true },
      { field: 'stateName', header: 'State', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['districtName'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.districtTypeBody = event;

    this._districtService
      .getDistrict(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.districtTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditDistrictModal( data?: DistrictData) {
    const modalRef = this._dialogService.open(DistrictModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' District',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        if (result.id) {
          this.filterEvent(this.districtTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteDistrict(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `${row.districtName}`, () => {
      this._districtService.deleteDistrict(row.id).subscribe({
        next: res => {
          this.filterEvent(this.districtTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
