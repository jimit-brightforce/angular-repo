import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { DistrictService } from '../../service/district.service';
import { DistrictData } from '../../interface/district.interface';
import { StateData } from '../../../state/interface/state.interface';

@Component({
    selector: 'app-district-modal',
    standalone: true,
    imports: [
        InputTextModule,
        ReactiveFormsModule,
        DropdownModule,
        ButtonModule,
        DialogModule,
        AppDropdownComponent,
        FloatLabelModule,
        NgxTrimDirectiveModule,
    ],
    templateUrl: './district-modal.component.html',
    styleUrl: './district-modal.component.scss',
    providers: [DistrictService]
})
export class DistrictModalComponent extends DestroyBehavior{

    private _districtService = inject(DistrictService);
    private _dynamicDialogRef = inject(DynamicDialogRef);
    private _dialogService = inject(DialogService);
    private _utilService = inject(UtilService);
    private _toast = inject(ToastService);

    stateDropdownOptions = signal<StateData[]>([]);

    isLoading = signal<boolean>(false);
    districtForm = this._districtService.getDistrictForm();
    districtModalData: DistrictData = this._dialogService.getInstance(this._dynamicDialogRef).data;
    districtModalType: number;

    constructor() {
        super();
        if (this.districtModalData) {
            this.patchValueIntoDistrictForm();
            this.getStateDropdownTableData(this.districtModalData?.stateName);
        }

    }

    patchValueIntoDistrictForm() {
        this.districtForm.patchValue({
            ...this.districtModalData,
        });
    }

    getStateDropdownTableData(searchKey: string = '') {
        const param: FilterEvent = {
            page: 0,
            size: 15,
            searchKey: searchKey ?? null,
        };
        this._districtService.getMetaforStateDropDown(param).subscribe({
            next: res => {
                this.stateDropdownOptions.set(res.responseObject);
            },
        });
    }

    submitDistrictForm() {
        this._utilService.markFormGroupDirty(this.districtForm);
        if (this.districtForm.valid) {
            const data = {
                id: this.districtModalData?.id,
                districtName: this.districtForm.value.districtName,
                districtCode: this.districtForm.value.districtCode,
                stateId : this.districtForm.value.stateId,
            };
            this.isLoading.set(true);
            this._districtService
                .addUpdateDistrict(data as any)
                .pipe(
                    takeUntil(this.notifier),
                    finalize(() => this.isLoading.set(false))
                )
                .subscribe(res => {
                    this._toast.success(res.responseMessage);
                    this._dynamicDialogRef.close({
                        closeModalType: this.districtModalType,
                        data: res.responseObject,
                    });
                });
        }
    }
}
