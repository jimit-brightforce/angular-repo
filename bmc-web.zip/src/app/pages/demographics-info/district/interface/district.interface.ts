
export interface DistrictData {
    id?: number;
    districtName: string;
    districtCode: string;
    stateId: number;
    stateName?: string;
}
