
export interface ZoneData {
    id?: number;
    zoneName: string;
    zoneCode: string;
    regionId: string;
}

