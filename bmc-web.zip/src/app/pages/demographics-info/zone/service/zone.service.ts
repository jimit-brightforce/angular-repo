
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { ZoneData } from '../interface/zone.interface';
import { RegionData } from '../../region/interface/region.interface';

@Injectable()
export class ZoneService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getZone(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<ZoneData>>(
      `/v1/${API_FOLDER.masters}/zone/page`,
      payload
    );
  }

  getMetaforRegionDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<RegionData>>(
      `/v1/${API_FOLDER.masters}/region/page`,
      payload
    );
  }

  addUpdateZone(payload: ZoneData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<ZoneData>>(
        `/v1/${API_FOLDER.masters}/zone`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<ZoneData>>(
      `/v1/${API_FOLDER.masters}/zone`,
      payload
    );
  }

  deleteZone(id: number) {
    return this._apiService.delete<ListApiResponse<ZoneData>>(
      `/v1/${API_FOLDER.masters}/zone/${id}`
    );
  }

  getZoneForm() {
    return this._fb.group({
        zoneName: ['', [Validators.required]],
        zoneCode: ['', [Validators.required]],
        regionId: ['', [Validators.required]],
    });
  }
}
