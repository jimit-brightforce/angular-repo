import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CommonModule } from '@angular/common';
import { ZoneService } from './service/zone.service';
import { ZoneData } from './interface/zone.interface';
import { ZoneModalComponent } from './modal/zone-modal/zone-modal.component';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-zone',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './zone.component.html',
  styleUrl: './zone.component.scss',
  providers : [ZoneService]
})
export class ZoneComponent extends DestroyBehavior{

    @ViewChild(TableComponent) _table: TableComponent;

    private _dialogService = inject(DialogService);
    private _zoneService = inject(ZoneService);
    private _toast = inject(ToastService);
    private _appDialog = inject(AppDialogService);

    zoneBody: FilterEvent;

    zoneTableData = signal<ZoneData[]>([]);

    zoneForm = this._zoneService.getZoneForm();
    zoneModalData: ZoneData;
    zoneModalType: number;

    config: TableConfig = {
      loading: true,
      columns: [
        { field: 'zoneName', header: 'Zone Name', sortable: true, selected: true },
        { field: 'zoneCode', header: 'Zone Code', sortable: true, selected: true },
      ],
      lazy: true,
      totalRecords: 0,
      globalFilterFields: ['zoneName',  'zoneCode'],
      showIndex: true,
    };

    filterEvent(event: FilterEvent) {
      this.config.loading = true;
      this.zoneBody = event;

      this._zoneService
        .getZone(event)
        .pipe(
          finalize(() => (this.config.loading = false)),
          takeUntil(this.notifier)
        )
        .subscribe(res => {
          this.zoneTableData.set(res.responseObject);
          this.config.totalRecords = res.totalRecords;
        });
    }

    addEditZoneModal( data?: ZoneData) {
      const modalRef = this._dialogService.open(ZoneModalComponent, {
        header: (data ? 'Edit' : 'Add') + ' Zone',
        width: '35%',
        data: data,
        breakpoints: { '1199px': '75vw', '575px': '90vw' },
        contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
        focusOnShow: true,
      });

      modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
        if (result) {
          if (result.id) {
            this.filterEvent(this.zoneBody);
          } else {
            this._table.table.reset();
          }
        }
      });
    }

    deleteZone(row): void {
      this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.zoneName}</b>`, () => {
        this._zoneService.deleteZone(row.id).subscribe({
          next: res => {
            this.filterEvent(this.zoneBody);
            this._toast.success(res.responseMessage);
          },
        });
      });
    }
}
