import { CheckboxModule } from 'primeng/checkbox';
import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { AreaService } from '../../service/area.service';
import { AreaData} from '../../interface/area.interface';
import { AppDropdownComponent, FilterEvent } from '@components';

@Component({
    selector: 'app-area-modal',
    standalone: true,
    imports: [
        CommonModule,
        InputTextModule,
        ReactiveFormsModule,
        ButtonModule,
        CheckboxModule,
        DialogModule,
        AppDropdownComponent,
        FloatLabelModule,
        NgxTrimDirectiveModule
    ],
    templateUrl: './area-modal.component.html',
    styleUrl: './area-modal.component.scss',
    providers: [AreaService]
})
export class AreaModalComponent extends DestroyBehavior {

    private _areaService = inject(AreaService);
    private _dynamicDialogRef = inject(DynamicDialogRef);
    private _dialogService = inject(DialogService);
    private _utilService = inject(UtilService);
    private _toast = inject(ToastService);
    cityDropdown = signal<AreaData[]>([])


    isLoading = signal<boolean>(false);
    areaForm = this._areaService.getAreaForm();
    areaModalData: AreaData = this._dialogService.getInstance(this._dynamicDialogRef).data;
    areaModalType: number;

    constructor() {
        super();
        if (this.areaModalData) {
            this.patchValueIntoAreaForm();
        }
    }

    patchValueIntoAreaForm() {
        this.areaForm.patchValue({
            // ...this.areaModalData,
        });
    }

    getCityTableData(searchKey: string = '') {
        const param: FilterEvent = {
          page: 0,
          size: 15,
          searchKey: searchKey ?? null,
        };
        this._areaService.getMetaforCityDropDown(param).subscribe({
          next: res => {
            this.cityDropdown.set(res.responseObject);
          },
        });
      }

    submitAreaForm() {
        this._utilService.markFormGroupDirty(this.areaForm);
        if (this.areaForm.valid) {
            const data = {
                id: this.areaModalData?.id,
                areaName: this.areaForm.value.areaName,
                cityId: this.areaForm.value.cityId,
                isActive: this.areaForm.value.isActive,
                postalCode: this.areaForm.value.postalCode,
                latitude: this.areaForm.value.latitude,
                longitude: this.areaForm.value.longitude,
            };

            this.isLoading.set(true);
            this._areaService
                .addUpdateArea(data as any)
                .pipe(
                    takeUntil(this.notifier),
                    finalize(() => this.isLoading.set(false))
                )
                .subscribe(res => {
                    this._toast.success(res.responseMessage);
                    this._dynamicDialogRef.close({
                        closeModalType: this.areaModalType,
                        data: res.responseObject,
                    });
                });
        }
    }
}
