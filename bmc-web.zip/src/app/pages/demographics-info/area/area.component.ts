import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CommonModule } from '@angular/common';
import { AreaService } from './service/area.service';
import { AreaData } from './interface/area.interface';
import { AreaModalComponent } from './modal/area-modal/area-modal.component';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-area',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './area.component.html',
  styleUrl: './area.component.scss',
  providers : [AreaService]
})
export class AreaComponent extends DestroyBehavior{

    @ViewChild(TableComponent) _table: TableComponent;

    private _dialogService = inject(DialogService);
    private _areaService = inject(AreaService);
    private _toast = inject(ToastService);
    private _appDialog = inject(AppDialogService);

    areaBody: FilterEvent;

    areaTableData = signal<AreaData[]>([]);

    areaForm = this._areaService.getAreaForm();
    areaModalData: AreaData;
    areaModalType: number;

    config: TableConfig = {
      loading: true,
      columns: [
        { field: 'areaName', header: 'Area Name', sortable: true, selected: true },
        { field: 'state', header: 'State', sortable: true, selected: true },
        { field: 'cityName', header: 'City', sortable: true, selected: true },
        { field: 'postalCode', header: 'Postal Code', sortable: true, selected: true },
        { field: 'latitude', header: 'Latitude', sortable: true, selected: true },
        { field: 'longitude', header: 'Longitude', sortable: true, selected: true },
      ],
      lazy: true,
      totalRecords: 0,
      globalFilterFields: ['areaName'],
      showIndex: true,
    };

    filterEvent(event: FilterEvent) {
      this.config.loading = true;
      this.areaBody = event;

      this._areaService
        .getArea(event)
        .pipe(
          finalize(() => (this.config.loading = false)),
          takeUntil(this.notifier)
        )
        .subscribe(res => {
          this.areaTableData.set(res.responseObject);
          this.config.totalRecords = res.totalRecords;
        });
    }

    addEditAreaModal( data?: AreaData) {
      const modalRef = this._dialogService.open(AreaModalComponent, {
        header: (data ? 'Edit' : 'Add') + ' Area',
        width: '35%',
        data: data,
        breakpoints: { '1199px': '75vw', '575px': '90vw' },
        contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
        focusOnShow: true,
      });

      modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
        if (result) {
          console.log(result);

          if (result.id) {
            this.filterEvent(this.areaBody);
          } else {
            this._table.table.reset();
          }
        }
      });
    }

    deleteArea(row): void {
      this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.areaName}</b>`, () => {
        this._areaService.deleteArea(row.id).subscribe({
          next: res => {
            this.filterEvent(this.areaBody);
            this._toast.success(res.responseMessage);
          },
        });
      });
    }
}
