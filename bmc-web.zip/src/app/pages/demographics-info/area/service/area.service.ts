
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { AreaData } from '../interface/area.interface';

@Injectable()
export class AreaService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getArea(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<AreaData>>(
      `/v1/${API_FOLDER.masters}/area/page`,
      payload
    );
  }

  getMetaforCityDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<any>>(
      `/v1/${API_FOLDER.masters}/city/page`,
      payload
    );
  }

  addUpdateArea(payload: AreaData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<AreaData>>(
        `/v1/${API_FOLDER.masters}/area`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<AreaData>>(
      `/v1/${API_FOLDER.masters}/area`,
      payload
    );
  }

  deleteArea(id: number) {
    return this._apiService.delete<ListApiResponse<AreaData>>(
      `/v1/${API_FOLDER.masters}/area/${id}`
    );
  }

  getAreaForm() {
    return this._fb.group({
        areaName: ['', [Validators.required]],
        cityId: [null as number, [Validators.required]],
        isActive: [true, [Validators.required]],
        postalCode: ['', [Validators.required]],
        latitude: ['', [Validators.required]],
        longitude: ['', [Validators.required]],
    });
  }
}
