export interface AreaData{
    id ?: number;
}


export interface CityData{
    id ?: number;
    cityName: string
    cityCode: string
    stateId: number
    districtId: number
}
