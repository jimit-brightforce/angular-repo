import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService } from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CommonModule } from '@angular/common';
import { CityService } from './service/city.service';
import { CityModalComponent } from './modal/city-modal/city-modal.component';
import { CityData } from './interface/city.interface';
import { DestroyBehavior } from '@strategies';

@Component({
  selector: 'app-city',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './city.component.html',
  styleUrl: './city.component.scss',
  providers : [CityService]
})
export class CityComponent extends DestroyBehavior{

    @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _cityService = inject(CityService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  cityBody: FilterEvent;

  cityTableData = signal<CityData[]>([]);

  cityForm = this._cityService.getCityForm();
  cityModalData: CityData;
  cityModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'cityName', header: 'City Name', sortable: true, selected: true },
      { field: 'cityCode', header: 'City Code', sortable: true, selected: true },
      { field: 'stateName', header: 'State Name', sortable: true, selected: true },
      { field: 'districtName', header: 'District Name', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['cityName'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.cityBody = event;

    this._cityService
      .getCity(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.cityTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditCityModal( data?: CityData) {
    const modalRef = this._dialogService.open(CityModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' City',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {
        console.log(result);

        if (result.id) {
          this.filterEvent(this.cityBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteCity(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.cityName}</b>`, () => {
      this._cityService.deleteCity(row.id).subscribe({
        next: res => {
          this.filterEvent(this.cityBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
