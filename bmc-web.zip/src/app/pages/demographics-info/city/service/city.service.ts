
import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FilterEvent } from '@components';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { API_FOLDER } from '@consts';
import { CityData } from '../interface/city.interface';
import { StateData } from '../../state/interface/state.interface';
import { DistrictData } from '../../district/interface/district.interface';

@Injectable()
export class CityService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getCity(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<CityData>>(
      `/v1/${API_FOLDER.masters}/city/page`,
      payload
    );
  }

  getMetaForState(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<StateData>>(
      `/v1/${API_FOLDER.masters}/state/page`,
      payload
    );
  }

  getMetaForDistrict(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<DistrictData>>(
      `/v1/${API_FOLDER.masters}/district/page`,
      payload
    );
  }

  addUpdateCity(payload: CityData) {
    if (payload.id) {
      return this._apiService.put<ListApiResponse<CityData>>(
        `/v1/${API_FOLDER.masters}/city`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<CityData>>(
      `/v1/${API_FOLDER.masters}/city`,
      payload
    );
  }

  deleteCity(id: number) {
    return this._apiService.delete<ListApiResponse<CityData>>(
      `/v1/${API_FOLDER.masters}/city/${id}`
    );
  }

  getCityForm() {
    return this._fb.group({
        cityName: ['', [Validators.required]],
        cityCode: ['', [Validators.required]],
        stateId: [null as number, [Validators.required]],
        districtId: [null as number, [Validators.required]],
    });
  }
}
