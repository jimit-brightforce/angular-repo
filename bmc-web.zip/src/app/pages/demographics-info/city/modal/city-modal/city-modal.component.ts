import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { CityService } from '../../service/city.service';
import { CityData } from '../../interface/city.interface';
import { AppDropdownComponent, FilterEvent } from '@components';
import { StateData } from '../../../state/interface/state.interface';
import { DistrictData } from '../../../district/interface/district.interface';
import { DialogModule } from 'primeng/dialog';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-city-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule
  ],
  templateUrl: './city-modal.component.html',
  styleUrl: './city-modal.component.scss',
  providers : [CityService]
})
export class CityModalComponent extends DestroyBehavior{

  private _cityService = inject(CityService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  isLoading = signal<boolean>(false);
  stateDropdownOptions = signal<StateData[]>([]);
  districtDropdownOptions = signal<DistrictData[]>([]);
  cityForm = this._cityService.getCityForm();
  cityModalData: CityData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  stateModalData: StateData;
  districtModalData: DistrictData;
  cityModalType: number;

  stateId: number;

  constructor() {
    super();
    if (this.cityModalData) {
      this.patchValueIntoCityForm();
    }
  }

  patchValueIntoCityForm() {
    this.cityForm.patchValue({
      ...this.cityModalData,
    });
  }

  onSelect(event) {
   this.stateId = event.value;
  }

  getStateNameTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'id',
        order: 'desc',
      },
    };
    this._cityService.getMetaForState(param).subscribe({
      next: res => {
        this.stateDropdownOptions.set(res.responseObject);
      },
    });
  }

  getDistrictNameTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 10,
      searchKey: searchKey ?? null,
      sort: {
        column: 'id',
        order: 'desc',
      },
    };
    this._cityService.getMetaForDistrict(param).subscribe({
      next: res => {
        const aaa = res.responseObject.filter(x => x.id === this.stateId);
        console.log(aaa);

        this.districtDropdownOptions.set(res.responseObject);
      },
    });
  }

  submitCityForm() {
    this._utilService.markFormGroupDirty(this.cityForm);
    if (this.cityForm.valid) {
      const data = {
        id: this.cityModalData?.id,
        cityName: this.cityForm.value.cityName,
        cityCode: this.cityForm.value.cityCode,
        stateId: this.cityForm.value.stateId,
        districtId: this.cityForm.value.districtId,
      };

      this.isLoading.set(true);
      this._cityService
        .addUpdateCity(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.cityModalType,
            data: res.responseObject,
          });
        });
    }
  }
}
