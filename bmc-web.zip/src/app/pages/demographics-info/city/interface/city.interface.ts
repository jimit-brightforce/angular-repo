
export interface CityData{
    id ?: number;
    cityName: string;
    cityCode: string;
    stateName: string;
    districtName: string;
    stateId: number;
    districtId: number;
}
