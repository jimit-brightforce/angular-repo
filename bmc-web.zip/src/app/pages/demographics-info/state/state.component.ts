import { Component, inject, signal, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogService} from 'primeng/dynamicdialog';
import { ToastService, AppDialogService, DeleteMessagePrefix } from '@services';
import {
  TableColumnDirective,
  TableComponent
} from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';
import { TagModule } from 'primeng/tag';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { StateService } from './service/state.service';
import { StateData } from './interface/state.interface';
import { StateModalComponent } from './modal/state-modal/state-modal.component';

@Component({
  selector: 'app-state',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    TagModule,
    OverlayPanelModule
  ],
  templateUrl: './state.component.html',
  styleUrl: './state.component.scss',
  providers : [StateService]
})
export class StateComponent extends DestroyBehavior{

  @ViewChild(TableComponent) _table: TableComponent;

  private _dialogService = inject(DialogService);
  private _stateService = inject(StateService);
  private _toast = inject(ToastService);
  private _appDialog = inject(AppDialogService);

  stateTypeBody: FilterEvent;

  stateTableData = signal<StateData[]>([]);

  stateForm = this._stateService.getStateForm();
  stateModalData: StateData;
  stateModalType: number;

  config: TableConfig = {
    loading: true,
    columns: [
      { field: 'stateName', header: 'State Name', sortable: true, selected: true },
      { field: 'stateCode', header: 'State Code', sortable: true, selected: true },
      { field: 'gstcode', header: 'Gst Code', sortable: true, selected: true },
      { field: 'countryName', header: 'Country Name', sortable: true, selected: true },
    ],
    lazy: true,
    totalRecords: 0,
    globalFilterFields: ['stateName'],
    showIndex: true,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    this.stateTypeBody = event;

    this._stateService
      .getState(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.stateTableData.set(res.responseObject);
        this.config.totalRecords = res.totalRecords;
      });
  }

  addEditStateModal( data?: StateData) {
    const modalRef = this._dialogService.open(StateModalComponent, {
      header: (data ? 'Edit' : 'Add') + ' State',
      width: '35%',
      data: data,
      breakpoints: { '1199px': '75vw', '575px': '90vw' },
      contentStyle: { 'max-height': '500px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });

    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(result => {
      if (result) {

        if (result.id) {
          this.filterEvent(this.stateTypeBody);
        } else {
          this._table.table.reset();
        }
      }
    });
  }

  deleteState(row): void {
    this._appDialog.confirmDelete(DeleteMessagePrefix + `<b>${row.stateName}</b>`, () => {
      this._stateService.deleteState(row.id).subscribe({
        next: res => {
          this.filterEvent(this.stateTypeBody);
          this._toast.success(res.responseMessage);
        },
      });
    });
  }
}
