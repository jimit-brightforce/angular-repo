import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { FilterEvent } from '@components';
import { StateData } from '../interface/state.interface';

@Injectable()
export class StateService {
  private _fb = inject(FormBuilder);
  private _apiService = inject(ApiServices);

  getState(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<StateData>>(
      `/v1/${API_FOLDER.masters}/state/page`,
      payload
    );
  }

  getMetaforCountryDropDown(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<StateData>>(
      `/v1/${API_FOLDER.masters}/country/page`,
      payload
    );
  }

  addUpdateState(payload: StateData) {
    if (payload.id) {
      return this._apiService.post<ListApiResponse<StateData>>(
        `/v1/${API_FOLDER.masters}/state`,
        payload
      );
    }
    return this._apiService.post<ListApiResponse<StateData>>(
      `/v1/${API_FOLDER.masters}/state`,
      payload
    );
  }

  deleteState(id: number) {
    return this._apiService.delete<ListApiResponse<StateData>>(
      `/v1/${API_FOLDER.masters}/state/${id}`
    );
  }

  getStateForm() {
    return this._fb.group({
        stateName: ['', Validators.required],
        stateCode: ['', Validators.required],
        gstcode: ['', Validators.required],
        countryId: [0, Validators.required],       
    });
  }
}
