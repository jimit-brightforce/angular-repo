
export interface StateData {
    id?: number
    stateName: string
    stateCode: string
    countryId: number
    gstcode: string

}