import { Component, OnInit, inject, signal } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { AppDropdownComponent, FilterEvent } from '@components';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ToastService, UtilService } from '@services';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { FloatLabelModule } from 'primeng/floatlabel';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { StateService } from '../../service/state.service';
import { StateData } from '../../interface/state.interface';

@Component({
  selector: 'app-state-modal',
  standalone: true,
  imports: [
    InputTextModule,
    ReactiveFormsModule,
    DropdownModule,
    ButtonModule,
    DialogModule,
    AppDropdownComponent,
    FloatLabelModule,
    NgxTrimDirectiveModule,
  ],
  templateUrl: './state-modal.component.html',
  styleUrl: './state-modal.component.scss',
  providers : [StateService]
})
export class StateModalComponent extends DestroyBehavior implements OnInit{

  private _stateService = inject(StateService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _dialogService = inject(DialogService);
  private _utilService = inject(UtilService);
  private _toast = inject(ToastService);

  stateDropdown = signal<StateData[]>([]);

  isLoading = signal<boolean>(false);
  stateForm = this._stateService.getStateForm();
  stateModalData: StateData = this._dialogService.getInstance(this._dynamicDialogRef).data;
  stateModalType: number;

  constructor() {
    super();
    if (this.stateModalData) {
      this.patchValueIntostateForm();
    }
  }

  patchValueIntostateForm() {
    this.stateForm.patchValue({
      ...this.stateModalData,
    });
  }

  ngOnInit(): void {
    this.getCountryTableData();
  }

  getCountryTableData(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 15,
      searchKey: searchKey ?? null,
    };
    this._stateService.getMetaforCountryDropDown(param).subscribe({
      next: res => {
        this.stateDropdown.set(res.responseObject);
      },
    });
  }

  submitStateForm() {
    this._utilService.markFormGroupDirty(this.stateForm);
    if (this.stateForm.valid) {
      const data = {
        id : this.stateModalData?.id,
        countryId : this.stateForm.value.countryId,
        stateName : this.stateForm.value.stateName,
        stateCode : this.stateForm.value.stateCode,
        gstcode : this.stateForm.value.gstcode,

      };

      this.isLoading.set(true);
      this._stateService
        .addUpdateState(data as any)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.isLoading.set(false))
        )
        .subscribe(res => {
          this._toast.success(res.responseMessage);
          this._dynamicDialogRef.close({
            closeModalType: this.stateModalType,
            data: res.responseObject,
          });
        });
    }
  }
}
