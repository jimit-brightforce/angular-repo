import { Component, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { environment } from '@environments';
import { LayoutService } from 'src/app/layout/service/app.layout.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: [
    `
      :host ::ng-deep .pi-eye,
      :host ::ng-deep .pi-eye-slash {
        transform: scale(1.6);
        margin-right: 1rem;
        color: var(--primary-color) !important;
      }
    `,
  ],
})
export class LoginComponent {
  // cha

  value = 2;

  valCheck: string[] = ['remember'];

  password!: string;
  version = environment.version;

  fb = inject(FormBuilder);
  loginForm: FormGroup;
  loginTypes = [
    {
      id: 1,
      label: 'Patient',
    },
    {
      id: 2,
      label: 'Doctor',
    },
    {
      id: 3,
      label: 'Admin',
    },
    {
      id: 4,
      label: 'Staff',
    },
  ];
  constructor(public layoutService: LayoutService) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.email, Validators.required]],
      password: ['', [Validators.required]],
      loginType: new FormControl(2, {
        validators: [Validators.required],
      }),
    });
    // for (let index = 0; index < 1000; index++) {
    //   this.loginTypes.push({
    //     id: index,
    //     label: `${index}`
    //   })

    // }
  }

  proceedLogin() {
    console.log(this.loginForm.invalid, this.loginForm.value);
  }

  searchTypes() {
    setTimeout(() => {
      this.loginTypes = [
        {
          id: 1,
          label: 'Patient',
        },
        {
          id: 2,
          label: 'Doctor',
        },
      ];
    }, 2000);
  }

  onSelectItemUserType(ev) {
    console.log(ev);
  }
}
