import { Injectable, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Injectable()
export class RegisterService {
  private _fb = inject(FormBuilder);

  getIndividualForm() {
    return this._fb.group({
      personalDetail: this._fb.group({
        title: ['', [Validators.required]],
        firstName: ['', [Validators.required]],
        middleName: ['', [Validators.required]],
        lastName: ['', [Validators.required]],
        gender: ['', [Validators.required]],
        dob: ['', [Validators.required]],
        age: ['', [Validators.required]],
      }),
    });
  }
}
