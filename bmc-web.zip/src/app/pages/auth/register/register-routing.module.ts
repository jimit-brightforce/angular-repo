import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'choose',
    loadComponent: () =>
      import('./components/choose/choose.component').then(m => m.ChooseComponent),
  },
  {
    path: 'care-provider',
    loadComponent: () =>
      import('./components/care-providers/care-providers.component').then(
        m => m.CareProvidersComponent
      ),
  },
  {
    path: 'care-professional',
    loadComponent: () =>
      import('./components/care-professional/care-professional.component').then(
        m => m.CareProfessionalComponent
      ),
  },
  {
    path: 'individual',
    loadComponent: () =>
      import('./components/individual/individual.component').then(m => m.IndividualComponent),
  },
  { path: '**', redirectTo: '/notfound' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegisterRoutingModule {}
