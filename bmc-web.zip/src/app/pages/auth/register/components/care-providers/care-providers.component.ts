import { Component } from '@angular/core';

@Component({
  selector: 'app-care-providers',
  standalone: true,
  imports: [],
  templateUrl: './care-providers.component.html',
  styleUrl: './care-providers.component.scss',
})
export class CareProvidersComponent {}
