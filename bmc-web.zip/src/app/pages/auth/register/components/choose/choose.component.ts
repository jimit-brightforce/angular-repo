import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';

@Component({
  selector: 'app-choose',
  standalone: true,
  imports: [CardModule, ButtonModule, RouterLink],
  templateUrl: './choose.component.html',
  styleUrl: './choose.component.scss',
})
export class ChooseComponent {}
