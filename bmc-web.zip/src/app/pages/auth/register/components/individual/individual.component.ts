import { Component, inject } from '@angular/core';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { RegisterService } from '../../services/register.service';
import { Titles } from '@consts';
import { AppDropdownComponent } from '@components';

@Component({
  selector: 'app-individual',
  standalone: true,
  imports: [InputTextModule, FormsModule, ReactiveFormsModule, AppDropdownComponent],
  providers: [RegisterService],
  templateUrl: './individual.component.html',
  styleUrl: './individual.component.scss',
})
export class IndividualComponent {
  private _registerService = inject(RegisterService);
  public readonly titles = Titles;
  individualForm: FormGroup = this._registerService.getIndividualForm();
}
