import { Component } from '@angular/core';

@Component({
  selector: 'app-care-professional',
  standalone: true,
  imports: [],
  templateUrl: './care-professional.component.html',
  styleUrl: './care-professional.component.scss',
})
export class CareProfessionalComponent {}
