import { Component, inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppDropdownComponent } from '@components';

import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { PickListModule } from 'primeng/picklist';
import { ButtonModule } from 'primeng/button';
import { PanelModule } from 'primeng/panel';

import {
  TableColumnDirective,
  TableComponent,
} from 'src/app/shared/components/table/table.component';
import { TableConfig } from 'src/app/shared/components/table/table.model';
import { AppDialogService } from '@services';

@Component({
  selector: 'app-patient-encounter-service',
  standalone: true,
  imports: [
    InputTextModule,
    PanelModule,
    AppDropdownComponent,
    FormsModule,
    ReactiveFormsModule,
    PickListModule,
    ButtonModule,
    TableComponent,
    TableColumnDirective,
    InputNumberModule,
  ],
  templateUrl: './patient-encounter-service.component.html',
  styleUrl: './patient-encounter-service.component.scss',
})
export class PatientEncounterServiceComponent {
  private _appDialog = inject(AppDialogService);

  config: TableConfig = {
    columns: [
      { field: 'coTreatingDoctor', header: 'Co-Treating Doctor', sortable: true, selected: true },
      { field: 'serviceCategory', header: 'Service Category', sortable: true, selected: true },
      { field: 'service', header: 'Service', sortable: true, selected: true },
      { field: 'date', header: 'Date', sortable: true, selected: true },
    ],
    lazy: false,
    globalFilterFields: ['Payer'],
  };
  targetCities: any[] = [];
  tableData = [
    {
      'coTreatingDoctor': 'Deepak Vora',
      'serviceCategory': 'IPD Service',
      'service': 'IPD Registration Charge',
      'date': '15-Apr-2024 02:19 PM',
      'priceListIDP': 1001,
      'quantity': 5,
    },
    {
      'coTreatingDoctor': 'John Smith',
      'serviceCategory': 'OPD Service',
      'service': 'Consultation Fee',
      'date': '15-Apr-2024 03:30 PM',
      'priceListIDP': 1002,
      'quantity': 8,
    },
    {
      'coTreatingDoctor': 'Emily Johnson',
      'serviceCategory': 'Lab Test',
      'service': 'Blood Test',
      'date': '15-Apr-2024 10:00 AM',
      'priceListIDP': 1003,
      'quantity': 10,
    },
  ];
  sourceCities = [
    { name: 'San Francisco', code: 'SF' },
    { name: 'London', code: 'LDN' },
    { name: 'Paris', code: 'PRS' },
    { name: 'Istanbul', code: 'IST' },
    { name: 'Berlin', code: 'BRL' },
    { name: 'Barcelona', code: 'BRC' },
    { name: 'Rome', code: 'RM' },
  ];

  deletePriceList(row) {
    this._appDialog.confirmDelete('Are you sure you want to delete the selected User?', () => {
      this.tableData = this.tableData.filter(res => res.priceListIDP !== row.priceListIDP);
    });
  }
}
