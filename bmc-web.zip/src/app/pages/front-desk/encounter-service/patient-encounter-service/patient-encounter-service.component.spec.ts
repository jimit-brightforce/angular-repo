import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientEncounterServiceComponent } from './patient-encounter-service.component';

describe('PatientEncounterServiceComponent', () => {
  let component: PatientEncounterServiceComponent;
  let fixture: ComponentFixture<PatientEncounterServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PatientEncounterServiceComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(PatientEncounterServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
