export interface EncounterServiceData {
  id: number;
  encounterNumber: string;
  encounterNumberUnique: string;
  encounterDate: Date | string;
  encounterType: string;
  doctorName: string;
  treatingCareProfessionalFullName: string;
  treatingCareProfessionalFirstName: string;
  treatingCareProfessionalMiddleName: string;
  treatingCareProfessionalFamilyName: string;
  treatingCareProfessionalIDP: number;
  episodeIDP: number;
  citizenFullName: Date;
  citizenFirstName: string;
  citizenMiddleName: string;
  citizenFamilyName: string;
  purposeTypeIDP: number;
  purposeType: string;
  payerClassIDP: string;
  payerClassName: string;
  patientServiceDtoCollection: PatientServiceData[]
  patientFacilityDtoCollection: PatientFacility[],
}

export interface PatientServiceData {
  id: number;
  patientEncounterIdf: string;
  serviceMapName: string;
  serviceMapIdf: number;
  encounterServiceNumber: string;
  quantity: number;
  onSetDate:  string | Date;
  voucherServiceIdf: string;
  rate: number;
  amount: number;
  docName: string;
}

export interface PatientFacility{
  facilityIDP: number;
  facility: string;
  utilizationType: number;
  facilityResources: FacilityResource[]
}

export interface FacilityResource{
  facilityResourceIDP: number;
  resourceName: string;
  currentStatus: number;
  startDateTime: Date;
  endDateTime: Date;
  quantity: number;
  remarks: string;
}

