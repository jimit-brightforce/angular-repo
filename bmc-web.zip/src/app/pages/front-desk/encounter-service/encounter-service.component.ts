import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, inject, signal } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

import { InputTextModule } from 'primeng/inputtext';
import { CalendarModule } from 'primeng/calendar';
import { ButtonModule } from 'primeng/button';
import { PanelModule } from 'primeng/panel';

import { TableComponent } from 'src/app/shared/components/table/table.component';
import { FilterEvent, TableConfig } from 'src/app/shared/components/table/table.model';

import { RangeSearchFormComponent } from '@components';
import { EncounterServiceService } from './service/encounter-service.service';
import { DestroyBehavior } from '@strategies';
import { EncounterServiceData } from './interface/encounter-service.interface';
import { finalize, takeUntil } from 'rxjs';
import { DateFormat, MomentFormat } from '@enums';
import { AppDialogService, TRIGGER_FROM, UtilService } from '@services';

@Component({
  selector: 'app-encounter-service',
  standalone: true,
  imports: [
    InputTextModule,
    PanelModule,
    CalendarModule,
    ReactiveFormsModule,
    FormsModule,
    ButtonModule,
    RouterModule,
    TableComponent,
    RangeSearchFormComponent,
  ],
  providers: [EncounterServiceService],
  templateUrl: './encounter-service.component.html',
  styleUrl: './encounter-service.component.scss',
})
export class EncounterServiceComponent extends DestroyBehavior {
  private _encounterServiceService = inject(EncounterServiceService);
  private _appDialogService = inject(AppDialogService);
  private _utilsService = inject(UtilService);

  encounterServiceListBody: FilterEvent;
  tableData = signal<EncounterServiceData[]>([]);
  private _router = inject(Router);

  config: TableConfig = {
    columns: [
      {
        field: 'encounterDate',
        header: 'Date',
        sortable: true,
        selected: true,
        dateFormat: DateFormat.mediumWithSeperator,
      },
      { field: 'citizenFullName', header: 'Patient', sortable: true, selected: true },
      { field: 'episodeType', header: 'Type', sortable: true, selected: true },
      {
        field: 'treatingCareProfessionalFullName',
        header: 'Doctor',
        sortable: true,
        selected: true,
      },
      { field: 'encounterNumber', header: 'Encounter No', sortable: true, selected: true },
      { field: 'encounterType', header: 'Encounter Type', sortable: true, selected: true },
      { field: 'payerClassName', header: 'Payer', sortable: true, selected: true },
      { field: 'bedNumber', header: 'Bed No', sortable: true, selected: true },
    ],
    lazy: true,
    isShowDateRange: true,
    loading: true,
    totalRecords: 0,
    rangeDate: [new Date(), new Date()],
    rangeDateFormat: MomentFormat.mediumWithSeperator,
    isShowMonthDropdown: true,
    selectedMonthDropdown: 1,
  };

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    if (event.searchKey) {
      event.search.push({
        columnName: 'searchString',
        searchString: event.searchKey as string,
      });
      event.searchKey = null;
    }
    this.encounterServiceListBody = event;
    this._encounterServiceService
      .getEncounterServiceList(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.tableData.set(
          res.responseObject.map(obj => {
            obj.encounterDate = this._utilsService.getDateByZone(obj.encounterDate.toString());
            return obj;
          })
        );
        this.config.totalRecords = res.totalRecords;
      });
  }

  rowClickEvent(row, type = 1) {
    const payload = {
      patientEpisodeIDP: row.episodeIDP,
      patientProfileIDP: row.patientProfileId,
      patientName: row.citizenFullName,
      episodeDate: row.episodeDate,
      payerClassIDP: row.payerClassIDP,
      payerClass: row.payerClassName,
      purposeTypeIDP: row.purposeTypeIDP,
      purposeType: row.purposeType,
      episodeNumber: row.episodeNumber,
      bedNumber: row.bedNumber,
      episodeTypeId: row.episodeTypeId,
      episodeType: row.episodeType,
      citizenIDP: row.citizenIDP,
      treatingCareProfessionalIDP: row.treatingCareProfessionalIDP,
      treatingCareProfessionalFirstName: row.treatingCareProfessionalFirstName,
      treatingCareProfessionalMiddleName: row.treatingCareProfessionalMiddleName,
      treatingCareProfessionalFamilyName: row.treatingCareProfessionalFamilyName,
      treatingCareProfessionalFullName: row.treatingCareProfessionalFullName,
      patientFacilityDtoCollection: row.patientFacilityDtoCollection,
      patientServiceDtoCollection: row.patientServiceDtoCollection,
      patientEncounterIDP: row.id,
      encounterType: row.encounterType,
      encounterDate: row.encounterDate,
      encounterNumber: row.encounterNumber,
      id: row.id,
    };
    const modalRef = this._appDialogService.openPatientEncounterModel(
      type,
      TRIGGER_FROM.encounterService,
      payload
    );
    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(data => {
      if (data) {
        this.filterEvent(this.encounterServiceListBody);
      }
    });
  }
}
