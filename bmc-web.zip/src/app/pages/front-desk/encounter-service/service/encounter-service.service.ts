/* eslint-disable @typescript-eslint/no-unused-vars */
import { Injectable, inject } from '@angular/core';
import { FilterEvent } from '@components';
import { API_FOLDER } from '@consts';
import { ActionApiResponse, ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { EncounterServiceData } from '../interface/encounter-service.interface';

@Injectable()
export class EncounterServiceService {
  private _apiService = inject(ApiServices);

  getEncounterServiceList(payload: FilterEvent) {
     return this._apiService.post<ListApiResponse<EncounterServiceData>>(
      `/v1/${API_FOLDER.frontDesk}/patient-encounter/page-multi-search`,
      payload
    ); 
  }

  savePatientEncounterService(payload){
    return this._apiService.put<ActionApiResponse<any>>(
      `/v1/${API_FOLDER.frontDesk}/patient-encounter/update-services`,
      payload
    );
  }
}
