import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EncounterServiceComponent } from './encounter-service.component';

describe('EncounterServiceComponent', () => {
  let component: EncounterServiceComponent;
  let fixture: ComponentFixture<EncounterServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EncounterServiceComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(EncounterServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
