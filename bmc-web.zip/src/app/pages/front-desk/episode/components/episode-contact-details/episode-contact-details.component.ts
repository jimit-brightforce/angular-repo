import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  inject,
  input,
  model,
  OnInit,
  signal,
} from '@angular/core';
import {
  FormsModule,
  ReactiveFormsModule,
  FormGroup,
  Validators,
  FormGroupDirective,
} from '@angular/forms';
import {
  AppDropdownComponent,
  TableColumnDirective,
  TableComponent,
  TableConfig,
} from '@components';
import { FormRequiredMessage, ValidDetailMessage } from '@consts';
import { InputTrimDirective } from '@directives';
import { ContactTypeEnum, ReferenceTypeIDP } from '@enums';
import {
  UtilService,
  DataService,
  CommonDropdownApiService,
  AppDialogService,
  AuthService,
} from '@services';
import { DestroyBehavior } from '@strategies';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { TagModule } from 'primeng/tag';
import { contactInfoModel } from 'src/app/shared/components/patient-info/interface/patient-info.interface';
import { ContactInfoApiService } from 'src/app/shared/components/patient-info/services';

@Component({
  selector: 'app-episode-contact-details',
  standalone: true,
  imports: [
    InputTextModule,
    FormsModule,
    AppDropdownComponent,
    ReactiveFormsModule,
    FloatLabelModule,
    CheckboxModule,
    InputGroupModule,
    InputGroupAddonModule,
    InputTrimDirective,
    ButtonModule,
    TagModule,

    TableComponent,
    TableColumnDirective,
  ],
  templateUrl: './episode-contact-details.component.html',
  styleUrl: './episode-contact-details.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [ContactInfoApiService],
})
export class EpisodeContactDetailsComponent extends DestroyBehavior implements OnInit {
  private _utillService = inject(UtilService);
  private _dataService = inject(DataService);
  private _commonDropdownApiService = inject(CommonDropdownApiService);
  private _fgd = inject(FormGroupDirective);
  private _appDialog = inject(AppDialogService);
  private _cd = inject(ChangeDetectorRef);
  private _authService = inject(AuthService);
  public readonly RequiredMessage = FormRequiredMessage;
  public readonly validDetailsMessage = ValidDetailMessage;

  childFormName = input<string>('contactInfo');
  contactInfo = model<contactInfoModel[]>([]);
  contactTypeDropdown = this._dataService.contactTypeDropdown;
  //   contactTypeEnum = ContactTypeEnum;
  form: FormGroup;
  isLoading = signal<boolean>(false);
  tableConfig: TableConfig = {
    columns: [
      { field: 'contactName', header: 'Type', selected: true },
      { field: 'contactDetails', header: 'Details', selected: true },
    ],
    lazy: false,
    searchBar: false,
    paginator: false,
    showIndex: false,
  };
  ngOnInit(): void {
    this.form = this._fgd.form.get(this.childFormName()) as FormGroup;
    this._commonDropdownApiService.getMetaForContactType();

    // contact number can not created if mobile number is already available
    // only availble while updating mobile number
    // this.contactTypeDropdown.update(contact => {
    //   const isMobileAvailable = contactInfo.some(
    //     (r: contactInfoModel) => r.contactTypeIDP == ContactTypeEnum.Mobile
    //   );
    //   if (isMobileAvailable && !(this.contactDetails?.contactTypeIDP === ContactTypeEnum.Mobile)) {
    //     contact = contact.filter(c => c.contactTypeIDP != ContactTypeEnum.Mobile);
    //   }
    //   return contact;
    // });

    // const modalRef = this.dialogService.getInstance(this.dynamicDialogRef);
  }
  contactInfoFormcontrol(formcontrol: string): boolean {
    return this.form.controls[formcontrol].invalid && this.form.controls[formcontrol].dirty;
  }

  saveContactInfo() {
    if (this.form.invalid) {
      this._utillService.markFormGroupDirty(this.form);
      return;
    }

    const { contactTypeIDP } = this.form.value;
    const contactName = this.contactTypeDropdown().find(
      i => i.contactTypeIDP === contactTypeIDP
    ).contactType;
    this.contactInfo().push({
      ...this.form.value,
      contactName: contactName,
      primary: false,
      referenceTypeIDP: ReferenceTypeIDP.Citizen,
      careProviderIDP: this._authService.userInfo().careProviderIDP,
    });

    this.resetForm();
  }

  contactTypeSelected(event) {
    if (event.value === ContactTypeEnum.Email) {
      this.form
        .get('contactDetails')
        .setValidators([Validators.required, Validators.maxLength(49), Validators.email]);
    } else if (event.value === ContactTypeEnum.Mobile) {
      this.form
        .get('contactDetails')
        .setValidators([
          Validators.required,
          Validators.maxLength(13),
          Validators.pattern('^[0-9]*$'),
        ]);
    } else {
      this.form
        .get('contactDetails')
        .setValidators([Validators.required, Validators.maxLength(99)]);
    }
    this.form.get('contactDetails').updateValueAndValidity();
  }

  primaryContact(i: number) {
    this.contactInfo.update(add => {
      add.map((element, index) => {
        if (index !== i) {
          element.primary = false;
        }
      });
      return add;
    });
    this._cd.detectChanges();
  }

  deleteContact(row, i: number) {
    // event.stopPropagation();
    this._appDialog.confirmDelete(
      `Are you sure you want to Remove ${row.contactName} Contact Information?`,
      () => {
        this.contactInfo().splice(i, 1);
        this._cd.detectChanges();
      }
    );
  }

  resetForm() {
    this.form.reset({
      active: true,
    });
  }
}
