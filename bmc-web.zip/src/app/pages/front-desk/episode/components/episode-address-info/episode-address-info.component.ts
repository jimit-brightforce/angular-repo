import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  inject,
  input,
  model,
  OnInit,
  signal,
} from '@angular/core';
import {
  FormGroup,
  FormGroupDirective,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import {
  AppDropdownComponent,
  FilterEvent,
  TableColumnDirective,
  TableComponent,
  TableConfig,
} from '@components';
import { FormRequiredMessage } from '@consts';
import { InputTrimDirective } from '@directives';
import { ReferenceTypeIDP } from '@enums';
import { UtilService, AuthService, AddressDataService, AppDialogService } from '@services';
import { DestroyBehavior } from '@strategies';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputTextModule } from 'primeng/inputtext';
import { Subject, takeUntil, switchMap, map } from 'rxjs';
import {
  AddressInfoModel,
  AreaCityStateCountryModel,
} from 'src/app/shared/components/patient-info/interface/patient-info.interface';
import { AddressInfoApiService } from 'src/app/shared/components/patient-info/services';

@Component({
  selector: 'app-episode-address-info',
  standalone: true,
  imports: [
    InputTextModule,
    FormsModule,
    AppDropdownComponent,
    ReactiveFormsModule,
    ButtonModule,
    FloatLabelModule,
    CheckboxModule,
    InputTrimDirective,
    TableComponent,
    TableColumnDirective,
  ],
  templateUrl: './episode-address-info.component.html',
  styleUrl: './episode-address-info.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [AddressInfoApiService],
})
export class EpisodeAddressInfoComponent extends DestroyBehavior implements OnInit {
  childFormName = input<string>('addressInfo');
  private _utillService = inject(UtilService);
  private _authService = inject(AuthService);
  private _addressDataService = inject(AddressDataService);
  private _fgd = inject(FormGroupDirective);
  private _appDialog = inject(AppDialogService);
  private _cd = inject(ChangeDetectorRef);
  public readonly RequiredMessage = FormRequiredMessage;
  form: FormGroup;
  searchAddress = new Subject<FilterEvent>();
  adressDetails = model.required<AddressInfoModel[]>();
  addressTypeDropdown = this._addressDataService.addressTypeDropdown;
  isLoading = signal<boolean>(false);
  areaCityStateCountryDropdown = signal<AreaCityStateCountryModel[]>([]);
  tableConfig: TableConfig = {
    columns: [
      { field: 'addressTypeName', header: 'Address Type', selected: true },
      {
        field: 'address',
        header: 'Address',
        selected: true,
      },
      {
        field: 'areaName',
        header: 'Area',
        selected: true,
      },
      { field: 'cityName', header: 'City', selected: true },
      { field: 'postalCode', header: 'Postal Code', selected: true },
      { field: 'stdCode', header: 'STD Code', selected: true },
    ],
    lazy: false,
    searchBar: false,
    paginator: false,
    showIndex: false,
  };
  ngOnInit(): void {
    this.form = this._fgd.form.get(this.childFormName()) as FormGroup;
    this._addressDataService.getMetaForAddressType();
    this.searchAddress
      .pipe(
        takeUntil(this.notifier),
        switchMap((param: FilterEvent) =>
          this._addressDataService.getMetaForcountryStateCityArea(param)
        ),
      )
      .subscribe({
        next: res => {
          this.areaCityStateCountryDropdown.set(res.responseObject);
        },
      });

    if (this.form.value.areaCityStateCountry) {
      this.getAddressDropdown();
    }
  }

  addressInfoFormcontrol(formcontrol: string): boolean {
    return this.form.controls[formcontrol].invalid && this.form.controls[formcontrol].dirty;
  }

  getAddressDropdown(searchKey: string = '') {
    const param: FilterEvent = {
      page: 0,
      size: 20, // will be changed after API improvement
      searchKey: searchKey ?? null,
      sort: null,
    };

    this.searchAddress.next(param);
  }

  saveAdressInfo() {
    if (this.form.invalid) {
      this._utillService.markFormGroupDirty(this.form);
      return;
    }
    const [areaName, cityName] = this.form.value.areaCityStateCountry.split(',');
    // API CALL HERE ON CONDITON OF EDIT OR SAVE
    const param: AddressInfoModel = {
      addressTypeIDP: this.form.value.addressType,
      address1: this.form.value.address1,
      address2: this.form.value.address2,
      // areaCityStateCountry: this.form.value.areaCityStateCountry,
      postalCode: this.form.value.zipCode,
      //   STDCode: this.form.value.STDCode,
      careProviderIDP: this._authService.userInfo().careProviderIDP,

      //   careProfessionalIDP': 1,
      referenceTypeIDP: ReferenceTypeIDP.Citizen,
      cityIDP: this.areaCityStateCountryDropdown().find(
        r => r.cityName === this.form.value.areaCityStateCountry
      ).cityIDP,
      areaIDF: this.areaCityStateCountryDropdown().find(
        r => r.cityName === this.form.value.areaCityStateCountry
      ).areaIDF,
      area: this.form.value.area,
      primary: false,

      //   External Value that only for show in table

      //   areaCityStateCountry: this.form.value.areaCityStateCountry,
      addressTypeName: this.addressTypeDropdown().find(
        r => r.addressTypeIDP === this.form.value.addressType
      ).addressType,
      address: this.form.value.address1 + ' , ' + this.form.value.address2,
      areaName: this.form.value.area || areaName,
      cityName: cityName,
      referenceIDF: 0,
      citizenIDP: 0,
    };
    this.adressDetails().push(param);
    this.form.reset();
  }

  changeArea() {
    const changeArea = this.form.value.changeArea;
    if (changeArea) {
      this.form.get('area').setValidators([Validators.required]);
    } else {
      this.form.get('area').clearValidators();
    }
    this.form.get('area').updateValueAndValidity();
  }

  primaryAddress(i: number) {
    this.adressDetails.update(add => {
      add.map((element, index) => {
        if (index !== i) {
          element.primary = false;
        }
      });
      return add;
    });
    this._cd.detectChanges();
  }

  deleteAddressInfo(row: AddressInfoModel, i: number) {
    this._appDialog.confirmDelete(`Are you sure you want to delete ${row.addressTypeName}?`, () => {
      this.adressDetails.update(add => {
        add.splice(i, 1);
        return add;
      });
      this._cd.detectChanges();
    });
  }
}
