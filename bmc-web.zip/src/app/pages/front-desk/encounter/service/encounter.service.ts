import { Injectable, inject } from '@angular/core';
import { FilterEvent } from '@components';
import { API_FOLDER } from '@consts';
import { ActionApiResponse, ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { EncounterData } from '../interface/encounter.interface';
import { FormBuilder, Validators } from '@angular/forms';
@Injectable()
export class EncounterService {
  private _apiService = inject(ApiServices);
  private _fb = inject(FormBuilder);

  patientEncounterForm() {
    return this._fb.group({
      citizenIDP:[],
      payerClassIDP:[],
      encounterTypeIDP: ['',[Validators.required]],
      encounterMode: [],
      patientEpisodeIDP: [],
      patientProfileIDP: [],
      careProfessionalIDPT: [],
      careProfessional: [],
      careProfessionalIDPC: [],
      careProfessionalIDPR: [],
      assistantIDF: [],
      remarks1: [],
      isGroupOPD: [false],
      printOrderSheet: [true],
      generateVoucher:[true],
      sendSMS:[true],
      serviceCategory:[],
      reportingDoctor:[],
      facilityForm: this._fb.group({
        facilityType: [''],
        facilityGroup: [''],
        availableFacility: this._fb.array([]),
      }),
    });
  }

  getAddAvailableFacilityForm() {
    return this._fb.group({
      facilityIDP: [],
      isSelected: [false],
      facilityName: [],
      facilitySourceName: [],
      facilityResourceIDP: [],
      startDateTime: [new Date()],
      endDateTime: [new Date()],
      remark: [],
      status: [],
      currentStatus: [],
      currentStatusStr: [],
    });
  }

  getEncounterList(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<EncounterData>>(
      `/v1/${API_FOLDER.frontDesk}/patient-episode/page-multi-search`,
      payload
    );
    
  }

  updatecareProfessional(payload) {
    return this._apiService.put<ActionApiResponse<EncounterData>>(
      `/v1/${API_FOLDER.frontDesk}/patient-episode`,
      payload
    );
  }

  savePatientEncounter(payload){
    if (payload.patientEncounterIDP) {
      return this._apiService.put<ActionApiResponse<any>>(
        `/v1/${API_FOLDER.frontDesk}/patient-encounter`,
        payload
      );
    }
    return this._apiService.post<ActionApiResponse<any>>(
      `/v1/${API_FOLDER.frontDesk}/patient-encounter`,
      payload
    );
  }

  getEncounterDetail(encounterID) {
    return this._apiService.get<ActionApiResponse<EncounterData>>(
      `/v1/${API_FOLDER.frontDesk}/patient-episode/${encounterID}`
    );    
  }

  getVoucherDetail(id) {
    return this._apiService.get<ListApiResponse<EncounterData>>(
      `/v1/${API_FOLDER.frontDesk}/voucher/by-patient-encounter/${id}`
    );  
  }

  
}
