import { CommonModule } from '@angular/common';
import { Component, ViewChild, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {
  TableComponent,
  RangeSearchFormComponent,
  TableConfig,
  TableColumnDirective,
  TableExpandableRowDirective,
  FilterEvent,
} from '@components';
import { AppDialogService, CommonDropdownApiService, DataService, TRIGGER_FROM, UtilService } from '@services';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TooltipModule } from 'primeng/tooltip';
import { EncounterService } from './service/encounter.service';
import { EncounterData, PatientEncountersData } from './interface/encounter.interface';
import { finalize, takeUntil } from 'rxjs';
import { DestroyBehavior } from '@strategies';
import { DateFormat, MomentFormat, SlugMap } from '@enums';
import { DropdownModule } from 'primeng/dropdown';
import { ActionPermissionDirective, PermissionMap } from '@directives';

@Component({
  selector: 'app-encounter',
  standalone: true,
  imports: [
    CommonModule,
    InputTextModule,
    PanelModule,
    ReactiveFormsModule,
    FormsModule,
    ButtonModule,
    RouterModule,
    RangeSearchFormComponent,
    TooltipModule,
    TableComponent,
    TableColumnDirective,
    DropdownModule,
    TableExpandableRowDirective,
    ActionPermissionDirective
  ],
  providers: [AppDialogService, EncounterService],
  templateUrl: './encounter.component.html',
  styleUrl: './encounter.component.scss',
})
export class EncounterComponent extends DestroyBehavior {
  @ViewChild('table') table: TableComponent;
  private _encounterService = inject(EncounterService);
  private _appDialogService = inject(AppDialogService);
  private _dataService = inject(DataService);
  private _commonDropdownApiService = inject(CommonDropdownApiService);
  private _utilsService = inject(UtilService);
  protected readonly PermissionMap = PermissionMap;
  protected readonly SlugMap = SlugMap;
  encounterListBody: FilterEvent;
  tableData = signal<EncounterData[]>([]);

  config: TableConfig = {
    columns: [
      {
        field: 'episodeDate',
        header: 'Date',
        sortable: true,
        selected: true,
        dateFormat: DateFormat.mediumWithSeperator,
      },
      { field: 'episodeNumber', header: 'Episode No', selected: true, sortable: true },
      { field: 'episodeType', header: 'Type', sortable: true, selected: true },
      { field: 'payerClass', header: 'Payer', sortable: true, selected: true },
      { field: 'bedNumber', header: 'Bed No', sortable: true, selected: true },
      { field: 'patientName', header: 'Patient', sortable: true, selected: true },
      { field: 'purposeType', header: 'Purpose', selected: true },
    ],
    lazy: true,
    dataKey: 'patientEpisodeIDP',
    expandable: true,
    isShowDateRange: true,
    loading: true,
    totalRecords: 0,
    rangeDate: [new Date(), new Date()],
    rangeDateFormat: MomentFormat.mediumWithSeperator,
    isShowMonthDropdown: true,
    selectedMonthDropdown: 1,
    expansionField: 'patientEncounters',
  };

  subTableConfig: TableConfig = {
    columns: [
      { field: 'encounterNumber', header: 'Encounter No.', sortable: true, selected: true },
      {
        field: 'encounterDate',
        header: 'Date',
        sortable: true,
        selected: true,
        dateFormat: DateFormat.mediumWithSeperator,
      },
      { field: 'doctorName', header: 'Doctor', sortable: true, selected: true },
    ],
    lazy: false,
    dataKey: 'id',
    searchBar: false,
    paginator: false,
    showIndex: false,
  };

  careProfessionalDropdown = this._dataService.careProfessionalDropdown;

  constructor() {
    super();
    this._commonDropdownApiService.getMetaForCareProfessional();
  }

  openOrderList() {
    const modalData = {
      isEncounterList: true,
    };
    this._appDialogService.openOrderListModal(TRIGGER_FROM.encounter, modalData);
  }

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    if (event.searchKey) {
      event.search.push({
        columnName: 'searchString',
        searchString: event.searchKey as string,
      });
      event.searchKey = null;
    }
    this.encounterListBody = event;
    this._encounterService
      .getEncounterList(event)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe(res => {
        this.tableData.set(res.responseObject.map(obj => {
          obj.encounterDate = this._utilsService.getDateByZone(obj.encounterDate);
          return obj;
        }));
        this.config.totalRecords = res.totalRecords;
      });
  }

  createEncounter(row: EncounterData, type: number = 0) {
    const payload = {
      patientEpisodeIDP: row.patientEpisodeIDP,
      patientProfileIDP: row.patientProfileId,
      patientName: row.patientName,
      episodeDate: row.episodeDate,
      payerClassIDP: row.payerClassIDP,
      payerClass: row.payerClass,
      purposeTypeIDP: row.purposeTypeIDP,
      purposeType: row.purposeType,
      episodeNumber: row.episodeNumber,
      bedNumber: row.bedNumber,
      episodeTypeId: row.episodeTypeId,
      episodeType: row.episodeType,
      citizenIDP: row.citizenIDP,
      treatingCareProfessionalIDP: row.treatingCareProfessionalIDP,
      treatingCareProfessionalFirstName: row.treatingCareProfessionalFirstName,
      treatingCareProfessionalMiddleName: row.treatingCareProfessionalMiddleName,
      treatingCareProfessionalFamilyName: row.treatingCareProfessionalFamilyName,
      treatingCareProfessionalFullName: row.treatingCareProfessionalFullName,
      patientEncounters: row.patientEncounters,
    };
    const modalRef = this._appDialogService.openPatientEncounterModel(
      type,
      TRIGGER_FROM.encounter,
      payload
    );
    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(data => {
      if (data) {
        this.filterEvent(this.encounterListBody);
        this.table.table.expandedRowKeys = {};
      }
    });
  }

  updateEncounter(subRow: PatientEncountersData, type: number = 1) {
    const row = subRow['parent'] as EncounterData;
    const payload = {
      patientEpisodeIDP: row.patientEpisodeIDP,
      patientProfileIDP: row.patientProfileId,
      patientName: row.patientName,
      episodeDate: row.episodeDate,
      payerClassIDP: subRow.payerClassIDP,
      payerClass: subRow.payerClassName,
      purposeTypeIDP: subRow.purposeTypeIDP,
      purposeType: subRow.purposeType,
      episodeNumber: row.episodeNumber,
      bedNumber: row.bedNumber,
      encounterTypeIDP: subRow.encounterTypeIDP,
      episodeType: row.episodeType,
      citizenIDP: row.citizenIDP,
      treatingCareProfessionalIDP: subRow.treatingCareProfessionalIDP,
      treatingCareProfessionalFirstName: subRow.treatingCareProfessionalFirstName,
      treatingCareProfessionalMiddleName: subRow.treatingCareProfessionalMiddleName,
      treatingCareProfessionalFamilyName: subRow.treatingCareProfessionalFamilyName,
      treatingCareProfessionalFullName: subRow.treatingCareProfessionalFullName,
      patientFacilityDtoCollection: subRow.patientFacilityDtoCollection,
      patientServiceDtoCollection: subRow.patientServiceDtoCollection,
      patientEncounterIDP: subRow.id,
      encounterModeIDP: subRow.encounterModeIDP,
      encounterMode: subRow.encounterMode,
      remarks: subRow.remarks,
      assistantEmployeeIDP: subRow.assistantEmployeeIDP,
      coTreatingCareProfessionalIDP: subRow.coTreatingCareProfessionalIDP,
      patientEncounters: row.patientEncounters,
      id: subRow.id,
      referenceCareProfessionalIDP: subRow.referenceCareProfessionalIDP,
    };
    const modalRef = this._appDialogService.openPatientEncounterModel(
      type,
      TRIGGER_FROM.encounter,
      payload
    );
    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(data => {
      if (data) {
        this.filterEvent(this.encounterListBody);
        this.table.table.expandedRowKeys = {};
      }
    });
  }

  onCellEdit(row, column: string) {
    row.editMode = column;
    row.originalValue = row[column];
  }

  saveCellEdit(row, column) {
    if (row.originalValue == row[column]) {
      this.cancelEditMode(row, column);
      return;
    }
    const payload = {
      episodeIDP: row.patientEpisodeIDP,
      careProfessionalIDPT: row[column],
    };
    this._encounterService
      .updatecareProfessional(payload)
      .pipe(takeUntil(this.notifier))
      .subscribe(res => {
        row.treatingCareProfessionalFamilyName =
          res.responseObject.treatingCareProfessionalFamilyName;
        row.treatingCareProfessionalFirstName =
          res.responseObject.treatingCareProfessionalFirstName;
        row.treatingCareProfessionalFullName = res.responseObject.treatingCareProfessionalFullName;
        row.treatingCareProfessionalMiddleName =
          res.responseObject.treatingCareProfessionalMiddleName;
        row.treatingCareProfessionalIDP = row[column];
        row.editMode = null; // Exit edit mode
        row[column] = row.treatingCareProfessionalIDP; // Restore the original value
      });
  }

  cancelEditMode(row, column: string) {
    row.editMode = null; // Exit edit mode
    row[column] = row.originalValue; // Restore the original value
  }

  rowToggleEvent(row) {
    //PREVENT API CALL IF ROW IS ALREADY EXPANDED AND SUBTABLE DATA IS ALREADY LOADED
    if (row.expanded || row.subTableData) {
      return;
    }

    //SOME API CALL TO GET SUBTABLE DATA

    row.subTableData = this.tableData;
  }
}
