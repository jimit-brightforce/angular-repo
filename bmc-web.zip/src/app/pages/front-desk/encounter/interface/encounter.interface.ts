import { VoucherOptedServiceData } from "../../voucher/interface/voucher.interface";

export interface EncounterData {
  patientEpisodeIDP: number;
  citizenIDP: number;
  patientName: string;
  patientProfileId: number;
  episodeTypeId: number;
  episodeType: string;
  payerClassIDP: number;
  payerClass: string;
  bedNumber: string;
  episodeNumber: string;
  purposeTypeIDP: number;
  purposeType: string;
  docName: string;
  treatingCareProfessionalFullName: string;
  treatingCareProfessionalFirstName: string;
  treatingCareProfessionalMiddleName: string;
  treatingCareProfessionalFamilyName: string;
  treatingCareProfessionalIDP: number;
  episodeDate: string;
  patientEncounters: PatientEncountersData[] | [];
  voucherOptedServiceDtoList?: VoucherOptedServiceData[],
  encounterDate?: string;
}

export interface PatientEncountersData {
  id: number;
  encounterNumber: string;
  encounterNumberUnique: number;
  encounterDate: string;
  encounterTypeIDP: number;
  encounterType: string;
  doctorName: string;
  treatingCareProfessionalFullName: string;
  treatingCareProfessionalFirstName: string;
  treatingCareProfessionalMiddleName: string;
  treatingCareProfessionalFamilyName: string;
  treatingCareProfessionalIDP: number;
  episodeIDP: number;
  purposeTypeIDP: number;
  purposeType: string;
  payerClassIDP: number;
  payerClassName: string;
  patientServiceDtoCollection: PatiendEncounterServiceData[];
  patientFacilityDtoCollection: [];
  encounterModeIDP?: string;
  encounterMode?: string;
  remarks?: string;
  assistantEmployeeIDP?: string;
  referenceCareProfessionalIDP?: string;
  coTreatingCareProfessionalIDP?: string;
}

export interface PatiendEncounterModelData {
  id?: number;
  appointmentIDP: number;
  citizenFirstName: string;
  citizenMiddleName: string;
  citizenFamilyName: string;
  patientProfileIDP: number;
  citizenIDP: number;
  patientName?: string;
  episodeDate?: Date;
  payerClassIDP?: string;
  payerClass?: string;
  purposeTypeIDP?: string;
  purposeType?: string;
  episodeNumber?: string;
  bedNumber?: string;
  episodeTypeId?: number;
  episodeType?: string;
  treatingCareProfessionalIDP?: number;
  treatingCareProfessionalFirstName?: string;
  treatingCareProfessionalMiddleName?: string;
  treatingCareProfessionalFamilyName?: string;
  treatingCareProfessionalFullName?: string;
  patientEpisodeIDP: number;
  patientFacilityDtoCollection?: EncounterFacilityData[];
  patientServiceDtoCollection?: PatiendEncounterServiceData[];
  patientEncounterIDP?: number;
  encounterTypeIDP?: string;
  encounterType?: string;
  encounterModeIDP?: string;
  encounterMode?: string;
  remarks?: string;
  assistantEmployeeIDP?: string;
  referenceCareProfessionalIDP?: string;
  coTreatingCareProfessionalIDP?: string;
  encounterDate?: string;
  encounterNumber?: string;
  patientEncounters: PatientEncountersData[] | [];
  encounterDeletedServiceDtoCollection: EncounterServiceData[];
}

export interface PatiendEncounterServiceData {
  id: number;
  patientEncounterIdf: string;
  serviceMapName: string;
  serviceMapIdf: number;
  encounterServiceNumber: string;
  quantity: number;
  onSetDate: string;
  onsetDateStr?: string;
  voucherServiceIdf: string;
  rate: number;
  amount: number;
  docName: string;
  serviceAlias?: string;
  serviceIDF: number;
  serviceName: string;
  serviceCategoryIDF: number;
  serviceCategory: string;
  isCreatedVoucher?: boolean;
}

export interface PatiendEncounterFormData {
  patientEncounterIDP?: number;
  encounterTypeIDP: number;
  encounterMode: number;
  patientEpisodeIDP: number;
  patientProfileIDP: number;
  careProfessionalIDPT: number;
  careProfessionalIDPC: number;
  careProfessionalIDPR: number;
  assistantIDF: number;
  remarks1: string;
  encounterRequestServiceDtoCollection: EncounterServiceData[];
  encounterDeletedServiceDtoCollection: EncounterServiceData[];
  encounterRequestFacilityDtoCollection: EncounterFacilityData[];
  printOrderSheet: boolean;
  printVoucher: boolean;
  sendSms: boolean;
}
export interface EncounterServiceData {
  serviceDoctorID: string;
  serviceMapID: string | number;
  qty: string | number;
  rate: string | number;
  grossAmt: string | number;
  rowStatus: string | number;
  id?: string | number;
}

export interface EncounterFacilityData {
  facilityIDP: number;
  facility: string;
  utilizationType?: number;
  facilityResources?: FacilityResourceData[];
}

export interface FacilityResourceData {
  facilityResourceIDP: number;
  resourceName: string;
  currentStatus: number;
  startDateTime: string;
  endDateTime: string;
  quantity: number;
  remarks: string;
  currentStatusStr: string;
}

export interface PatiendEncounterServiceFormData {
  patientEncounterIDP?: number;
  encounterRequestServiceDtoCollection: EncounterServiceData[];
  encounterDeletedServiceDtoCollection: EncounterServiceData[];
  printOrderSheet: boolean;
  sendSms: boolean;
}
