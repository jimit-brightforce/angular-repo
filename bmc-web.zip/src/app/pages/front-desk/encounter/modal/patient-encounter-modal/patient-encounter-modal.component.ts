import { Component, OnInit, computed, inject, model, signal } from '@angular/core';
import { EncounterService } from '../../service/encounter.service';
import { DestroyBehavior } from '@strategies';
import { DataService, TRIGGER_FROM, ToastService, UtilService } from '@services';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import {
  EncounterFacilityData,
  FacilityResourceData,
  PatiendEncounterFormData,
  PatiendEncounterModelData,
  PatiendEncounterServiceFormData,
} from '../../interface/encounter.interface';
import { EpisodeService } from '../../../episode/services/episode.service';
import { PatientQuickRegistrationService } from '../../../patient-quick-registration/service/patient-quick-registration.service';
import { PriceListDropdown } from 'src/app/pages/service-config/price-list-details/interface/price-list-details.interface';
import { finalize, map, takeUntil } from 'rxjs';
import { FormArray, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { AppDropdownComponent, TableColumnDirective, TableComponent, TableConfig } from '@components';
import {
  CareProfessionalDropdown,
  Facility,
  FacilityResource,
  SelectedServiceList,
} from '../../../episode/interface/episode.interface';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputTextModule } from 'primeng/inputtext';
import { TabViewModule } from 'primeng/tabview';
import { PanelModule } from 'primeng/panel';
import { AvatarModule } from 'primeng/avatar';
import { DividerModule } from 'primeng/divider';

import * as moment from 'moment';
import { CheckboxModule } from 'primeng/checkbox';
import { DateFormat, MomentFormat } from '@enums';
import { CommonModule } from '@angular/common';
import { InputNumberModule } from 'primeng/inputnumber';
import { Router, RouterModule } from '@angular/router';
import { CalendarModule } from 'primeng/calendar';
import { EncounterServiceService } from '../../../encounter-service/service/encounter-service.service';
import { cloneDeep } from 'lodash';
import { FormatDatePipe } from 'src/app/shared/pipe/format-date.pipe';
import { TagModule } from 'primeng/tag';
import { groupBy, flatMap } from 'lodash';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { VoucherOptedServiceData } from '../../../voucher/interface/voucher.interface';

@Component({
  selector: 'app-patient-encounter-modal',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    AppDropdownComponent,
    FloatLabelModule,
    InputTextModule,
    TabViewModule,
    PanelModule,
    CheckboxModule,
    InputNumberModule,
    RouterModule,
    CalendarModule,
    AvatarModule,
    TableComponent,
    TableColumnDirective,
    DividerModule,
    FormatDatePipe,
    TagModule,
    ProgressSpinnerModule
  ],
  templateUrl: './patient-encounter-modal.component.html',
  styleUrl: './patient-encounter-modal.component.scss',
  providers: [
    EncounterService,
    EpisodeService,
    PatientQuickRegistrationService,
    EncounterServiceService,
  ],
})
export class PatientEncounterModalComponent extends DestroyBehavior implements OnInit {
  private _utilService = inject(UtilService);
  private _dialogService = inject(DialogService);
  private _dataService = inject(DataService);
  private _dynamicDialogRef = inject(DynamicDialogRef);
  private _episodeService = inject(EpisodeService);
  private _encounterService = inject(EncounterService);
  private _encounterServiceService = inject(EncounterServiceService);
  private _patientQuickRegistrationService = inject(PatientQuickRegistrationService);
  private _toast = inject(ToastService);
  private _router = inject(Router);

  encounterTypeDropdown = this._dataService.encounterTypeDropdown;
  encounterModeDropdown = this._dataService.encounterModeDropdown;
  assistantDropdown = this._dataService.assistantDropdown;
  careProfessionalDropdown = this._dataService.careProfessionalDropdown;

  careProfessionalGroupDropdown = this._dataService.careProfessionalGroupDropdown;

  facilityGroupDropdown = this._dataService.facilityGroupDropdown;
  facilityTypeDropdown = this._dataService.facilityTypeDropdown;
  serviceCategoryDropdown = this._dataService.serviceCategoryDropdown;

  patientEncounterModalData: PatiendEncounterModelData;
  patientEncounterModalType: number;
  patientEncounterModalFrom: number;

  serviceLists = signal<PriceListDropdown[]>([]);
  selectedServiceList: SelectedServiceList[] = [];
  addSelectedServiceList: SelectedServiceList[] = [];

  patientEncounterForm = this._encounterService.patientEncounterForm();
  reportingDoctor: CareProfessionalDropdown | null = null;

  TRIGGER_FROM = TRIGGER_FROM;

  isOccupied: boolean = true;

  activeIndex: number = 0;
  serviceSerch = model<string>('');
  filterdServiceList = computed(() =>
    this.serviceLists().filter(
      service =>
        this.serviceSerch().trim() === '' ||
        service.serviceAlias.toLowerCase().includes(this.serviceSerch().toLowerCase())
    )
  );

  isShowSelectedServiceList = signal<boolean>(false);
  dateFormat = DateFormat;
  momentFormat = MomentFormat;
  isLoading = signal<boolean>(false);
  totalServiceCost: number = 0;

  voucherOptedServiceData: VoucherOptedServiceData[] = [];

  config: TableConfig = {
    columns: [
      { field: 'onsetDateStr', header: 'OnSet Date', selected: true},
      { field: 'serviceName', header: 'Service', sortable: false, selected: true },
      { field: 'docName', header: 'Reporting Dr.', sortable: false, selected: true },
    ],
    lazy: false,
    searchBar: false,
    paginator: false,
    showIndex: false,
  };

  servicePackageConfig: TableConfig = {
    columns: [
      { field: 'packageName', header: 'Package Name', selected: true },
      { field: 'serviceName', header: 'Service Name ', selected: true },
      { field: 'facilityName', header: 'Facility Name', selected: true },
    ],
    lazy: false,
    searchBar: false,
    paginator: false,
    showIndex: false,
  };

  availableFacilityTableConfig: TableConfig={
    columns:[
      {field: 'facilityName', header:'Facility Name', selected: true},
      {field: 'facilityResource', header:'Facility Resource', selected: true},
      {field: 'startDateTime', header:'Start Date/Time', selected: true},
      {field: 'etartDateTime', header:'End Date/Time', selected: true},
      {field: 'remarks', header:'Remarks', selected: true},
    ],
    lazy: false,
    searchBar: false,
    paginator: false,
    showIndex: false,
  }
  isDeleteAllowForService = false;
  serviceSpinner = signal<boolean>(false);

  constructor() {
    super();
    const modalRef = this._dialogService.getInstance(this._dynamicDialogRef);
    this.patientEncounterModalData = modalRef.data.data;
    this.patientEncounterModalType = modalRef.data.type;
    this.patientEncounterModalFrom = modalRef.data.from;
    if (this.patientEncounterModalData) {
      this.patchFormData();
      if (this.patientEncounterModalData?.patientServiceDtoCollection) {
        this.isShowSelectedServiceList.set(true);
        this.calculateTotalCost();
      }
      if (this.patientEncounterModalData.id) {
        this.getVoucherInfo(this.patientEncounterModalData.id);
      }
    }
  }

  ngOnInit(): void {
    this._episodeService.getMetaForEncounterType();
    this._episodeService.getMetaForEncounterMode();
    this._episodeService.getMetaForAssistant();
    this._episodeService.getMetaForCareProfessional();
    this._patientQuickRegistrationService.getCareProfessionalGroupData();
    this._episodeService.getMetaForFacilityGroup();
    this._episodeService.getMetaForFacilityType();
    this._episodeService.getMetaForServiceCategory();

    if (TRIGGER_FROM.encounter === this.patientEncounterModalFrom) {
      this.patientEncounterForm.get('encounterMode').setValidators([Validators.required]);
    }
  }

  getVoucherInfo(id) {
    this._encounterService
      .getVoucherDetail(id)
      .pipe(takeUntil(this.notifier))
      .subscribe(res => {
        res.responseObject.map(item => {
          item.voucherOptedServiceDtoList.map(service =>{
            this.voucherOptedServiceData.push(service);
          })          
        });
        if (this.patientEncounterModalData?.patientServiceDtoCollection) {
          this.patientEncounterModalData.patientServiceDtoCollection.forEach(item => {
            const isCreatedVoucher = this.voucherOptedServiceData.find(service => service.serviceMapIdf === item.serviceMapIdf);
            item.isCreatedVoucher = isCreatedVoucher ? true : false;
          });
        }
        //this.isDeleteAllowForService = !!!res.responseObject.length;
      });
  }

  patchFormData() {
    this.patientEncounterForm.patchValue({
      payerClassIDP: this.patientEncounterModalData.payerClassIDP,
      careProfessionalIDPT: this.patientEncounterModalData.treatingCareProfessionalIDP,
      reportingDoctor: this.patientEncounterModalData?.treatingCareProfessionalIDP || "",
      patientProfileIDP: this.patientEncounterModalData.patientProfileIDP,
      patientEpisodeIDP: this.patientEncounterModalData.patientEpisodeIDP,
      encounterTypeIDP: this.patientEncounterModalData?.encounterTypeIDP || '',
      encounterMode: this.patientEncounterModalData?.encounterModeIDP || '',
      assistantIDF: this.patientEncounterModalData?.assistantEmployeeIDP || '',
      remarks1: this.patientEncounterModalData?.remarks || '',
      careProfessionalIDPC: this.patientEncounterModalData?.coTreatingCareProfessionalIDP || '',
      careProfessionalIDPR: this.patientEncounterModalData?.referenceCareProfessionalIDP || '',
      citizenIDP: this.patientEncounterModalData?.citizenIDP || '',
    });

    if (!this.reportingDoctor) {
      this.reportingDoctor = {
        careProfessionalIDP: this.patientEncounterModalData.treatingCareProfessionalIDP,
        additionalLicenseNo: null,
        firstName: this.patientEncounterModalData.treatingCareProfessionalFirstName,
        middleName: this.patientEncounterModalData.treatingCareProfessionalMiddleName,
        familyName: this.patientEncounterModalData.treatingCareProfessionalFamilyName,
        fullName: this.patientEncounterModalData.treatingCareProfessionalFullName,
      };
    }

    if (this.patientEncounterModalData.patientFacilityDtoCollection) {
      const facityFormGroup = this.patientEncounterForm.get('facilityForm') as FormGroup;
      const availableFacilityArray = facityFormGroup.controls['availableFacility'] as FormArray;
      this.patientEncounterModalData.patientFacilityDtoCollection.map(
        (facility: EncounterFacilityData) => {
          facility.facilityResources.forEach((facilityResource: FacilityResourceData) => {
            const formGroup = this._episodeService.getAddAvailableFacilityForm();
            formGroup.patchValue({
              facilityName: facility.facility,
              facilityIDP: facility.facilityIDP,
              facilitySourceName: facilityResource.resourceName,
              facilityResourceIDP: facilityResource.facilityResourceIDP,
              status: facilityResource.currentStatus === 2 ? true : false,
              currentStatus: facilityResource.currentStatus,
              currentStatusStr: facilityResource.currentStatusStr,
              isSelected: true,
              startDateTime: new Date(facilityResource.startDateTime),
              endDateTime: new Date(facilityResource.endDateTime),
              remark: facilityResource.remarks,
            });
            availableFacilityArray.push(formGroup);
          });
        }
      );
    }
    this.getServiceList();
  }

  getServiceList() {
    const payerClass = this.patientEncounterForm.get('payerClassIDP').value as any;
    const serviceCategory = this.patientEncounterForm.get('serviceCategory').value as any;
    
    if (serviceCategory && payerClass) {
      this.serviceSpinner.set(true);
      this._patientQuickRegistrationService
        .getServiceMapByPayerClassAndServiceCateGory(payerClass, serviceCategory)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.serviceSpinner.set(false)),
          map(res => {
            const service = res.responseObject.map(service => {
              service.serviceAlias += service.packageIDF ? ` (P) ` : '';
              return {
                ...service,
                isSelected: false,
              };
            });
            this.serviceLists.set(service);
          })
        )
        .subscribe();
    } else if (payerClass) {
      this.serviceSpinner.set(true);
      this._patientQuickRegistrationService
        .getServiceMapByPayerClass(payerClass)
        .pipe(
          takeUntil(this.notifier),
          finalize(() => this.serviceSpinner.set(false)),
          map(res => {
            const service = res.responseObject.map(service => {
              service.serviceAlias += service.packageIDF ? ` (P) ` : '';
              return {
                ...service,
                isSelected: false,
              };
            });
            this.serviceLists.set(service);
          })
        )
        .subscribe();
    }
  }

  getTreatingDoctor(event) {
    this.patientEncounterForm.patchValue({
      reportingDoctor: event.value,
    });
    if (!this.reportingDoctor) {
      this.reportingDoctor = event.item;
    }
  }

  isDoctorServiceSelected(event) {
    this.reportingDoctor = event.item;
    if (typeof event === 'object') {
      this.reportingDoctor = event.item;
    }
    const index = this.selectedServiceList.findIndex(
      item => item.reportingDoctorIDP === this.reportingDoctor.careProfessionalIDP
    );
    this.serviceLists.set(this.serviceLists().map(item => ({ ...item, isSelected: false })));
    if (index !== -1) {
      const object = this.selectedServiceList[index].selectedService;
      object.map(item => {
        const serviceIndex = this.serviceLists().findIndex(
          obj => obj.priceListDetailIDP === item.priceListDetailIDP
        );
        if (serviceIndex >= 0) {
          this.serviceLists()[serviceIndex].isSelected = true;
        }
      });
    }
  }

  checkServiceSelected(checked: boolean, item: PriceListDropdown): void {
    const index = this.selectedServiceList.findIndex(
      item => item.reportingDoctorIDP === this.reportingDoctor.careProfessionalIDP
    );
    item.isSelected = checked;
    if (checked) {
      if (!this.selectedServiceList.length || index === -1) {
        const object: SelectedServiceList = {
          reportingDoctorIDP: this.reportingDoctor.careProfessionalIDP,
          reportingDoctorName: this.reportingDoctor.fullName,
          serviceCategory: null,
          selectedService: [],
        };
        object.selectedService.push({
          ...item,
          quantity: 1,
          date: moment().toISOString(),
          rowStatus: 1,
          isOpenPackagePopup: false,
          servicePackages:[]
        });
        this.selectedServiceList.push(object);
      } else {
        const object: SelectedServiceList = this.selectedServiceList[index];
        object.selectedService.push({
          ...item,
          quantity: 1,
          date: moment().toISOString(),
          rowStatus: 1,
          isOpenPackagePopup: false,
          servicePackages:[]
        });
      }
    } else {
      if (index !== -1) {
        const object: SelectedServiceList = this.selectedServiceList[index];
        const filteredServices: PriceListDropdown[] = object.selectedService.filter(
          s => s.priceListDetailIDP !== item.priceListDetailIDP
        );
        object.selectedService = filteredServices;
        this.selectedServiceList[index] = object;
      }
    }
    this.calculateTotalCost();
  }

  deleteSelectedService(
    doctorIndex: number,
    serviceIndex: number,
    isDeleteFormSelected: boolean = false
  ) {
    if (isDeleteFormSelected) {
      this.addSelectedServiceList[doctorIndex].selectedService.splice(serviceIndex, 1);
      const filterData = this.selectedServiceList.filter(
        object => object.selectedService.length > 0
      );
      this.isShowSelectedServiceList.set(filterData.length > 0 ? true : false);
      this.calculateTotalCost();
    } else {
      this.selectedServiceList[doctorIndex].selectedService.splice(serviceIndex, 1);
      if(this.selectedServiceList[doctorIndex].selectedService?.length === 0){
        this.selectedServiceList.splice(doctorIndex, 1);
      }
      const doctor = this.selectedServiceList[doctorIndex];
      if (this.reportingDoctor.careProfessionalIDP === doctor.reportingDoctorIDP) {
        this.serviceLists.set(this.serviceLists().map(item => ({ ...item, isSelected: false })));
        const object = this.selectedServiceList[doctorIndex].selectedService;
        object.map(item => {
          const serviceIndex = this.serviceLists().findIndex(
            obj => obj.priceListDetailIDP === item.priceListDetailIDP
          );
          if (serviceIndex >= 0) {
            this.serviceLists()[serviceIndex].isSelected = true;
          }
        });
      }
    }
  }

  calculateTotalCost() {
    let total = 0;
    for (const item of this.addSelectedServiceList) {
      for (const service of item.selectedService) {
        console.log(service.quantity)
        if(service.quantity){
          total += service.quantity * service.rate;
        }else{
          total += 0;
        }        
      }
    }
    if (this.patientEncounterModalData && this.patientEncounterModalData?.patientServiceDtoCollection) {
      for (const service of this.patientEncounterModalData.patientServiceDtoCollection) {
        if(!service.isCreatedVoucher){
          total += service.amount;
        }        
      }
    }
    this.totalServiceCost = total;
  }

  getPatientEncounterFormValue(formControl: string) {
    return this.patientEncounterForm.get(formControl).value;
  }

  searchFacility() {
    const facityFormGroup = this.patientEncounterForm.get('facilityForm') as FormGroup;
    this._utilService.markFormGroupDirty(facityFormGroup);
    const facilityFormValues = facityFormGroup.getRawValue();
    if (facityFormGroup.valid && facilityFormValues.facilityType && facilityFormValues.facilityGroup) {      
      this._episodeService
        .getFacilityBySearch(facilityFormValues.facilityType, facilityFormValues.facilityGroup)
        .pipe(takeUntil(this.notifier))
        .subscribe(resp => {
          const faciltyData: Facility[] = resp.responseObject;
          const availableFacilityArray = facityFormGroup.controls['availableFacility'] as FormArray;
          availableFacilityArray.clear();
          faciltyData?.forEach((facility: Facility) => {
            facility.facilityResourceDtoList?.forEach((facilityResource: FacilityResource) => {
              const formGroup = this._episodeService.getAddAvailableFacilityForm();
              formGroup.patchValue({
                facilityName: facility.facility,
                facilityIDP: facility.facilityIDP,
                facilitySourceName: facilityResource.resourceName,
                facilityResourceIDP: facilityResource.facilityResourceIDP,
                status: facilityResource.currentStatus === 2 ? true : false,
                currentStatus: facilityResource.currentStatus,
                currentStatusStr: facilityResource.currentStatusStr,
              });
              availableFacilityArray.push(formGroup);
            });
          });
        });
    }else{
      if(!facilityFormValues.facilityType){
        this._toast.error('Please Facility Type');
      }else if(!facilityFormValues.facilityGroup){
        this._toast.error('Please Facility Group');
      }
    }
  }

  get facilityFormGroup() {
    return this.patientEncounterForm.get('facilityForm').get('availableFacility') as FormArray;
  }

  deleteSelectedFacility(index: number) {
    const facility = this.facilityFormGroup.at(index) as FormGroup;
    facility.patchValue({
      isSelected: false,
      startDateTime: null,
      endDateTime: null,
      remark: null,
    });
  }

  onGroupOPDChange(event) {
    if (event.checked) {
      this.patientEncounterForm.get('careProfessional').setValidators([Validators.required]);
      this.patientEncounterForm.get('careProfessionalIDPT').setValidators(null);
    } else {
      this.patientEncounterForm.get('careProfessional').setValidators(null);
      this.patientEncounterForm.get('careProfessionalIDPT').setValidators([Validators.required]);
    }

    this.patientEncounterForm.get('careProfessional').updateValueAndValidity();
    this.patientEncounterForm.get('careProfessionalIDPT').updateValueAndValidity();
  }

  addServices() {
    this.isShowSelectedServiceList.set(true);
    this.addSelectedServiceList = cloneDeep(this.selectedServiceList);

    console.log("this.addSelectedServiceList::",this.addSelectedServiceList);
    this.calculateTotalCost();
  }

  deleteFromExistingData(index: number) {
    if (!this.patientEncounterModalData.encounterDeletedServiceDtoCollection) {
      this.patientEncounterModalData.encounterDeletedServiceDtoCollection = [];
    }
    const item = this.patientEncounterModalData.patientServiceDtoCollection[index];
    this.patientEncounterModalData.encounterDeletedServiceDtoCollection.push({
      serviceDoctorID: this.getPatientEncounterFormValue('careProfessionalIDPT'),
      serviceMapID: item.serviceMapIdf,
      qty: item.quantity,
      rate: item.rate,
      grossAmt: item.quantity * item.rate,
      rowStatus: -1,
      id: item.id,
    });
    this.patientEncounterModalData.patientServiceDtoCollection.splice(index, 1);
    this.calculateTotalCost();
  }

  submitPatientEncounter() {
    const finalServiceList = [];
    let isRedirectToVoucher: boolean = false;
    if (this.patientEncounterModalData.patientServiceDtoCollection?.length) {
      for (const item of this.patientEncounterModalData.patientServiceDtoCollection) {
        finalServiceList.push({
          serviceDoctorID: this.getPatientEncounterFormValue('careProfessionalIDPT'),
          serviceMapID: item.serviceMapIdf,
          qty: item.quantity,
          rate: item.rate,
          grossAmt: item.quantity * item.rate,
          rowStatus: -1,
        });
        if(!item.isCreatedVoucher){
          isRedirectToVoucher = true;
        }
      }
    }
    for (const item of this.addSelectedServiceList) {
      for (const service of item.selectedService) {
        finalServiceList.push({
          serviceDoctorID: item.reportingDoctorIDP,
          serviceMapID: service.serviceMapIDP,
          qty: service.quantity,
          rate: service.rate,
          grossAmt: service.quantity * service.rate,
          rowStatus: service.rowStatus,
        });
      }
      if(item.selectedService.length>0){
        isRedirectToVoucher = true;
      }
    }
    const isInvalidService = finalServiceList.find(service => service.qty < 1);
    if (isInvalidService) {
      this._toast.error('Please enter valid quantity for selected service');
      return
    }
    if (TRIGGER_FROM.encounter === this.patientEncounterModalFrom) {
      this._utilService.markFormGroupDirty(this.patientEncounterForm, true);
      if (this.patientEncounterForm.invalid) {
        return;
      }
      const param: PatiendEncounterFormData = {
        patientEncounterIDP: this.patientEncounterModalData?.patientEncounterIDP,
        encounterTypeIDP: this.getPatientEncounterFormValue('encounterTypeIDP'),
        encounterMode: this.getPatientEncounterFormValue('encounterMode'),
        patientEpisodeIDP: this.getPatientEncounterFormValue('patientEpisodeIDP'),
        patientProfileIDP: this.getPatientEncounterFormValue('patientProfileIDP'),
        careProfessionalIDPT: this.getPatientEncounterFormValue('careProfessionalIDPT'),
        careProfessionalIDPC: this.getPatientEncounterFormValue('careProfessionalIDPC'),
        careProfessionalIDPR: this.getPatientEncounterFormValue('careProfessionalIDPR'),
        assistantIDF: this.getPatientEncounterFormValue('assistantIDF'),
        remarks1: this.getPatientEncounterFormValue('remarks1'),
        encounterRequestServiceDtoCollection: finalServiceList,
        encounterDeletedServiceDtoCollection:
          this.patientEncounterModalData.encounterDeletedServiceDtoCollection || [],
        encounterRequestFacilityDtoCollection: this.getPatientEncounterFormValue(
          'facilityForm.availableFacility'
        ).map(facility => ({
          facilityIDP: facility.facilityIDP,
          facility: facility.facilityName,
          facilityResources: [
            {
              facilityResourceIDP: facility.facilityResourceIDP,
              resourceName: facility.facilitySourceName,
              currentStatus: facility.currentStatus,
              startDateTime: moment(facility.startDateTime).isValid()
                ? moment(facility.startDateTime).format('DD-MMM-YYYY HH:mm')
                : null,
              endDateTime: moment(facility.endDateTime).isValid()
                ? moment(facility.endDateTime).format('DD-MMM-YYYY HH:mm')
                : null,
              quantity: 1,
              remarks: facility.remark || '',
            },
          ],
          utilizationType: 1,
        })),
        printOrderSheet: this.getPatientEncounterFormValue('printOrderSheet'), //Print OrderSheet ?
        printVoucher: this.getPatientEncounterFormValue('generateVoucher'), // Generate Voucher ?
        sendSms: this.getPatientEncounterFormValue('sendSMS'), //Send SMS ?
      };
      if (
        param.encounterRequestServiceDtoCollection.length > 0 &&
        this.isShowSelectedServiceList()
      ) {
        this._encounterService
          .savePatientEncounter(param)
          .pipe(
            takeUntil(this.notifier),
            finalize(() => {
              this.isLoading.set(false);
            })
          )
          .subscribe({
            next: async (res: any) => {
              this._toast.success(res.responseMessage);
              if (this.patientEncounterForm.value.generateVoucher && isRedirectToVoucher) {
                await this._router.navigate(['front-desk/voucher/finance-voucher'], {
                  queryParams: {
                    voucherType: 'OPD Cash Memo',
                    patientEpisodeIDP: 1,
                    voucherMapIdf: 3232,
                    type: 8,
                    encounterID:
                     
                      res.responseObject.patientServiceDtoCollection[0].patientEncounterIdf,
                    citizenIDP: this.getPatientEncounterFormValue('citizenIDP'),
                  },
                });
                this._dynamicDialogRef.close(false);
              } else {
                this._dynamicDialogRef.close(true);
              }
            },
          });
      } else {
        this._toast.error('Please select services.');
      }
    } else if (TRIGGER_FROM.encounterService === this.patientEncounterModalFrom) {
      const param: PatiendEncounterServiceFormData = {
        patientEncounterIDP: this.patientEncounterModalData?.patientEncounterIDP,
        encounterRequestServiceDtoCollection: finalServiceList,
        encounterDeletedServiceDtoCollection:
          this.patientEncounterModalData.encounterDeletedServiceDtoCollection || [],
        printOrderSheet: this.getPatientEncounterFormValue('printOrderSheet'), //Print OrderSheet ?
        sendSms: this.getPatientEncounterFormValue('sendSMS'), //Send SMS ?
      };

      if (param.encounterRequestServiceDtoCollection.length > 0) {
        this._encounterServiceService
          .savePatientEncounterService(param)
          .pipe(
            takeUntil(this.notifier),
            finalize(() => {
              this.isLoading.set(false);
            })
          )
          .subscribe({
            next: (res: any) => {
              this._toast.success(res.responseMessage);
              this._dynamicDialogRef.close(true);
            },
          });
      } else {
        this._toast.error('No Data for Updating!');
      }
    }
  }

  isUpArrow = true;
  isOpen = false;

  toggleArrow() {
    this.isUpArrow = !this.isUpArrow;
    this.isOpen = !this.isOpen;
  }

  getArrowIcon() {
    return this.isUpArrow ? 'pi pi-angle-down' : 'pi pi-angle-up';
  }

  toogleServicePackageTable(
    doctorIndex: number,
    serviceIndex: number) {
      if(!this.addSelectedServiceList[doctorIndex].selectedService[serviceIndex].isOpenPackagePopup && this.addSelectedServiceList[doctorIndex].selectedService[serviceIndex].servicePackages.length === 0){
        const packageIDF: string = this.addSelectedServiceList[doctorIndex].selectedService[serviceIndex].packageIDF.toString();
        this._patientQuickRegistrationService
          .getPackageServiceDataByIds(packageIDF)
          .pipe(
            takeUntil(this.notifier),
            map(res => {
              let srNo = 1;
              const modifiedData = flatMap(groupBy(res.responseObject, 'packageIDP'), items => {
                let prevPackageIDP = null;
                return items.map(item => {
                  const { packageIDP, packageName, ...rest } = item;
                  const shouldSetSrNo =
                    packageIDP && (!prevPackageIDP || prevPackageIDP !== packageIDP);
                  prevPackageIDP = shouldSetSrNo ? packageIDP : prevPackageIDP;
                  return {
                    ...rest,
                    packageName: shouldSetSrNo ? packageName : null,
                    srNo: shouldSetSrNo ? srNo++ : null,
                  };
                });
              });
              this.addSelectedServiceList[doctorIndex].selectedService[serviceIndex].servicePackages = modifiedData;
            })
          )
          .subscribe();
      }
      
        this.addSelectedServiceList[doctorIndex].selectedService[serviceIndex].isOpenPackagePopup = !this.addSelectedServiceList[doctorIndex].selectedService[serviceIndex].isOpenPackagePopup;
  }

  resetForm(){
    this.addSelectedServiceList = [];
    this.selectedServiceList = [];
    this.totalServiceCost = 0;
    this.patientEncounterModalData.patientServiceDtoCollection = [];
    this.getServiceList();
  }
}
