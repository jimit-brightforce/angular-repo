import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientEncounterModalComponent } from './patient-encounter-modal.component';

describe('PatientEncounterModalComponent', () => {
  let component: PatientEncounterModalComponent;
  let fixture: ComponentFixture<PatientEncounterModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PatientEncounterModalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PatientEncounterModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
