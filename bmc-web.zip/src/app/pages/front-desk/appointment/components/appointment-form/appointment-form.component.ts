import { DatePipe } from '@angular/common';
import { Component, Input, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AppDropdownComponent, ReferenceDoctorDropdownComponent } from '@components';
import { AppointmentModes } from '@consts';
import { ToastService } from '@services';
import { FormBehavior } from '@strategies';
import * as moment from 'moment';
import { ButtonModule } from 'primeng/button';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { FloatLabelModule } from 'primeng/floatlabel';

@Component({
  selector: 'app-appointment-form',
  standalone: true,
  imports: [
    InputTextareaModule,
    AppDropdownComponent,
    InputTextModule,
    ReactiveFormsModule,
    ButtonModule,
    DatePipe,
    ReferenceDoctorDropdownComponent,
    FloatLabelModule,
  ],
  templateUrl: './appointment-form.component.html',
  styleUrl: './appointment-form.component.scss',
})
export class AppointmentFormComponent {
  @Input() selectInfo;
  private _ref = inject(DynamicDialogRef);
  private _fb = inject(FormBuilder);
  private _toastService = inject(ToastService);
  private _formBehaviour = inject(FormBehavior);
  private _dialogConfig = inject(DynamicDialogConfig);

  protected dialogData = this._dialogConfig.data;
  selectedDoctor = null;
  appointmentForm = this._fb.group({
    date: [],
    startTime: [],
    endTime: [],
    purposeType: ['', [Validators.required]],
    appointmentMode: [null, [Validators.required]],
    purposeDetails: [null, [Validators.required]],
    doctorForm: this._fb.group({
      refDoctor: [13],
    }),
  });

  protected readonly AppointmentModes = AppointmentModes;
  timeOptions = [
    {
      id: '07:15',
      label: '07:15 AM',
    },
    {
      id: '07:40',
      label: '07:40 AM',
    },
    {
      id: '07:50',
      label: '07:50 AM',
    },
  ];

  purposeTypes = [
    {
      id: '1',
      label: 'Type1',
    },
    {
      id: '2',
      label: 'Type2',
    },
    {
      id: '3',
      label: 'Type3',
    },
  ];

  constructor() {
    if (this.dialogData.selectedSlot) {
      const start = moment(this.dialogData.selectedSlot.start);
      const end = moment(this.dialogData.selectedSlot.start).add(15, 'minutes');
      this.appointmentForm.patchValue({
        date: this.dialogData.selectedSlot.start,
        startTime: start.format('HH:mm'),
        endTime: end.format('HH:mm'),
      });
    }
  }

  saveAppointment() {
    this._formBehaviour.markFormGroupDirty(this.appointmentForm);
    if (this.appointmentForm.valid) {
      this._toastService.success('Appointment saved succesfully');
      this._ref.close(this.appointmentForm.getRawValue());
    }
  }
}
