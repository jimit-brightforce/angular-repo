import { AfterViewInit, ChangeDetectorRef, Component, inject, signal } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FullCalendarModule } from '@fullcalendar/angular';
import { ButtonModule } from 'primeng/button';
import { PanelModule } from 'primeng/panel';
import { CalendarOptions, DateSelectArg, EventApi, EventClickArg } from '@fullcalendar/core';
import interactionPlugin from '@fullcalendar/interaction';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import { AppDropdownComponent } from '@components';
import { AddressDataService, AppDialogService, TRIGGER_FROM, ToastService } from '@services';
import { DestroyBehavior } from '@strategies';
import { takeUntil } from 'rxjs';
import { DialogService } from 'primeng/dynamicdialog';
import { AppointmentFormComponent } from './components/appointment-form/appointment-form.component';
import * as moment from 'moment';
import { EventImpl } from '@fullcalendar/core/internal';
import { DropdownModule } from 'primeng/dropdown';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputTextModule } from 'primeng/inputtext';
import { SelectButtonModule } from 'primeng/selectbutton';
import { ActionPermissionDirective, PermissionMap } from '@directives';
import { SlugMap } from '@enums';

@Component({
  selector: 'app-appointment',
  standalone: true,
  imports: [
    FullCalendarModule,
    PanelModule,
    AppDropdownComponent,
    ButtonModule,
    DropdownModule,
    FloatLabelModule,
    InputTextModule,
    SelectButtonModule,
    ActionPermissionDirective,
  ],
  providers: [AppDialogService, ToastService, AddressDataService],
  templateUrl: './appointment.component.html',
  styleUrl: './appointment.component.scss',
})
export class AppointmentComponent extends DestroyBehavior implements AfterViewInit {
  private changeDetector = inject(ChangeDetectorRef);
  private _fb = inject(FormBuilder);
  private _appDialogService = inject(AppDialogService);
  private _toastService = inject(ToastService);
  private _dialogService = inject(DialogService);
  protected readonly PermissionMap = PermissionMap;
  protected readonly SlugMap = SlugMap;
  calendarOptions = signal<CalendarOptions>({
    plugins: [interactionPlugin, dayGridPlugin, timeGridPlugin],
    views: {
      timeGridFourDay: {
        type: 'timeGrid',
        duration: { days: 3 },
        buttonText: '3 day',
      },
    },
    slotDuration: '00:05',
    slotMinTime: '07:00:00',
    slotMaxTime: '19:00:00',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'timeGridWeek,timeGridFourDay,timeGridDay',
    },
    firstDay: new Date().getDay(),
    initialDate: new Date(),
    initialView: 'timeGridWeek',
    allDaySlot: false,
    // initialEvents: INITIAL_EVENTS, // alternatively, use the `events` setting to fetch from a feed
    weekends: true,
    selectable: true,
    selectMirror: true,
    dayMaxEvents: true,
    editable: true,
    select: this.handleDateSelect.bind(this),
    eventClick: this.handleEventClick.bind(this),
    eventsSet: this.handleEvents.bind(this),
    validRange: nowDate => {
      return {
        start: nowDate,
      };
    },
    events: [],
  });
  currentEvents = signal<EventApi[]>([]);

  appointmentMetaForm = this._fb.group({
    hospitalId: [1],
    doctorId: [1, [Validators.required]],
    patientId: [1],
    scheduleId: [],
  });
  selectedPatient = {
    medicoId: 1,
    name: 'Paven',
  };
  faculty = [
    {
      id: 1,
      name: 'faculty 1',
    },
    {
      id: 2,
      name: 'faculty 2',
    },
    {
      id: 3,
      name: 'faculty 3',
    },
    {
      id: 4,
      name: 'faculty 4',
    },
    {
      id: 5,
      name: 'faculty 5',
    },
  ];
  doctorName = [
    {
      id: 1,
      name: 'doctor 1',
    },
    {
      id: 2,
      name: 'doctor 2',
    },
    {
      id: 3,
      name: 'doctor 3',
    },
    {
      id: 4,
      name: 'doctor 4',
    },
    {
      id: 5,
      name: 'doctor 5',
    },
  ];

  dateOption: any[] = [
    { label: 'Today', value: 'Today' },
    { label: '3 Days', value: '3 Days' },
    { label: 'Full Week', value: 'Full Week' },
  ];

  doctors = [
    {
      'careProfessionalIDP': 15512,
      'firstName': 'Aditya',
      'middleName': 'Pravin',
      'familyName': 'Viras',
      name: '',
    },
    {
      'careProfessionalIDP': 13902,
      'firstName': 'Akash',
      'middleName': 'Rajeshbhai',
      'familyName': 'Doshi',
      name: '',
    },
  ].map(doctor => {
    doctor.name = `${doctor.firstName} ${doctor.middleName} ${doctor.familyName}`;
    return doctor;
  });

  ngAfterViewInit(): void {
    this.calendarOptions().events = [
      {
        title: 'test',
        start: moment().set('hours', 7).toDate(),
        end: moment().set('hours', 7).set('minute', 25).toDate(),
      },
    ]; //a code for adding an event into the day
  }

  handleDateSelect(selectedSlot: DateSelectArg) {
    if (!this.selectedPatient) {
      this._toastService.error('Select Patient First');
      return;
    }

    this.openAppointmentForm(selectedSlot);
    // const title = prompt('Please enter a new title for your event');
    // const calendarApi = selectedSlot.view.calendar;
    // calendarApi.unselect(); // clear date selection
    // if (title) {
    //   calendarApi.addEvent({
    //     id: createEventId(),
    //     title,
    //     start: selectedSlot.startStr,
    //     end: selectedSlot.endStr,
    //     allDay: selectedSlot.allDay
    //   });
    // }
  }

  openAppointmentForm(selectedSlot: DateSelectArg | EventImpl) {
    const modalRef = this._dialogService.open(AppointmentFormComponent, {
      header: 'Appointment',
      data: {
        selectedSlot,
        patient: this.selectedPatient,
      },
      width: '500px',
      contentStyle: { 'max-height': '800px', overflow: 'auto', Overlay: true },
      focusOnShow: true,
    });
    modalRef.onClose.subscribe(() => { });
  }

  handleEventClick(clickInfo: EventClickArg) {
    this.openAppointmentForm(clickInfo.event);
  }

  handleEvents(events: EventApi[]) {
    this.currentEvents.set(events);
    this.changeDetector.detectChanges(); // workaround for pressionChangedAfterItHasBeenCheckedError
  }

  selectPatient() {
    const modalRef = this._appDialogService.openPatientSelectModal(TRIGGER_FROM.appointment);
    modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(data => {
      if (data) {
        this.selectedPatient = data;
        this.appointmentMetaForm.get('patientId').setValue(this.selectedPatient.medicoId);
      }
    });
  }

  // AddPatient() {
  //   const modalRef = this._appDialogService.openAddPatientModal(TRIGGER_FROM.appointment);
  //   modalRef.onClose.pipe(takeUntil(this.notifier)).subscribe(data => {
  //     if (data) {
  //       this.selectedPatient = data;
  //       this.appointmentMetaForm.get('patientId').setValue(this.selectedPatient.medicoId);
  //     }
  //   });
  // }
}
