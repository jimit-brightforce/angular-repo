import { inject, Injectable } from '@angular/core';
import { FilterEvent } from '@components';
import { API_FOLDER } from '@consts';
import { ListApiResponse } from '@models';
import { ApiServices } from '@services';
import { AssistantScheduleList } from '../interface/assistant-schedule.interface';

@Injectable()
export class AssistantScheduleService {
  private _apiService = inject(ApiServices);
  getAssistantScheduleList(payload: FilterEvent) {
    return this._apiService.post<ListApiResponse<AssistantScheduleList>>(
      `/v1/${API_FOLDER.frontDesk}/patient-encounter/assistant-schedule`,
      payload
    );
  }
}
