import { TestBed } from '@angular/core/testing';

import { AssistantScheduleService } from './assistant-schedule.service';

describe('AssistantScheduleService', () => {
  let service: AssistantScheduleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssistantScheduleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
