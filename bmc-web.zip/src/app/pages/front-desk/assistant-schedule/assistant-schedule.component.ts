import { ChangeDetectorRef, Component, ViewChild, inject, signal } from '@angular/core';
import { AssistantScheduleService } from './service/assistant-schedule.service';
import {
  TableComponent,
  TableColumnDirective,
  TableConfig,
  FilterEvent,
  RangeSearchFormComponent,
} from '@components';
import { ButtonModule } from 'primeng/button';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { TagModule } from 'primeng/tag';
import {
  AssistantScheduleData,
  AssistantScheduleList,
} from './interface/assistant-schedule.interface';
import { DestroyBehavior } from '@strategies';
import { CalendarModule } from 'primeng/calendar';
import { finalize, takeUntil } from 'rxjs';
import { DateFormat } from '@enums';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import { AppDialogService } from '@services';

@Component({
  selector: 'app-assistant-schedule',
  standalone: true,
  imports: [
    ButtonModule,
    TableComponent,
    TagModule,
    TableColumnDirective,
    OverlayPanelModule,
    RangeSearchFormComponent,
    CalendarModule,
    FormsModule,
  ],
  providers: [AssistantScheduleService, DatePipe],
  templateUrl: './assistant-schedule.component.html',
  styleUrl: './assistant-schedule.component.scss',
})
export class AssistantScheduleComponent extends DestroyBehavior {
  @ViewChild(TableComponent) _table: TableComponent;
  private _assistantScheduleService = inject(AssistantScheduleService);
  private _appDialogService = inject(AppDialogService);

  // date = new Date();
  assistantScheduleBody: FilterEvent;
  startDate: string = '';
  endDate: string = '';
  assistantScheduleTableData = signal<AssistantScheduleData[]>([]);

  config: TableConfig = {
    loading: true,
    columns: [
      {
        field: 'encounterDate',
        header: 'Date',
        sortable: true,
        selected: true,
        dateFormat: DateFormat.mediumWithSeperator,
      },
      { field: 'patient', header: 'Patient', sortable: true, selected: true },
      { field: 'episodeType', header: 'Type', sortable: true, selected: true },
      {
        field: 'careProfessionalName',
        header: 'Care Professional',

        sortable: true,
        selected: true,
      },
      { field: 'payerClassName', header: 'Payer Class', sortable: true, selected: true },
      { field: 'bedNo', header: 'Bed No', sortable: true, selected: true },
      { field: 'encounterNumber', header: 'Encounter No', sortable: true, selected: true },
      { field: 'encounterType', header: 'Encounter Type', sortable: true, selected: true },
    ],
    lazy: true,
    actionItems: [],
    totalRecords: 0,
    // showColumnFilter: false,
  };

  rangeDate = [new Date(), new Date()];
  selectedDates: string[] = [];

  constructor(private cdr: ChangeDetectorRef) {
    super();
    // this.rangeDate.forEach(date => this.selectedDates.push(moment(date).format('YYYY-MM-DD')));
  }

  filterEvent(event: FilterEvent) {
    this.config.loading = true;
    if (!event.page) {
      event = { ...this.assistantScheduleBody, ...event };
    }
    this.assistantScheduleBody = event;

    const params: AssistantScheduleList = {
      page: event.page,
      size: event.size,
      startDate: this.startDate || moment().format('YYYY-MM-DD'),
      endDate: this.endDate || moment().format('YYYY-MM-DD'),
      searchKey: event.searchKey,
      sort: event.sort,
    };

    this._assistantScheduleService
      .getAssistantScheduleList(params)
      .pipe(
        finalize(() => (this.config.loading = false)),
        takeUntil(this.notifier)
      )
      .subscribe((res: any) => {
        this.assistantScheduleTableData.set(res.responseObject.content);
        this.config.totalRecords = res.responseObject.totalElements;
      });
    this.config.loading = false;
    // this.assistantScheduleTableData.set([]);
  }

  searchAssistantSchedule() {}

  resetSearch() {}

  getData(eve: any) {
    const dateObj = new Date(eve);
    const formattedDate = moment(dateObj).format('YYYY-MM-DD');
    // Clear previous selections if there are more than 2
    if (this.selectedDates.length === 2) {
      this.selectedDates = [];
    }
    this.selectedDates.push(formattedDate);
    // Ensure only 2 dates are stored
    this.selectedDates = this.selectedDates.slice(-2);
    // Assign start and end dates
    [this.startDate, this.endDate] = this.selectedDates;
    eve = this.selectedDates;
    // Make API call if both dates are selected
    if (this.selectedDates.length === 2) {
      this.filterEvent(eve);
    }
  }

  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngAfterViewInit() {
    //  Your code that modifies the property
    this.cdr.detectChanges();
  }
}
