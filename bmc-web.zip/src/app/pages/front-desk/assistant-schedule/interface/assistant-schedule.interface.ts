import { FilterEvent } from '@components';

export interface AssistantScheduleData {
  date: string;
  encounterNo: string;
  encounterType: string;
  type: string;
  payerClass: string;
  bedNo: string;
  patient: string;
  isCareProfessional: boolean;
}

export interface AssistantScheduleList extends FilterEvent {
  startDate?: string;
  endDate?: string;
}
