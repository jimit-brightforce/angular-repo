import { importProvidersFrom, NgModule } from '@angular/core';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { provideClientHydration } from '@angular/platform-browser';

import { CookieModule } from 'ngx-cookie';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { JwtModule } from '@auth0/angular-jwt';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AppLayoutModule } from './layout/app.layout.module';
import { NotfoundComponent } from './pages/notfound/notfound.component';
import { DialogService } from 'primeng/dynamicdialog';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { httpInterceptor } from './shared/interceptors/http.interceptor';

@NgModule({
  declarations: [AppComponent, NotfoundComponent],
  imports: [
    AppRoutingModule,
    AppLayoutModule,
    CookieModule.withOptions(),
    ConfirmDialogModule,
    ToastModule,
    // JwtModule.forRoot({}),
  ],
  providers: [
    { provide: LocationStrategy, useClass: PathLocationStrategy },

    importProvidersFrom(
      JwtModule.forRoot({
        config: {
          // tokenGetter: tokenGetter,
        },
      })
    ),

    provideHttpClient(withInterceptors([httpInterceptor])),
    provideClientHydration(),
    MessageService,
    ConfirmationService,
    DialogService,
    // JwtInterceptor, // Add this line to provide an instance of JwtInterceptor
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
