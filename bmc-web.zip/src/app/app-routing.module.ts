import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { NotfoundComponent } from './pages/notfound/notfound.component';
import { AppLayoutComponent } from './layout/app.layout.component';
import { authGuard, guestGuard } from '@guards';

@NgModule({
  imports: [
    RouterModule.forRoot(
      [
        {
          path: '',
          loadChildren: () => import('./pages/landing/landing.module').then(m => m.LandingModule),
          canActivate: [guestGuard],
        },

        {
          path: 'auth',
          loadChildren: () => import('./pages/auth/auth.module').then(m => m.AuthModule),
          canActivate: [guestGuard],
        },
        {
          path: '',
          component: AppLayoutComponent,
          canActivate: [authGuard],
          children: [
            {
              path: 'dashboard',
              loadChildren: () =>
                import('./pages/dashboard/dashboard.module').then(m => m.DashboardModule),
            },
            {
              path: 'front-desk',
              loadChildren: () =>
                import('./pages/front-desk/front-desk.module').then(m => m.FrontDeskModule),
            },
            {
              path: 'pathology',
              loadChildren: () =>
                import('./pages/pathology/pathology.module').then(m => m.PathologyModule),
            },
            {
              path: 'hr-department',
              loadChildren: () =>
                import('./pages/hr-department/hr-department.module').then(
                  m => m.HrDepartmentModule
                ),
            },
            {
              path: 'pathology',
              loadChildren: () =>
                import('./pages/pathology/pathology-routing.module').then(
                  m => m.PathologyRoutingModule
                ),
            },
            {
              path: 'pharmacy',
              loadChildren: () =>
                import('./pages/pharmacy/pharmacy.module').then(m => m.PharmacyModule),
            },
            {
              path: 'inventory',
              loadChildren: () =>
                import('./pages/inventory/inventory-routing.module').then(
                  m => m.InventoryRoutingModule
                ),
            },
            {
              path: 'service-config',
              loadChildren: () =>
                import('./pages/service-config/service-config.module').then(
                  m => m.ServiceConfigModule
                ),
            },
            {
              path: 'client-configuration',
              loadChildren: () =>
                import('./pages/client-configuration/client-configuration.module').then(
                  m => m.ClientConfigurationModule
                ),
            },
            {
              path: 'financial',
              loadChildren: () =>
                import('./pages/financial/financial.module').then(m => m.FinancialModule),
            },
            {
              path: 'documentation',
              loadChildren: () =>
                import('./pages/documentation/documentation.module').then(
                  m => m.DocumentationModule
                ),
            },
            {
              path: 'inventory',
              loadChildren: () =>
                import('./pages/inventory/inventory.module').then(m => m.InventoryModule),
            },
            {
              path: 'empty',
              loadChildren: () =>
                import('./pages/empty/emptydemo.module').then(m => m.EmptyDemoModule),
            },
            {
              path: 'reporting',
              loadChildren: () =>
                import('./pages/reporting/reporting.module').then(m => m.ReportingModule),
            },
            {
              path: 'user',
              loadChildren: () => import('./pages/user/user.module').then(m => m.UserModule),
            },
            {
              path: 'medical-terminology',
              loadChildren: () =>
                import('./pages/medical-terminology/medical-terminology.module').then(
                  m => m.MedicalTerminologyModule
                ),
            },
            {
              path: 'others',
              loadChildren: () => import('./pages/others/others.module').then(m => m.OthersModule),
            },
            {
              path: 'demographics-info',
              loadChildren: () =>
                import('./pages/demographics-info/demographics-info.module').then(
                  m => m.DemographicsInfoModule
                ),
            },
            {
              path: 'medical-equipment',
              loadChildren: () =>
                import('./pages/medical-equipment/medical-equipment.module').then(
                  m => m.MedicalEquipmentModule
                ),
            },
            {
              path: 'menu-configuration',
              loadChildren: () =>
                import('./pages/menu-configuration/menu-configuration.module').then(
                  m => m.MenuConfigurationModule
                ),
            },
            {
              path: 'mis-reports',
              loadChildren: () =>
                import('./pages/mis-reports/mis-reports.module').then(
                  m => m.MisReportsModule
                ),
            },
          ],
        },
        { path: 'notfound', component: NotfoundComponent },
        { path: '**', redirectTo: '/notfound' },
      ],
      {
        scrollPositionRestoration: 'enabled',
        anchorScrolling: 'enabled',
        onSameUrlNavigation: 'reload',
      }
    ),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
