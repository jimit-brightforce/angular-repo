import { Injectable, signal } from '@angular/core';
import { Subject } from 'rxjs';
import { MenuChangeEvent } from '../api/menuchangeevent';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  private menuSource = new Subject<MenuChangeEvent>();
  private resetSource = new Subject();
  public actionMap = signal<object>(null);

  menuSource$ = this.menuSource.asObservable();
  resetSource$ = this.resetSource.asObservable();

  onMenuStateChange(event: MenuChangeEvent) {
    this.menuSource.next(event);
  }

  reset() {
    this.resetSource.next(true);
  }

  setLocalMenu(menu) {
    localStorage.setItem('menus', JSON.stringify(menu));
  }

  getLocalMenu() {
    return JSON.parse(localStorage.getItem('menus') || '[]');
  }

  setActionMap(map) {
    this.actionMap.set(map);
  }
}
