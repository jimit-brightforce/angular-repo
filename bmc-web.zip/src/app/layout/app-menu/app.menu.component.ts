import { Component, inject, effect } from '@angular/core';
import { LayoutService } from '../service/app.layout.service';
import { AuthService } from '@services';
import { MENU_LIST } from './menu-list';
import { findIndex, cloneDeep } from 'lodash';
import { MenuService } from './app.menu.service';

@Component({
  selector: 'app-menu',
  templateUrl: './app.menu.component.html',
})
export class AppMenuComponent {
  model = [];
  private authService = inject(AuthService);
  private menuSevice = inject(MenuService);
  userInfo = this.authService.userInfo;

  constructor(public layoutService: LayoutService) {
    this.setMenuByUser(this.menuSevice.getLocalMenu());
    effect(
      () => {
        if (this.userInfo()) {
          const menuFromResponse = this.userInfo().menu;
          this.setMenuByUser(menuFromResponse);
        }
      },
      {
        allowSignalWrites: true,
      }
    );
  }

  setMenuByUser(menuFromResponse) {
    if (!menuFromResponse.length) return;
    const viewableMenus = [];
    const actionMap = {};
    const allMenu = cloneDeep(MENU_LIST[0].items);
    for (let index = 0; index < allMenu.length; index++) {
      const findMainMenuIndex = findIndex(menuFromResponse, {
        menuGroupName: allMenu[index].label,
      });
      if (findMainMenuIndex > -1) {
        const subMenus = [];
        const groupedMenu = allMenu[index];
        groupedMenu.items.forEach(menu => {
          const findSubMenuIndex = findIndex(menuFromResponse[findMainMenuIndex].menus, {
            menuSlug: menu.slug,
          });
          if (findSubMenuIndex > -1) {
            const userRights =
              menuFromResponse[findMainMenuIndex].menus[findSubMenuIndex].userRights;
            if (userRights !== '0000') {
              subMenus.push(menu);
              menuFromResponse[findMainMenuIndex].menus[findSubMenuIndex].url = menu.routerLink[0];
              actionMap[menu.slug] = userRights;
            }
          }
        });
        groupedMenu.items = subMenus;
        viewableMenus.push(groupedMenu);
      }
    }
    this.model = [
      {
        label: '',
        items: viewableMenus,
      },
    ];
    this.menuSevice.setLocalMenu(menuFromResponse);
    this.menuSevice.setActionMap(actionMap);
  }
}
