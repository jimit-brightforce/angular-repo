import { Component, ElementRef, ViewChild, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { LayoutService } from '../service/app.layout.service';
import { AuthService, ToastService } from '@services';
import { FormBehavior } from '@strategies';
import { ConfirmPasswordValidator } from '@validators';

@Component({
  selector: 'app-topbar',
  templateUrl: './app.topbar.component.html',
})
export class AppTopBarComponent {
  @ViewChild('menubutton') menuButton!: ElementRef;
  @ViewChild('topbarmenubutton') topbarMenuButton!: ElementRef;
  @ViewChild('topbarmenu') menu!: ElementRef;

  private _auth = inject(AuthService);
  private _fb = inject(FormBuilder);
  private _formBehavior = inject(FormBehavior);
  private _toastService = inject(ToastService);

  public layoutService = inject(LayoutService);
  public authService = inject(AuthService);

  public visibleChangePasswordDialog = false;
  public changePasswordForm = this._fb.group(
    {
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required],
    },
    { validators: ConfirmPasswordValidator }
  );

  items: MenuItem[] = [
    {
      label: 'Change Password',
      icon: 'pi pi-lock',
      command: () => {
        this._toggleChangePasswordModal();
      },
    },
    {
      label: 'Logout',
      icon: 'pi pi-sign-out',
      command: () => {
        this._logout();
      },
    },
  ];

  private _toggleChangePasswordModal() {
    this.visibleChangePasswordDialog = !this.visibleChangePasswordDialog;
  }

  changePassword() {
    this._formBehavior.markFormGroupDirty(this.changePasswordForm);
    if (this.changePasswordForm.valid) {
      this._toastService.success('Congratulations, Password changed successfully.');
      this._toggleChangePasswordModal();
    }
  }

  private _logout() {
    this._auth.logout();
  }
}
