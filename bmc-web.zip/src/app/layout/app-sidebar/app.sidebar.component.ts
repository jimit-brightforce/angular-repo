import { Component, ElementRef, OnInit, inject } from '@angular/core';
import { LayoutService } from '../service/app.layout.service';
import { AuthService } from '@services';
import { environment } from '@environments';

@Component({
  selector: 'app-sidebar',
  templateUrl: './app.sidebar.component.html',
})
export class AppSidebarComponent implements OnInit {
  layoutService = inject(LayoutService);
  authService = inject(AuthService);
  el = inject(ElementRef);

  version = environment.version;
  ngOnInit(): void {
    this.authService.getUserInfo().subscribe();
  }
}
