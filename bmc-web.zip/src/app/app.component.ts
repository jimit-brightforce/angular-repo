import { DOCUMENT } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { PrimeNGConfig } from 'primeng/api';
import { harmony, colorSet } from 'simpler-color';
import { AppCookieService } from './shared/services/cookie.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit {
  constructor(
    private primengConfig: PrimeNGConfig,
    private appCookieService: AppCookieService,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.setRootColors('#254D99', 'primary');
    this.setRootColors('#003399', 'secondary');

    // setTimeout(() => {
    //   this.setRootColors('#764abc', 'primary');

    //   setTimeout(() => {
    //     this.setRootColors('#c93d82', 'primary');
    //   }, 3000);
    // }, 5000);

    if (!this.appCookieService.get('test')) {
      this.appCookieService.set('test', '1');
    }
  }

  setRootColors(color: string, tag: string) {
    const rootStyle = this.document.body.style;
    const baseColors = harmony(color);
    const colorSetObj = colorSet(baseColors);
    const pallete = [1, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 98, 100];
    rootStyle.setProperty(`--${tag}-color`, color, 'important');
    pallete.forEach(opacity => {
      rootStyle.setProperty(
        `--medicodb-${tag}-${opacity}`,
        colorSetObj.primary(opacity),
        'important'
      );
    });
  }

  ngOnInit() {
    this.primengConfig.ripple = true;
  }
}
